/*!
 * Common methods
 *
 * http://crushftp.com/
 *
 * Author: Vipul Limbachiya
 *
 * http://urvatechlabs.com
 */

// Various methods that adds form functionalities and prototypes to existing methods

//jQuery function, clears form fields
$.fn.clearForm = function() {
    return this.each(function() {
        var type = this.type,
            tag = this.tagName.toLowerCase();
        if (tag == 'form' || tag == 'div') return $(':input', this).clearForm();
        if (type == 'text' || type == 'password' || tag == 'textarea') this.value = '';
        else if (type == 'checkbox' || type == 'radio') {
            this.checked = false;
        } else if (tag == 'select') this.selectedIndex = -1;
    });
};

jQuery.fn.offsetRelativeTo = function(el) {
    var $el = $(el),
        o1 = this.offset(),
        o2 = $el.offset();
    o1.top -= o2.top - $el.scrollTop();
    o1.left -= o2.left - $el.scrollLeft();
    return o1;
};

//Swap 2 array items
Array.prototype.swapItems = function(a, b) {
    var temp = this[a];
    this[a] = this[b];
    this[b] = temp;
    return this;
};

//Checks if string ends with specidied string
String.prototype.endsWith = function(str) {
    return (this.match(str + "$") == str);
};

// Check if specified array has item
Array.prototype.has = function(value) {
    var i;
    for (var i = 0, loopCnt = this.length; i < loopCnt; i++) {
        if (this[i] === value) {
            return true;
        }
    }
    return false;
};

// Few buggy browsers does not have indexOf for an array, add it if not available
if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function(value) {
        var i;
        for (var i = 0, loopCnt = this.length; i < loopCnt; i++) {
            if (this[i] === value) {
                return i;
            }
        }
        return -1;
    };
}

if (!('filter' in Array.prototype)) {
    Array.prototype.filter = function(filter, that /*opt*/ ) {
        var other = [],
            v;
        for (var i = 0, n = this.length; i < n; i++)
            if (i in this && filter.call(that, v = this[i], i, this))
                other.push(v);
        return other;
    };
}

//Array diff
Array.prototype.diff = function(a) {
    return this.filter(function(i) {
        return !(a.indexOf(i) > -1);
    });
};

// Array Remove - By John Resig (MIT Licensed)
Array.prototype.remove = function(from, to) {
    var rest = this.slice((to || from) + 1 || this.length);
    this.length = from < 0 ? this.length + from : from;
    return this.push.apply(this, rest);
};

Array.prototype.removeByVal = function() {
    var what, a = arguments,
        L = a.length,
        ax;
    while (L && this.length) {
        what = a[--L];
        while ((ax = this.indexOf(what)) != -1) {
            this.splice(ax, 1);
        }
    }
    return this;
};

Array.prototype.insert = function(index, item) {
    this.splice(index, 0, item);
};

//Max val in array
Array.prototype.max = function() {
    var max = this[0];
    var len = this.length;
    for (var i = 1; i < len; i++)
        if (this[i] > max) max = this[i];
    return max;
};

// VB-like string
String.prototype.string = function(l) {
    var s = '',
        i = 0;
    while (i++ < l) {
        s += this;
    }
    return s;
};

String.prototype.trim = function() {
    var trimmed = this.replace(/^\s+|\s+$/g, '');
    return trimmed;
};
String.prototype.ltrim = function() {
    var trimmed = this.replace(/^\s+/g, '');
    return trimmed;
};
String.prototype.rtrim = function() {
    var trimmed = this.replace(/\s+$/g, '');
    return trimmed;
};

Array.prototype.clean = function(deleteValue) {
  for (var i = 0; i < this.length; i++) {
    if (this[i] == deleteValue) {
      this.splice(i, 1);
      i--;
    }
  }
  return this;
};

// Zero-Fill
String.prototype.zf = function(l) {
    return '0'.string(l - this.length) + this;
};
Number.prototype.zf = function(l) {
    return this.toString().zf(l);
};


// Capitalize first character
String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
};

String.prototype.startsWithArray = function(arr) {
    var curVal = this.toLowerCase();
    for (var i = 0; i < arr.length; i++) {
        if (curVal.indexOf(arr[i].toLowerCase()) == 0)
            return true;
    }
    return false;
};

// Date format prototype : http://www.codeproject.com/KB/scripting/dateformat.aspx
Date.prototype.format = function(f) {
    if (!this.valueOf())
        return ' ';

    var d = this;

    return f.replace(/(yyyy|mmmm|mmm|mm|dddd|ddd|dd|hf|hh|nn|ss|a\/p)/gi,
        function($1) {
            switch ($1.toLowerCase()) {
                case 'yyyy':
                    return d.getFullYear();
                case 'mmmm':
                    return gsMonthNames[d.getMonth()];
                case 'mmm':
                    return gsMonthNames[d.getMonth()].substr(0, 3);
                case 'mm':
                    return (d.getMonth() + 1).zf(2);
                case 'dddd':
                    return gsDayNames[d.getDay()];
                case 'ddd':
                    return gsDayNames[d.getDay()].substr(0, 3);
                case 'dd':
                    return d.getDate().zf(2);
                case 'hf':
                    return d.getHours();
                case 'hh':
                    return ((h = d.getHours() % 12) ? h : 12).zf(2);
                case 'nn':
                    return d.getMinutes().zf(2);
                case 'ss':
                    return d.getSeconds().zf(2);
                case 'a/p':
                    return d.getHours() < 12 ? 'AM' : 'PM';
            }
        }
    );
};

function getTextFromXML(doc) {
    var string = "";
    //for IE
    if ($.browser.msie && parseInt(jQuery.browser.version) == 10) {
        string = (new XMLSerializer()).serializeToString(doc);
    } else {
        if (window.ActiveXObject) {
            string = doc.xml;
        } else {
            string = (new XMLSerializer()).serializeToString(doc);
        }
    }
    return string;
}

// Adding in-case sensitive filter
jQuery.expr[':'].Contains = function(a,i,m){
    if (m[3].trim()=="" || m[3].trim()=="''")
        return true
    else
        return (a.textContent || a.innerText || "").toUpperCase().indexOf(m[3].toUpperCase())>=0;
};

//A Delay method based on timeout
var delay = (function() {
    var timer = 0;
    return function(callback, ms) {
        clearTimeout(timer);
        timer = setTimeout(callback, ms);
    };
})();

function lsTest(){
    var test = 'test';
    try {
        localStorage.setItem(test, test);
        localStorage.removeItem(test);
        return true;
    } catch(e) {
        return false;
    }
}

if (!lsTest()) {
    window.localStorage = {};
}

var crush = {
    ajaxCallURL: "agent",
    defaultRequestType: "POST",
    $loadingIndicator: false,
    $loadingIndicatorInline: false,
    storage: function(key, val) {
        if (typeof key != "undefined" && typeof val != "undefined") {
            localStorage[key] = val;
        }
        return localStorage[key];
    },
    middleEllipsis: function(str, len, separator) {
        separator = separator || "...";
        if (str.length > len) {
            var half = Math.ceil(len / 2);
            return $.trim(str.substr(0, half)) + "..." + $.trim(str.substr(str.length - half, str.length));
        } else
            return str;
    },
    block: function(element, append) {
        append = append || "";
        element.block({
            message: "<i class='spin fa fa-spinner'></i> Please Wait.." + append,
            centerX : false,
            centerY : false,
            css: {
                width: 120,
                top : '35%',
                left: '50%',
                'margin-left' : '-60px',
                border: 'none',
                padding: '10px',
                backgroundColor: '#000',
                '-webkit-border-radius': '10px',
                '-moz-border-radius': '10px',
                opacity: .5,
                color: '#fff',
                'text-align': 'left'
            }
        });
        return element;
    },
    rebuildSubItems: function(item, name) {
        if (item && name) {
            if (!item[name + "_subitem"]) {
                item[name + "_subitem"] = [];
            } else if (!item[name + "_subitem"].push) {
                var slab = item[name + "_subitem"];
                item[name + "_subitem"] = [slab];
            }
        }
    },
    getFormData : function($form){
        var unindexed_array = $form.serializeArray();
        var indexed_array = {};
        $.map(unindexed_array, function(n, i){
            indexed_array[n['name']] = n['value'];
        });
        return indexed_array;
    },
    unblock: function(element) {
        element.unblock();
        return element;
    },
    showLoading: function(inline, text) {
        var text = text || "<i class='spin fa fa-spinner'></i> Loading...";
        if (inline) {
            if (!this.$loadingIndicatorInline) {
                $("body").append('<div id="loadingIndicatorInline"></div>');
                this.$loadingIndicatorInline = $("#loadingIndicatorInline").hide();
            }
            this.$loadingIndicatorInline.html(text);
            this.$loadingIndicatorInline.show();
        } else {
            if (!this.$loadingIndicator) {
                $("body").append('<div class="modal" id="loadingIndicator"><div class="modal-dialog"><div class="modal-content"><div class="modal-body"></div></div></div></div>');
                this.$loadingIndicator = $("#loadingIndicator");
                this.$loadingIndicator.modal({
                    backdrop: 'static',
                    show: false
                });
            }
            this.$loadingIndicator.find(".modal-body").html(text);
            this.$loadingIndicator.modal('show');
        }
    },
    percOf: function(val, perc) {
        return (val * perc) / 100;
    },
    hideLoading: function(inline) {
        if (inline) {
            if (this.$loadingIndicatorInline) {
                this.$loadingIndicatorInline.hide();
            }
        } else {
            if (this.$loadingIndicator) {
                this.$loadingIndicator.modal('hide');
            }
        }
    },
    fixURLPath: function(path) {
        if (!path)
            return "/";
        if (path.lastIndexOf("/") != path.length - 1) {
            path = path + "/";
        }
        return path;
    },
    fixChars: function(val, reverse) {
        if(!val)
            return "";
        if(reverse)
            return val.replace(/{at}/g,"@").replace(/{colon}/g,":").replace(/{amp}/g,"&").replace(/{question}/g,"?").replace(/{slash}/g,"/").replace(/{backslash}/g,"\\").replace(/{hash}/g,"#").replace(/{quote}/g,"\"").replace(/{apos}/g,"'").replace(/{percent}/g,"\%").replace(/{plus}/g,"\+");
        else
            return val.replace(/@/g, "{at}").replace(/:/g, "{colon}").replace(/&/g, "{amp}").replace(/\?/g, "{question}").replace(/\//g, "{slash}").replace(/\\/g, "{backslash}").replace(/#/g, "{hash}").replace(/"/g, "{quote}").replace(/'/g, "{apos}").replace(/%/g, "{percent}").replace(/\+/g, "{plus}");
    },
    getStars: function(pass) {
        var str = "";
        var len = pass.length>6?6:pass.length;
        for (var i = 0; i < len; i++) {
            str += "*";
        }
        return str;
    },
    textEncode : function(val){
        return $("<div>").text(val).html();
    },
    encryptDecryptPass: function(pass, decrypt) {
        if(!pass)
            return "";
        var url = crush.ajaxCallURL;
        var pswd = !decrypt ? crush.fixChars(pass) : pass.replace(/\+/g, "{plus}");
        var data = {
            command: "encrypt_decrypt",
            pass: pswd,
            encrypt: !decrypt
        };
        var token = CrushClient.authenticationToken();
        if(token)
            data.auth_token = token;
        var _pass = $.ajax({
            type: "GET",
            url: url,
            async: false,
            data: data
        }).responseText;
        return crush.fixChars(_pass, true);
    },
    buildURL: function(protocol, user, pass, host, port, callback) {
        var url = {};
        if (user || pass) {
            if (pass){
                pass = crush.encryptDecryptPass(pass, true);
            }
            url.original = protocol + user + ":" + crush.fixChars(pass) + "@" + host;
            url.display = protocol + user + ":" + crush.getStars(pass) + "@" + host;
        } else {
            url.display = url.original = protocol + host;
        }
        if (port) {
            url.original += ":" + port;
            url.display += ":" + port;
        }
        callback(url);
    },
    data: {
        ajax: function(dataToSubmit, url, requestType, dataType) {
            requestType = requestType || crush.defaultRequestType;
            url = url || crush.ajaxCallURL;
            var nonAsync = dataToSubmit.notAsync;
            delete dataToSubmit.notAsync;
            var obj = {
                type: requestType,
                url: url,
                data: dataToSubmit
            };
            if(nonAsync){
                obj.async = false;
            }
            var token = CrushClient.authenticationToken();
            if(token)
                obj.data.auth_token = token;
            if (dataType)
                obj.dataType = dataType;
            return $.ajax(obj);
        },
        getValueFromJson: function(item, node) {
            if (item && item[node]) {
                return item[node];
            } else {
                return "";
            }
        }
    },
    loadTemplate: function(name) {
        var $q = jQuery.Deferred();
        crush.cachedTemplates = crush.cachedTemplates || {};

        function processTemplate(template) {
            if (template.indexOf('<!-- include:') == 0) {
                var partials = template.substring(('<!-- include:').length, template.indexOf("-->")).split(",");
                if (partials && partials.length > 0) {
                    var loadedCount = 0;
                    var loadedPartials = {};
                    for (var i = 0; i < partials.length; i++) {
                        var curPartial = partials[i];
                        (function(name) {
                            if (crush.cachedTemplates["Partial:" + name]) {
                                var partial = crush.cachedTemplates["Partial:" + name];
                                loadedPartials[name + ""] = partial;
                                loadedCount++;
                                if (loadedCount === partials.length) {
                                    render(loadedPartials);
                                }
                            } else {
                                $.get("/templates/partials/" + name + ".html", function(partial) {
                                    crush.cachedTemplates["Partial:" + name] = partial;
                                    loadedPartials[name + ""] = partial;
                                    loadedCount++;
                                    if (loadedCount === partials.length) {
                                        render(loadedPartials);
                                    }
                                });
                            }
                        })(curPartial);
                    }
                }

                function render(partials) {
                    if (partials) {
                        for (curPartial in partials) {
                            if (typeof curPartial === "string") {
                                var curPartialHTML = partials[curPartial];
                                var indexes = crush.indexesOf(template, 'import=' + curPartial);
                                var replaces = [];
                                if (indexes.length > 0) {
                                    for (var i = 0; i < indexes.length; i++) {
                                        var curInd = indexes[i];
                                        var toEval = "";
                                        var html = curPartialHTML + "";
                                        if (template.substr(curInd + ('import=' + curPartial).length).indexOf("{") == 0) {
                                            toEval = template.substring(curInd + ('import=' + curPartial).length, template.indexOf("}", curInd) + 1);
                                            var params = JSON.parse(toEval);
                                            if (params) {
                                                for (param in params) {
                                                    if (params[param].indexOf("RANDOM") >= 0) {
                                                        params[param] = params[param].replace(/RANDOM/g, crush.random());
                                                    }
                                                }
                                            }
                                            var curTemplate = Handlebars.compile(html);
                                            html = curTemplate(params);
                                        }
                                        replaces.push({
                                            find: 'import=' + curPartial + toEval,
                                            replace: html
                                        });
                                    }
                                    for (var i = 0; i < replaces.length; i++) {
                                        template = template.replace(replaces[i].find, replaces[i].replace);
                                    }
                                }
                            }
                        }
                    }
                    $q.resolve(template);
                }
            } else
                $q.resolve(template);
        }
        if (crush.cachedTemplates[name]) {
            processTemplate(crush.cachedTemplates[name]);
        } else {
            $.get("/templates/" + name + ".html", function(template) {
                crush.cachedTemplates[name] = template;
                processTemplate(template);
            });
        }
        return $q.promise();
    },
    indexesOf: function(str, find) {
        var result = [];
        for (i = 0; i < str.length; ++i) {
            if (str.substring(i, i + find.length) == find) {
                result.push(i);
            }
        }
        return result;
    },
    //Generate random code based on length, numeric flag restricts code to be numbers only
    random: function(length, numeric, possible) {
        length = length || 8;
        var randomId = "";
        possible = possible || "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        if (numeric) {
            possible = "0123456789";
        }
        for (var i = 0; i < length; i++)
            randomId += possible.charAt(Math.floor(Math.random() * possible.length));
        return randomId;
    },
    dottedQuadToInt: function(ip) {
        if (!ip) return false;
        var parts = ip.split('.', 4);
        if (parts.length < 4) return 0;
        var result = 0,
            base = 1;
        for (var i = 3; i >= 0; i--) {
            //validation
            if (parts[i].length == 0 || parts[i].length > 3) return -1;
            var segment = parseInt(parts[i], 10);
            if (isNaN(segment) || segment < 0 || segment > 255) return -1;

            //compute next segment
            result += base * segment;
            base = base << 8;
        }
        return result;
    },
    // Validate IP Address
    isValidIP: function(ip) {
        if (ip == "0.0.0.0") return true;
        ip = crush.dottedQuadToInt(ip);
        if (ip <= 0) return false;

        //mulitcast range:
        if (ip >= 3758096384 && ip <= 4026531839) return false;

        //alternate way to check multicast:
        if (ip >= crush.dottedQuadToInt('224.0.0.0') && ip <= crush.dottedQuadToInt('239.255.255.255')) return false;

        return true;
    },
    isValidAnyIPAddress: function(ip, allowedIPs) {
        if (!ip || ip.length == 0) return false;
        if (allowedIPs.has(ip.toLowerCase())) return true;
        ip = ip.split(".");
        var result = true;
        if (ip.length != 4) return false;
        for (var i = 0; i < ip.length; i++) {
            if (!crush.isNumeric(ip[i])) {
                result = false;
                i = ip.length;
            }
        }
        return result;
    },
    hasSpecialCharacters: function (input, charset){
        if(input)
        {
            charset = charset || "@#%&:=+?/";
            for (var i = 0; i < input.length; i++) {
                if (charset.indexOf(input.charAt(i)) != -1) {
                    return true;
                }
            }
        }
        return false;
    },
    //Validate numbers
    isNumeric: function(input) {
        return ((input - 0) == input && input.length > 0);
    },
    //Validate Email address
    isValidEmail: function(email) {
        return (email.indexOf("@") > 0 && email.lastIndexOf(".") > email.indexOf("@"));
    },
    formatBytes: function(bytes) {
        if ((bytes / 1024).toFixed(0) == 0) return bytes + " bytes";
        else if ((bytes / 1024 / 1024).toFixed(0) == 0) return (bytes / 1024).toFixed(1) + " KB";
        else if ((bytes / 1024 / 1024 / 1024).toFixed(0) == 0) return (bytes / 1024 / 1024).toFixed(1) + " MB";
        else if ((bytes / 1024 / 1024 / 1024 / 1024).toFixed(0) == 0) return (bytes / 1024 / 1024 / 1024).toFixed(1) + " GB";
        else if ((bytes / 1024 / 1024 / 1024 / 1024 / 1024).toFixed(0) == 0) return (bytes / 1024 / 1024 / 1024 / 1024).toFixed(1) + " TB";
    },
    formatTime: function(secs) {
        var remaining = "";
        if (!secs) return "";
        secs = secs.toString();
        if (secs.indexOf(".") < 0)
            secs = secs + ".0";
        secs = secs.substring(0, secs.indexOf(".")) * 1;
        var mins = (secs / 60) + ".0";
        mins = mins.substring(0, mins.indexOf(".")) * 1;
        if (mins > 0) {
            secs -= (mins * 60);
            remaining = mins + " min, " + secs + " secs";
        } else {
            if (secs < 0) {
                remaining = "Calculating";
            } else {
                remaining = secs + " secs";
            }
        }
        return remaining;
    },
    isValidDate: function(d) {
        if (Object.prototype.toString.call(d) !== "[object Date]")
            return false;
        return !isNaN(d.getTime());
    },
    isDate: function(str, uk) {
        var parms = str.split(/[\.\-\/]/);
        var yyyy = parseInt(parms[2], 10);
        var mm = parseInt(parms[1], 10);
        var dd = parseInt(parms[0], 10);
        if (uk) {
            mm = parseInt(parms[0], 10);
            dd = parseInt(parms[1], 10);
        }
        var date = new Date(yyyy, mm - 1, dd, 0, 0, 0, 0);
        return mm === (date.getMonth() + 1) &&
            dd === date.getDate() &&
            yyyy === date.getFullYear();
    },
    isDateTS: function(dt) {
        var isvalid = true;
        if (dt.length != 12)
            isvalid = false;

        if (!crush.isNumeric(dt))
            isvalid = false;

        if (isvalid) {
            var mm = parseInt(dt.substr(0, 2));
            var dd = parseInt(dt.substr(2, 2));
            var yyyy = parseInt(dt.substr(4, 4));
            var hh = parseInt(dt.substr(8, 2));
            var _mm = parseInt(dt.substr(10, 2));
            if (mm < 1 || mm > 12)
                isvalid = false;
            if (dd < 1 || dd > 31)
                isvalid = false;
            if (hh < 1 || hh > 24)
                isvalid = false;
            if (_mm < 1 || _mm > 60)
                isvalid = false;
        }
        return isvalid;
    },
    isDateTime: function(str) {
        if (!str || str.length == 0)
            return "";
        var errormessage = "";
        var isvalid = false;
        var dt = str;
        var parts = dt.split(" ");
        if (parts.length == 3) {
            var date = parts[0];
            var time = parts[1];
            var ampm = parts[2];
            if (ampm.length == 2 && (ampm.toLowerCase() == "am" || ampm.toLowerCase() == "pm")) {
                var validformatdate = /^\d{2}\/\d{2}\/\d{4}$/;
                var validformatdate2 = /^\d{2}\/\d{2}\/\d{2}$/;
                if (validformatdate.test(date) || validformatdate2.test(date)) {
                    var validformattime = /^\d{1,2}:\d{2}$/;
                    if (validformattime.test(time)) {
                        isvalid = true;
                    } else {
                        errormessage = "Time is not in the format HH:mm";
                    }
                } else {
                    errormessage = "Date is not in the format dd/MM/yyyy";
                }
            } else {
                errormessage = "DateTime does not have AM/PM at the end";
            }
        } else {
            errormessage = "DateTime is not in the format MM/dd/yyyy hh:mm am/pm";
        }
        return errormessage;
    },
    //Check if input starts with number
    startsWithNumber: function(input) {
        input = input.replace(/(^\d+)(.+$)/i, '$1');
        return !isNaN(input);
    },
    getInputValue: function(id, panel) {
        if (panel && $("#" + id, panel).length > 0) {
            var type = $("#" + id, panel).attr("type");
            type = type || "";
            type = type.toLowerCase();
            if (type == "checkbox" || type == "radio") {
                return $("#" + id, panel).is(":checked");
            } else {
                return $("#" + id, panel).val();
            }
        } else if ($("#" + id).length > 0) {
            var type = $("#" + id).attr("type");
            type = type || "";
            type = type.toLowerCase();
            if (type == "checkbox" || type == "radio") {
                return $("#" + id).is(":checked");
            } else {
                return $("#" + id).val();
            }
        } else {
            return "";
        }
    },
    substringMatcher : function(strs, elem, bookmarkPanel) {
      return function findMatches(q, cb) {
        var protocol = elem.closest(".settings-panel").find(".protocol-input").val();
        if(bookmarkPanel)
            protocol = elem.closest(".bookmark-panel").find(".protocol-input").val();
        var matches, substringRegex;
        // an array that will be populated with substring matches
        matches = [];
        // regex used to determine if a string contains the substring `q`
        substrRegex = new RegExp(q, 'i');
        // iterate through the pool of strings and for any string that
        // contains the substring `q`, add it to the `matches` array
        $.each(strs, function(i, str) {
          if (str.indexOf(protocol) == 0 && substrRegex.test(str.replace(protocol + "|", ""))) {
            matches.push(str.replace(protocol + "|", ""));
          }
        });
        cb(matches);
      };
    },
    sortObjectsRefKey: function(a, b) {
        if (a.key < b.key)
            return -1;
        if (a.key > b.key)
            return 1;
        return 0;
    },
    setPageTitle: function(title, append) {
        if (title) {
            if (append) {
                title = $(document).data("pageTitle") + " :: " + title;
            }
            document.title = title;
        } else if ($(document).data("pageTitle")) {
            document.title = $(document).data("pageTitle");
        }
    },
    queryString: function(name) {
        if (!name) return false;
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(window.location.search);
        if (results == null)
            return "";
        else
            return decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    isVisibleOnScreen: function(elem) {
        if (!elem || elem.length == 0) return;
        var docViewTop = $(window).scrollTop();
        var docViewBottom = docViewTop + $(window).height();
        var elemTop = $(elem).offset().top;
        var elemBottom = elemTop + $(elem).height();
        return ((elemBottom >= docViewTop) && (elemTop <= docViewBottom));
    },
    removeRangeSelection: function() {
        // Remove selection range, it messes up UI as all the text came between selection highlights in native browser selection manner
        if (window.getSelection) // Modern Browsers
        {
            var selection = window.getSelection();
            if (selection.removeAllRanges) {
                selection.removeAllRanges();
            }
        }
        if (document.getSelection) // IE
        {
            var selection = document.getSelection();
            if (selection.removeAllRanges) {
                selection.removeAllRanges();
            }
        }
    }
};

$.fn.isolatedScroll = function() {
    this.bind('mousewheel DOMMouseScroll', function(e) {
        var delta = e.wheelDelta || (e.originalEvent && e.originalEvent.wheelDelta) || -e.detail,
            bottomOverflow = this.scrollTop + $(this).outerHeight() - 15 - this.scrollHeight >= 0,
            topOverflow = this.scrollTop <= 0;

        if ((delta < 0 && bottomOverflow) || (delta > 0 && topOverflow)) {
            e.preventDefault();
        }
    });
    return this;
};
/**!
 * name: jQuery getChar
 * repository: https://github.com/bpeacock/key-to-charCode
 * @author Brian Peacock
 * @version 0.3
 * Copyright 2013, Brian Peacock
 * Licensed under the MIT license.
 */

(function($) {
    $.extend({
        getChar: function(e) {
            /*** Convert to Char Code ***/
            var code = e.which;
            //Ignore Shift Key events & arrows
            var ignoredCodes = {
                16: true,
                27: true,
                33: true,
                34: true,
                35: true,
                36: true,
                37: true,
                38: true,
                39: true,
                40: true,
                20: true,
                17: true,
                18: true,
                91: true
            };

            if (ignoredCodes[code] === true) {
                return false;
            }

            //These are special cases that don't fit the ASCII mapping
            var exceptions = {
                186: 59, // ;
                187: 61, // =
                188: 44, // ,
                189: 45, // -
                190: 46, // .
                191: 47, // /
                192: 96, // `
                219: 91, // [
                220: 92, // \
                221: 93, // ]
                222: 39, // '
                //numeric keypad
                96: '0'.charCodeAt(0),
                97: '1'.charCodeAt(0),
                98: '2'.charCodeAt(0),
                99: '3'.charCodeAt(0),
                100: '4'.charCodeAt(0),
                101: '5'.charCodeAt(0),
                102: '6'.charCodeAt(0),
                103: '7'.charCodeAt(0),
                104: '8'.charCodeAt(0),
                105: '9'.charCodeAt(0)
            };

            if (exceptions[code] !== undefined) {
                code = exceptions[code];
            }

            var ch = String.fromCharCode(code);

            /*** Handle Shift ***/
            if (e.shiftKey) {
                var special = {
                    1: '!',
                    2: '@',
                    3: '#',
                    4: '$',
                    5: '%',
                    6: '^',
                    7: '&',
                    8: '*',
                    9: '(',
                    0: ')',
                    ',': '<',
                    '.': '>',
                    '/': '?',
                    ';': ':',
                    "'": '"',
                    '[': '{',
                    ']': '}',
                    '\\': '|',
                    '`': '~',
                    '-': '_',
                    '=': '+'
                };

                if (special[ch] !== undefined) {
                    ch = special[ch];
                }
            } else {
                ch = ch.toLowerCase();
            }

            return ch.charCodeAt(0);
        }
    });
})(jQuery);

/*!
 * jQuery TextChange Plugin
 * http://www.zurb.com/playground/jquery-text-change-custom-event
 *
 * Copyright 2010, ZURB
 * Released under the MIT License
 */
(function(a) {
    a.event.special.textchange = {
        setup: function() {
            a(this).data("lastValue", this.contentEditable === "true" ? a(this).html() : a(this).val());
            a(this).bind("keyup.textchange", a.event.special.textchange.handler);
            a(this).bind("cut.textchange paste.textchange input.textchange", a.event.special.textchange.delayedHandler);
        },
        teardown: function() {
            a(this).unbind(".textchange");
        },
        handler: function() {
            a.event.special.textchange.triggerIfChanged(a(this));
        },
        delayedHandler: function() {
            var b = a(this);
            setTimeout(function() {
                    a.event.special.textchange.triggerIfChanged(b);
                },
                25);
        },
        triggerIfChanged: function(b) {
            var c = b[0].contentEditable === "true" ? b.html() : b.val();
            if (c !== b.data("lastValue")) {
                b.trigger("textchange", b.data("lastValue"));
                b.data("lastValue", c);
            }
        }
    };
    a.event.special.hastext = {
        setup: function() {
            a(this).bind("textchange", a.event.special.hastext.handler);
        },
        teardown: function() {
            a(this).unbind("textchange", a.event.special.hastext.handler);
        },
        handler: function(b, c) {
            c === "" && c !== a(this).val() && a(this).trigger("hastext");
        }
    };
    a.event.special.notext = {
        setup: function() {
            a(this).bind("textchange",
                a.event.special.notext.handler);
        },
        teardown: function() {
            a(this).unbind("textchange", a.event.special.notext.handler);
        },
        handler: function(b, c) {
            a(this).val() === "" && a(this).val() !== c && a(this).trigger("notext");
        }
    };
})(jQuery);

$.ui.plugin.add("resizable", "alsoResizeReverse", {
    start: function() {
        var that = $(this).resizable( "instance" ),
            o = that.options;

        $(o.alsoResizeReverse).each(function() {
            var el = $(this);
            el.data("ui-resizable-alsoresizeReverse", {
                width: parseInt(el.width(), 10), height: parseInt(el.height(), 10),
                left: parseInt(el.css("left"), 10), top: parseInt(el.css("top"), 10)
            });
        });
    },

    resize: function(event, ui) {
        var that = $(this).resizable( "instance" ),
            o = that.options,
            os = that.originalSize,
            op = that.originalPosition,
            delta = {
                height: (that.size.height - os.height) || 0,
                width: (that.size.width - os.width) || 0,
                top: (that.position.top - op.top) || 0,
                left: (that.position.left - op.left) || 0
            };

        $(o.alsoResizeReverse).each(function() {
            var el = $(this), start = $(this).data("ui-resizable-alsoresize-reverse"), style = {},
                css = el.parents(ui.originalElement[0]).length ?
                    [ "width", "height" ] :
                    [ "width", "height", "top", "left" ];

            $.each(css, function(i, prop) {
                var sum = (start[prop] || 0) - (delta[prop] || 0);
                if (sum && sum >= 0) {
                    style[prop] = sum || null;
                }
            });

            el.css(style);
        });
    },

    stop: function() {
        $(this).removeData("resizable-alsoresize-reverse");
    }
});