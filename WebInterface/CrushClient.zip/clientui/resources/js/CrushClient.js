/*!
 * CrushClient Web GUI
 *
 * http://crushFTP.com/
 *
 * Copyright @ CrushFTP
 *
 * Date: Mon, July 27 2015
 *
 * Author: Vipul Limbachiya
 *
 * http://UrvaTechlabs.com
 */
var CrushClient = (function() {
    //Variable declaration
    var logInterval, statsInterval, queueInterval, loadedClientName, lastLoadedClientName, loadedTab, clientLog = {},
        dtInstance, isTransferInProgress, bookmarksData = {},
        restoringClients, liveClients = [],
        forceLogReload, prefs, authenticationToken, pingInterval, curPingStatus, offlinePopup,
        scheduleTime = "8:00 AM",
        scheduleTimeList = [],
        statsSummaryInterval, totalCompleted, windowHeight = 0,
        windowWidth = 0;

    window.tabInstances = {};

    var clientTabs = $("#client-tabs");

    function pingServer() {
        $.when(crush.data.ajax({
            command: "ping"
        })).done(function(xhr) {
            curPingStatus = $.trim(xhr);
            if (offlinePopup) {
                offlinePopup.find(".close").click();
                offlinePopup = false;
                curPingStatus = "";
                $('#offlineNotice').hide();
                window.location.reload();
            }
        }).fail(function(err) {
            if (!offlinePopup) {
                $('#offlineNotice').show();
                offlinePopup = bootbox.dialog({
                    title: "<i class='fa fa-chain-broken fa-fw'></i> CrushClient is offline or not reachable",
                    message: "<div>The CrushClient agent is not running, please restart your CrushClient agent.</div>",
                    size: "medium",
                    value: "",
                    onEscape: true,
                    backdrop: true
                });
            }
        });
    }

    function refreshStatsSummary() {
        if (loadedClientName) {
            var name = loadedClientName;
            $.when(crush.data.ajax({
                command: "stats_summary",
                client: name
            })).done(function(xhr) {
                if (loadedClientName == name) {
                    if (xhr) {
                        var data = {};
                        var items = xhr.split(";");
                        for (var i = 0; i < items.length; i++) {
                            if (items[i]) {
                                var curItems = items[i].split("=");
                                if (curItems && curItems.length > 1) {
                                    var key = curItems[0];
                                    var val = curItems[1];
                                    if (key && key.toLowerCase().indexOf("folder") >= 0)
                                        val = parseInt(val);
                                    else if (key && key.toLowerCase().indexOf("bytes") >= 0)
                                        val = crush.formatBytes(parseInt(val));
                                    data[key] = val;
                                }
                            }
                        }
                        totalCompleted = 0;
                        var uc = parseInt(data.upload_count || 0);
                        var suc = parseInt(data.upload_skipped_count || 0);
                        var dc = parseInt(data.download_count || 0);
                        var sdc = parseInt(data.download_skipped_count || 0);
                        totalCompleted = uc + suc + dc + sdc;
                        var statsSummary = $('#statsSummary');
                        if (typeof data.upload_count != "undefined") {
                            statsSummary.find(".upload").show();
                            statsSummary.show().css("display", "inline-block");
                            statsSummary.find(".uploadCount").text(data.upload_count);
                            statsSummary.find(".uploadFolders").text(data.upload_folders || 0);
                            statsSummary.find(".uploadBytes").text(data.upload_bytes);
                        } else {
                            statsSummary.find(".upload").hide();
                        }

                        if (typeof data.download_count != "undefined") {
                            statsSummary.find(".download").show();
                            statsSummary.show().css("display", "inline-block");
                            statsSummary.find(".downloadCount").text(data.download_count);
                            statsSummary.find(".downloadFolders").text(data.download_folders || 0);
                            statsSummary.find(".downloadBytes").text(data.download_bytes);
                        } else {
                            statsSummary.find(".download").hide();
                        }

                        if (typeof data.upload_skipped_bytes != "undefined") {
                            statsSummary.find(".upload-skipped").show();
                            statsSummary.show().css("display", "inline-block");
                            statsSummary.find(".uploadSkippedCount").text(data.upload_skipped_count);
                            statsSummary.find(".uploadSkippedBytes").text(data.upload_skipped_bytes);
                        } else {
                            statsSummary.find(".upload-skipped").hide();
                        }

                        if (typeof data.download_skipped_count != "undefined") {
                            statsSummary.find(".download-skipped").show();
                            statsSummary.show().css("display", "inline-block");
                            statsSummary.find(".downloadSkippedCount").text(data.upload_skipped_count);
                            statsSummary.find(".downloadSkippedBytes").text(data.upload_skipped_bytes);
                        } else {
                            statsSummary.find(".download-skipped").hide();
                        }

                        if (typeof data.total_time != "undefined") {
                            statsSummary.find(".total-time").show();
                            statsSummary.show().css("display", "inline-block");
                            statsSummary.find(".totalTimeValue").text(data.total_time || 0);
                            statsSummary.find(".totalSpeedValue").text(data.total_speed || 0);
                        } else {
                            statsSummary.find(".total-time").hide();
                        }
                    }
                }
            });
        }
    }

    function prepare(pass) {
        window.onbeforeunload = function() {
            if ($.trim(curPingStatus) == "true") {
                return "Closing this page will abort all active connections and exit the agent.  Are you sure you want to continue?";
            }
        };
        pingInterval = setInterval(function() {
            pingServer();
        }, 10000);
        pingServer();
        statsSummaryInterval = setInterval(function() {
            refreshStatsSummary();
        }, 5000);
        refreshStatsSummary();
        authenticate(pass, function(data) {
            var status = data.toString();
            if (status.toLowerCase().indexOf("success:") == 0) {
                authenticationToken = status.split(":")[1];
                loadPartials(function() {
                    loadPrefs(function() {
                        init();
                    });
                });
            } else {
                $("body").removeClass('loading');
                function validatePassword() {
                    var promptOptions = {
                        title: "<i class='fa fa-key fa-fw'></i>  Please enter master password : ",
                        inputType: "password",
                        closeButton: false,
                        onEscape: function() {},
                        className: "master-pass-form",
                        buttons: {
                            confirm: {
                                label: "Validate"
                            }
                        },
                        callback: function(result) {
                            if (result === null) {
                                validatePassword();
                            } else {
                                prepare($.trim(result) + "");
                            }
                        }
                    };
                    bootbox.prompt(promptOptions);
                }
                if (pass) {
                    bootbox.alert("Entered password is not valid.", function() {
                        validatePassword();
                    });
                } else
                    validatePassword();
            }
        });
    }

    function init(pass) {
        crush.showLoading(true);
        getLiveClientInfo(function(xml) {
            crush.hideLoading(true);
            bindLayoutEvents();
            restoreClients();
        });

        if (crush.storage("collapsed-right-sidebar") == "true")
            $('body').addClass("collapsed-right-sidebar");
        if (crush.storage("bottom-panel-visible") == "true")
            $('body').removeClass("bottom-panel-hidden");
    }

    function restoreClients() {
        var clients = liveClients || [];
        if (clients.length > 0) {
            restoringClients = true;
            lastLoadedClientName = crush.storage("loadedClientName");
            for (var i = 0; i < clients.length; i++) {
                var curClient = clients[i];
                if (!clientLog[curClient]) {
                    clientLog[curClient] = {};
                    clientLog[curClient].logData = [];
                }
                if (i == 0) {
                    createClient($('#tab-1').attr("clientName", curClient), false, curClient, true);
                    clientTabs.find("li:first").find(".close-tab").click(function() {
                        closeTab($(this));
                    });
                } else
                    addNewClient(curClient);
            }
            restoringClients = false;
        } else {
            loadedTab = $("#tab-1");
            createClient($('#tab-1'));
            clientTabs.find("li:first").find(".close-tab").click(function() {
                closeTab($(this));
            });
        }
    }

    function reconnectClient(clientName, prefix, callback) {
        prefix = prefix == "l" ? "l" : "";
        if (tabInstances[clientName] && tabInstances[clientName].info && !tabInstances[clientName].reconnectTried) {
            var curInstance = tabInstances[clientName];
            var url = prefix == "l" ? curInstance.info.source.vrl : curInstance.info.destination.vrl;
            if (!url) {
                callback();
                return;
            }
            var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
            var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
            curInstance.reconnectTried = true;
            var cmd = runCommand({
                clientName: clientName,
                command: prefix + "discon"
            });
            cmd.promise.then(function() {
                changeServerStatus(clientName, prefix);
                crush.block(listPanel.parent(), "<br><div class='text-center'><a class='btn' href='javascript:void(0);'><i class='fa fa-close'></i> Cancel</a></div>");
                configureConnection(url, serverData, clientName, prefix, function() {
                    var cmd = runCommand({
                        clientName: clientName,
                        command: prefix + "connect \"" + url + "\"",
                        displayCommand: prefix + "connect \"" + url + "\""
                    });
                    cmd.promise.then(function(status) {
                        afterConnect("true", clientName, prefix, "/", function() {
                            callback(true);
                        });
                    });
                    listPanel.parent().find(".blockMsg").find("a").click(function() {
                        cmd.xhr.abort();
                    });
                });
            });
            setTimeout(function() {
                delete curInstance.reconnectTried;
            }, 5000);
        } else {
            if (tabInstances[clientName] && tabInstances[clientName].reconnectTried) {
                $.notify({
                    icon: 'glyphicon glyphicon-warning-sign',
                    message: 'Connection attempt failed.'
                }, {
                    type: 'danger',
                    timer: 1000
                });
            }
            callback();
        }
    }

    function isDotItemsHidden(clientName, prefix) {
        var pref = crush.storage(clientName + "_" + prefix + "HideDotItems");
        return typeof pref == "undefined" || pref == "true" ? true : false;
    }

    function getClientInfo(clientName, callback) {
        $.when(crush.data.ajax({
            command: "info",
            client: clientName
        })).done(function(xhr) {
            callback(xhr);
        }).fail(function(err) {
            callback();
        });
    }

    function authenticate(password, callback) {
        var data = {
            command: "authenticate"
        }
        if (password)
            data.password = password;
        $.when(crush.data.ajax(data)).done(function(xhr) {
            callback(xhr);
        }).fail(function(err) {
            callback("");
        });
    }

    function changePass(oldPass, newPassword, callback) {
        var data = {
            command: "set_password",
            password: oldPass,
            new_password: newPassword
        };
        $.when(crush.data.ajax(data)).done(function(xhr) {
            callback(xhr);
        }).fail(function(err) {
            callback();
        });
    }

    function addNewClient(clientName, tabName, callback) {
        var random = crush.random();
        var lastElem = clientTabs.find("li:last");
        var clientIndex = clientTabs.find("li.nav").length;
        tabName = tabName || 'Client ' + clientIndex;
        lastElem.before('<li class="nav"><a tabindex="0" href="#tab-' + random + '" data-toggle="tab" clientLink="' + random + '" class="tabs-top-button"> <span class="tab-name">'+tabName+'</span> <i class="fa close-tab fa-close fa-fw"></i></a></li>');
        lastElem.prev().find(".close-tab").click(function() {
            closeTab($(this));
        });
        lastElem.prev().find(".edit-name").click(function() {
            renameTab($(this).parent());
        });
        $("#actibeTabs").append('<div class="tab-pane" id="tab-' + random + '"></div>');
        if (!restoringClients) {
            lastElem.prev().find("a").click().focus().blur();
        }
        createClient($('#tab-' + random), random, clientName, false, callback);
        $('a[data-toggle="tab"]', clientTabs).unbind("shown.bs.tab").bind('shown.bs.tab', function(e) {
            loadedTab = $($(e.target).attr("href"));
            loadedClientName = loadedTab.attr("clientName");
            crush.storage("loadedClientName", loadedClientName);
            startPolling(loadedClientName);

            // setTimeout(function() {
            //     $(".tab-content:visible .action-side-bar:visible .panel-default").height($(".server-panel-1:visible").height() - 25)
            // }, 10);
        });
    }

    function bindLayoutEvents() {
        $('[data-toggle="tooltip"]').tooltip({
            container: "body"
        });

        $("#newClient").unbind().click(function() {
            addNewClient();
        });
        clientTabs.find(".edit-name").unbind().click(function() {
            renameTab($(this).parent());
        });
        $('a[data-toggle="tab"]', clientTabs).unbind("shown.bs.tab").bind('shown.bs.tab', function(e) {
            loadedTab = $($(e.target).attr("href"));
            loadedClientName = loadedTab.attr("clientName");
            startPolling(loadedClientName);
            // setTimeout(function() {
            //     $(".tab-content:visible .action-side-bar:visible .panel-default").height($(".server-panel-1:visible").height() - 25)
            // }, 10);
        });

        $('#schedulesLink').unbind().click(function() {
            schedules.show();
            return false;
        });

        $('#bookmarksLink').unbind().click(function() {
            bookmarks.show();
            return false;
        });

        $('#managedServersLink').unbind().click(function() {
            servers.show();
            return false;
        });

        $('#helpLink').unbind().click(function() {
            var dlg = bootbox.dialog({
                title: "<i class='fa fa-question-circle fa-fw'></i> About : ",
                message: $('#helpPanel').html(),
                size: "large",
                value: "",
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: "OK",
                        className: "btn-default cancel",
                        callback: function() {}
                    }
                }
            });
            return false;
        });

        $('#generalSettingsLink').unbind().click(function() {
            settings.show({
                settings: prefs,
                callback: function(data) {
                    prefs = $.extend(prefs, data);
                    savePrefs();
                    fluidUI.resize();
                }
            });
            return false;
        });

        $('#userConfigLink').unbind().click(function() {
            var settingsDialog;
            bootbox.dialog({
                title: "<i class='fa fa-user fa-fw'></i> User Settings",
                message: $('#userSettingsDialog').html(),
                value: "",
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: "Cancel",
                        className: "btn-default cancel",
                        callback: function() {}
                    },
                    ok: {
                        label: "OK",
                        className: "btn-success save",
                        callback: function() {
                            var pass = settingsDialog.find("#server_pass").val();
                            var confirmPass = settingsDialog.find("#server_pass_confirm").val();
                            var existingPass = settingsDialog.find("#server_current_pass").val();
                            if (pass != confirmPass) {
                                bootbox.alert("Passwords does not match");
                                setTimeout(function() {
                                    settingsDialog.find("#server_pass_confirm").focus().select();
                                }, 200);
                                return false;
                            } else {
                                changePass(existingPass, confirmPass, function(data) {
                                    var status = data.toString();
                                    if (status.toLowerCase().indexOf("success:") == 0) {
                                        var msg = status.split(":")[1];
                                        $.notify({
                                            icon: 'glyphicon glyphicon-check',
                                            message: msg
                                        }, {
                                            type: 'success',
                                            timer: 3000
                                        });
                                        settingsDialog.closest(".modal-content").find(".cancel").trigger("click");
                                    } else {
                                        var msg = status.split(":")[1];
                                        $.notify({
                                            icon: 'glyphicon glyphicon-check',
                                            message: msg
                                        }, {
                                            type: 'danger',
                                            timer: 3000
                                        });
                                    }
                                });
                                return false;
                            }
                        }
                    }
                }
            });
            settingsDialog = $('.bootbox-body .user-settings');
            settingsDialog.find(".remove-pass").removeAttr("checked").bind("change", function() {
                if ($(this).is(":checked"))
                    settingsDialog.find(".new-pass").slideUp("fast").find("input").val("");
                else
                    settingsDialog.find(".new-pass").slideDown("fast").find("#server_pass").focus();
            });
            setTimeout(function() {
                settingsDialog.find("input:visible:first").focus();
            }, 500);
            settingsDialog.find("input").bind("keydown", function(evt) {
                if (evt.which == 13) {
                    settingsDialog.closest(".modal-content").find(".save").trigger("click");
                    evt.stopPropagation();
                    evt.preventDefault();
                    return false;
                } else if (evt.which == 27) {
                    settingsDialog.closest(".modal-content").find(".cancel").trigger("click");
                }
            });
            return false;
        });
    }

    function getLiveClientInfo(cb) {
        $.when(crush.data.ajax({
            command: "list"
        })).done(function(xhr) {
            if (xhr) {
                liveClients = xhr.split("\n");
                for (var i = 0; i < liveClients.length; i++) {
                    liveClients[i] = $.trim(liveClients[i]);
                }
            }
            liveClients.clean("").reverse();
            loadPrefs(function() {
                if (cb)
                    cb(xhr);
            });
        });
    }

    function loadPartials(cb) {
        var partialsToLoad = ["bookmarks", "schedules", "servers", "cipher-control", "general-settings"];
        var loaded = 0;
        for (var i = 0; i < partialsToLoad.length; i++) {
            $.get("/templates/partials/" + partialsToLoad[i] + ".html", function(partial) {
                $('#dialog-placeholder').append(partial);
                loaded++;
                if (loaded == partialsToLoad.length)
                    cb();
            });
        }
    }

    function loadPrefs(cb) {
        $.when(crush.data.ajax({
            command: "load_prefs"
        })).done(function(xhr) {
            prefs = $.xml2json(xhr);
            crush.rebuildSubItems(prefs.bookmarks, "bookmarks");
            crush.rebuildSubItems(prefs.schedules, "schedules");
            crush.rebuildSubItems(prefs.servers, "servers");
            var bookmarks = prefs.bookmarks ? prefs.bookmarks.bookmarks_subitem : [];
            bookmarksData.hosts = bookmarksData.hosts || [];
            bookmarksData.ports = bookmarksData.ports || [];
            if (bookmarks.length > 0) {
                for (var i = 0; i < bookmarks.length; i++) {
                    var curBm = bookmarks[i];
                    if (!bookmarksData.hosts.has(curBm.protocol + "|" + curBm.host))
                        bookmarksData.hosts.push(curBm.protocol + "|" + curBm.host);
                    if (!bookmarksData.ports.has(curBm.protocol + "|" + curBm.port))
                        bookmarksData.ports.push(curBm.protocol + "|" + curBm.port);
                }
            }
            bookmarksData.hosts.clean("");
            bookmarksData.ports.clean("");
            prefs.bookmarks = bookmarks;
            var schedules = prefs.schedules ? prefs.schedules.schedules_subitem : [];
            prefs.schedules = schedules;
            var servers = prefs.servers ? prefs.servers.servers_subitem : [];
            prefs.servers = servers;
            if(prefs.client_view_mode && prefs.client_view_mode == "advanced"){
                $('body').removeClass('dummymode');
            }
            else
            {
                $('body').addClass('dummymode');
            }
            if (cb)
                cb();
        });
        $.when(crush.data.ajax({
            command: "version"
        })).done(function(version) {
            if (version) {
                $('#version-info').show().find(".version-number").text(version);
                $('#helpPanel').find(".version").text(version);
            }
        });
    }

    function savePrefs(params) {
        var xml = ['<?xml version="1.0" encoding="UTF-8"?><prefs type="properties">'];
        params = params || {};
        xml.push(bookmarks.XML(params.newBookmark));
        xml.push(schedules.XML(params.newSchedule));
        xml.push(servers.XML(params.newServer));
        for (var item in prefs) {
            if (typeof prefs[item] == "string" && item != "type") {
                xml.push("<" + item + ">" + prefs[item] + "</" + item + ">");
            }
        }
        xml.push('</prefs>');
        $.when(crush.data.ajax({
            command: "save_prefs",
            prefs: xml.join("\r\n")
        })).done(function(xhr) {
            loadPrefs(params.callback);
        });
    }

    function renameTab(elem) {
        var curName = elem.find("span.tab-name").text();
        var clientName = elem.attr("clientName");
        bootbox.prompt({
            title: "Rename :",
            value: curName,
            callback: function(result) {
                if (result) {
                    result = $.trim(result);
                    if (result !== curName) {
                        elem.find("span.tab-name").text(result);
                        tabInstances[clientName].name = result;
                    }
                }
            }
        });
    }

    function clientSettings(elem) {
        var elemLink = elem.closest("a");
        var clientName = elemLink.attr("clientName");
        var clientLink = elemLink.attr("clientLink");
        var tabInfo = tabInstances[clientName] || {};
        var maxThreads = tabInfo.maxThreads || 5;
        var displayName = elem.closest('a').find(".tab-name").text();
        var settingsDialog;
        bootbox.dialog({
            title: "<i class='fa fa-user fa-fw'></i> Client Settings",
            message: $('#clientSettingsDialog').html(),
            value: "",
            onEscape: true,
            backdrop: true,
            buttons: {
                cancel: {
                    label: "Cancel",
                    className: "btn-default cancel",
                    callback: function() {}
                },
                ok: {
                    label: "OK",
                    className: "btn-success save",
                    callback: function() {
                        var name = settingsDialog.find("#client_name").val();
                        elem.closest('a').find(".tab-name").text(name);
                        var threads = settingsDialog.find("#max_threads").val();
                        tabInfo.maxThreads = threads;
                        try {
                            tabInstances[clientName].maxThreads = threads;
                        } catch (ex) {}
                        if (maxThreads != threads) {
                            crush.showLoading(true);
                            var cmd = runCommand({
                                clientName: clientName,
                                command: "set max_threads \"" + threads + "\""
                            });
                            cmd.promise.then(function() {
                                crush.hideLoading(true);
                            });
                        }
                    }
                }
            }
        });
        settingsDialog = $('.bootbox-body .client-settings');
        settingsDialog.find("#client_name").val(displayName);
        settingsDialog.find("#max_threads").val(maxThreads);
        return false;
    }

    function closeTab(elem) {
        bootbox.confirm("Are you sure you want to close this tab?", function(result) {
            if (result) {
                var elemLink = elem.closest("a");
                var clientName = elemLink.attr("clientName");
                var clientLink = elemLink.attr("clientLink");
                crush.showLoading(true);
                $.when(crush.data.ajax({
                    command: "destroy",
                    client: clientName
                })).done(function(xhr) {
                    delete tabInstances[clientName];
                    clientLink = clientLink == "Home" ? "1" : clientLink;
                    $("#tab-" + clientLink).remove();
                    elemLink.remove();
                    clientTabs.find("a[clientname]:last").click();
                }).fail(function(err) {}).always(function() {
                    crush.hideLoading(true);
                });
            }
        });
        return false;
    }

    function confirmExit() {
        if (isTransferInProgress) {
            return "There are items being transferred, If you navigate away, you might interrupt the transfer. Do you want to continue?";
        }
    }

    function createClient(panel, clientLink, clientName, isRestoring, callback) {
        $('body').addClass('loading');
        crush.showLoading(true);
        $.when(crush.loadTemplate("tab-content")).done(function(template) {
            panel.html(template).find(".table").bootstrapTable();
            prepareClient(panel, clientLink, clientName, function(elm) {
                if (lastLoadedClientName && isRestoring) {
                    clientTabs.find("a[clientname='" + lastLoadedClientName + "']").click();
                    loadedClientName = lastLoadedClientName;
                    loadedTab = $("#tab-" + clientLink);
                } else {
                    crush.showLoading(true);
                }
                clientTabs.find("li.active").find("a").trigger('shown.bs.tab');
                if (callback)
                    callback(panel, clientName);
            }, isRestoring);
            crush.hideLoading(true);
        });
    }

    function prepareClient(panel, clientLink, clientName, callback, isRestoring) {
        clientLink = clientLink || "Home";
        crush.showLoading(true);
        bookmarksData.hosts = bookmarksData.hosts || [];
        bookmarksData.ports = bookmarksData.ports || [];
        var lServerPanel = panel.find(".server-panel-1");
        var rServerPanel = panel.find(".server-panel-2");
        clientName = clientName || "Client_" + crush.random();
        tabInstances[clientName] = tabInstances[clientName] || {};
        tabInstances[clientName] = $.extend({
            panel: panel,
            leftServerPanel: lServerPanel,
            leftListPanel: lServerPanel.find(".list-group:first"),
            rightServerPanel: rServerPanel,
            rightListPanel: rServerPanel.find(".list-group:first"),
            leftServerData: {},
            rightServerData: {}
        }, tabInstances[clientName]);
        var curInstance = tabInstances[clientName];
        var statsTemplate = panel.find(".actions").find(".template");
        curInstance.statsTemplate = Handlebars.compile(statsTemplate.html());
        statsTemplate.remove();

        function afterClientCreated() {
            bindEvents(clientName);
            $("input[id$='hide_dot_items']", panel).each(function() {
                var elm = $(this);
                var prefix = $(this).hasClass('left-server') ? "l" : "";
                if (isDotItemsHidden(clientName, prefix))
                    elm.attr("checked", "checked");
                else
                    elm.removeAttr("checked");
            });

            $("input[id$='verifyHost']", panel).bind("change", function() {
                var parent = $(this).parent().parent();
                if ($(this).is(":checked")) {
                    parent.next().show().find("input").focus();
                } else {
                    parent.next().hide();
                }
            });

            $("input[id$='PasswordBaseEncrypt']", panel).bind("change", function() {
                var parent = $(this).closest(".row");
                if ($(this).is(":checked")) {
                    parent.find(".password-based-encryption-input").show().find("input").focus();
                } else {
                    parent.find(".password-based-encryption-input").hide();
                }
            });

            $("input[id$='host']", panel).each(function() {
                var elm = $(this);
                elm.typeahead({
                    minLength: 0,
                    hint: true,
                    highlight: true
                }, {
                    name: 'hosts',
                    limit: 10,
                    source: crush.substringMatcher(bookmarksData.hosts, elm)
                });
            });
            $("input[id$='port']", panel).each(function() {
                var elm = $(this);
                elm.typeahead({
                    minLength: 0,
                    hint: true,
                    highlight: true
                }, {
                    name: 'hosts',
                    limit: 10,
                    source: crush.substringMatcher(bookmarksData.ports, elm)
                });
            });
            panel.attr("clientName", clientName);
            if (!restoringClients && !isRestoring) {
                loadedClientName = clientName;
                if (!clientLog[clientName]) {
                    clientLog[clientName] = {};
                    clientLog[clientName].logData = [];
                }
                startPolling(clientName);
            }
            if (tabInstances[clientName]) {
                var curInstance = tabInstances[clientName];
                var cmd = runCommand({
                    clientName: clientName,
                    command: "lpwd"
                });
                cmd.promise.then(function(status) {
                    if ($.trim(status).length > 0 && $.trim(status).toLowerCase() != "not connected.") {
                        var dir = $.trim(status);
                        dir = dir.substr(1, dir.lastIndexOf("\"") - 1);
                        afterConnect("true", clientName, "l", dir);
                    }
                });
                var cmd = runCommand({
                    clientName: clientName,
                    command: "pwd"
                });
                cmd.promise.then(function(status) {
                    if ($.trim(status).length > 0 && $.trim(status).toLowerCase() != "not connected.") {
                        var dir = $.trim(status);
                        dir = dir.substr(1, dir.lastIndexOf("\"") - 1);
                        afterConnect("true", clientName, "", dir);
                    }
                });
            }
            if (callback)
                callback(clientTabs.find('a[clientLink="' + clientLink + '"]').attr("clientName", clientName));
            else
                clientTabs.find('a[clientLink="' + clientLink + '"]').attr("clientName", clientName);
            setTimeout(function(){
                fluidUI.resize();
                setTimeout(function(){
                    $('body').removeClass('loading');
                }, 100);
            }, 200);
        }
        if (liveClients.has(clientName)) {
            getClientInfo(clientName, function(xhr) {
                if (xhr) {
                    var info = $.xml2json(xhr);
                    if (tabInstances[clientName]) {
                        tabInstances[clientName].info = info;

                        function bindInfo(serverPanel, dataItem) {
                            if (serverPanel && dataItem) {
                                var panelID = serverPanel.find(".server-settings:first").attr("id");
                                try {
                                    var _url;
                                    if (dataItem.vrl)
                                        _url = new URI(dataItem.vrl);
                                    else
                                        _url = new URL(dataItem.vrl);
                                    dataItem.protocol = _url.protocol() || "file:";
                                    dataItem.protocol += "://";
                                    dataItem.protocol = dataItem.protocol.toLowerCase();
                                    dataItem.port = _url.port();
                                    dataItem.host = _url.host();
                                    if (dataItem.host.endsWith(":" + dataItem.port)) {
                                        dataItem.host = dataItem.host.replace(":" + dataItem.port, "");
                                    }
                                    if (dataItem.host.endsWith(":" + dataItem.port)) {
                                        dataItem.host = dataItem.host.replace(":" + dataItem.port, "");
                                    }
                                } catch (ex) {}
                                setTimeout(function(){
                                    $('#' + panelID + '_protocol', serverPanel).val(dataItem.protocol || "file://").trigger('change', [true]);
                                    $('#' + panelID + '_host', serverPanel).val(dataItem.host || "");
                                    $('#' + panelID + '_port', serverPanel).val(dataItem.port || "").typeahead('val', dataItem.port || "");
                                    $('#' + panelID + '_username', serverPanel).val(dataItem.username || "");
                                    $('#' + panelID + '_password', serverPanel).val(dataItem.password || "");
                                }, 100);
                            }
                        }
                        bindInfo(curInstance.leftServerPanel, info.source);
                        bindInfo(curInstance.rightServerPanel, info.destination);
                    }
                }
                afterClientCreated(true);
            });
        } else {
            $.when(crush.data.ajax({
                command: "create",
                client: clientName
            })).done(function(xhr) {
                afterClientCreated();
            }).fail(function(err) {}).always(function() {
                crush.hideLoading(true);
            });
        }
    }

    function afterConnect(status, clientName, prefix, path, callback) {
        prefix = prefix == "l" ? "l" : "";
        var curInstance = tabInstances[clientName];
        var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
        var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
        path = path || "/";
        if (status + "" === "true") {
            getClientInfo(clientName, function(xhr) {
                if (xhr) {
                    var info = $.xml2json(xhr);
                    if (tabInstances[clientName]) {
                        tabInstances[clientName].info = info;
                    }
                }
                changeServerStatus(clientName, prefix, "-");
                if (callback)
                    callback();
                else
                    navigateToDir(path, clientName, prefix, false, false, true, function(){
                        serverPanel.trigger("connected");
                    });
            });
        } else {
            $.notify({
                icon: 'glyphicon glyphicon-warning-sign',
                message: 'Connection attempt failed.'
            }, {
                type: 'danger',
                timer: 1000
            });
            crush.unblock(listPanel.parent());
        }
    }

    function configureConnection(url, serverData, clientName, prefix, cb) {
        prefix = prefix == "l" ? "l" : "";
        setCiphers(url, serverData, clientName, prefix, function() {
            if (serverData.maxThreads) {
                var cmd = runCommand({
                    clientName: clientName,
                    setTo: prefix == "l" ? "src" : "dst",
                    command: "set max_threads \"" + serverData.maxThreads + "\""
                });
                cmd.promise.then(function() {
                    if (serverData.use_tunnel) {
                        var cmd2 = runCommand({
                            clientName: clientName,
                            setTo: prefix == "l" ? "src" : "dst",
                            command: "set use_tunnel \"true\""
                        });
                        cmd2.promise.then(function() {
                            if (serverData.pbe_pass) {
                                var cmd3 = runCommand({
                                    clientName: clientName,
                                    setTo: prefix == "l" ? "src" : "dst",
                                    command: "pbe " + serverData.pbe_pass + ""
                                });
                                cmd3.promise.then(function() {
                                    if (cb) {
                                        cb();
                                    }
                                });
                            } else {
                                if (cb) {
                                    cb();
                                }
                            }
                        });
                    } else {
                        if (serverData.pbe_pass) {
                            var cmd3 = runCommand({
                                clientName: clientName,
                                setTo: prefix == "l" ? "src" : "dst",
                                command: "pbe " + serverData.pbe_pass + ""
                            });
                            cmd3.promise.then(function() {
                                if (cb) {
                                    cb();
                                }
                            });
                        } else {
                            if (cb) {
                                cb();
                            }
                        }
                    }
                });
            } else {
                if (serverData.use_tunnel) {
                    var cmd2 = runCommand({
                        clientName: clientName,
                        setTo: prefix == "l" ? "src" : "dst",
                        command: "set use_tunnel \"true\""
                    });
                    cmd2.promise.then(function() {
                        if (serverData.pbe_pass) {
                            var cmd3 = runCommand({
                                clientName: clientName,
                                setTo: prefix == "l" ? "src" : "dst",
                                command: "pbe " + serverData.pbe_pass + ""
                            });
                            cmd3.promise.then(function() {
                                if (cb) {
                                    cb();
                                }
                            });
                        } else {
                            if (cb) {
                                cb();
                            }
                        }
                    });
                } else {
                    if (serverData.pbe_pass) {
                        var cmd3 = runCommand({
                            clientName: clientName,
                            setTo: prefix == "l" ? "src" : "dst",
                            command: "pbe " + serverData.pbe_pass + ""
                        });
                        cmd3.promise.then(function() {
                            if (cb) {
                                cb();
                            }
                        });
                    } else {
                        if (cb) {
                            cb();
                        }
                    }
                }
            }
        });
        if(serverData.protocol == "sftp://"){
            if(serverData.ssh_private_key){
                runCommand({
                    clientName: clientName,
                    setTo: prefix == "l" ? "src" : "dst",
                    command: "config ssh_private_key " + serverData.ssh_private_key + "",
                    notAsync : true
                });
            }
            if(serverData.ssh_private_key_pass){
                runCommand({
                    clientName: clientName,
                    setTo: prefix == "l" ? "src" : "dst",
                    command: "config ssh_private_key_pass " + serverData.ssh_private_key_pass + "",
                    notAsync : true
                });
            }
            if(serverData.ssh_two_factor){
                runCommand({
                    clientName: clientName,
                    setTo: prefix == "l" ? "src" : "dst",
                    command: "config ssh_two_factor " + serverData.ssh_two_factor + "",
                    notAsync : true
                });
            }
            if(serverData.verifyHost){
                runCommand({
                    clientName: clientName,
                    setTo: prefix == "l" ? "src" : "dst",
                    command: "config verifyHost " + serverData.verifyHost + "",
                    notAsync : true
                });
                if(serverData.addNewHost){
                    runCommand({
                        clientName: clientName,
                        setTo: prefix == "l" ? "src" : "dst",
                        command: "config addNewHost " + serverData.addNewHost + "",
                        notAsync : true
                    });
                }
                if(serverData.knownHostFile){
                    runCommand({
                        clientName: clientName,
                        setTo: prefix == "l" ? "src" : "dst",
                        command: "config knownHostFile " + serverData.knownHostFile + "",
                        notAsync : true
                    });
                }
            }
        }
    }

    function setCiphers(url, serverData, clientName, prefix, cb) {
        prefix = prefix == "l" ? "l" : "";
        if (url && url.toLowerCase().indexOf("https://") == 0) {
            var trustAll = serverData.cipher && serverData.cipher.trustAll;
            if (trustAll) {
                var cmd = runCommand({
                    clientName: clientName,
                    command: "CIPHER \"trust\""
                });
                cmd.promise.then(function() {
                    if (cb) {
                        cb();
                    }
                });
            } else if (serverData.cipher && serverData.cipher.cipher) {
                var cmd = runCommand({
                    clientName: clientName,
                    command: "CIPHER set \"" + serverData.cipher.cipher + "\""
                });
                cmd.promise.then(function() {
                    if (cb) {
                        cb();
                    }
                });
            } else {
                if (cb) {
                    cb();
                }
            }
        } else if (cb) {
            if(serverData.secure_data)
            {
                var cmd2 = runCommand({
                    clientName: clientName,
                    setTo: prefix == "l" ? "src" : "dst",
                    command: "set secure_data \"true\""
                });
                cmd2.promise.then(function() {
                    cb();
                });
            }
            else
                cb();
        }
    }

    function disconnectServer(clientName, prefix, callback) {
        prefix = prefix == "l" ? "l" : "";
        var cmd = runCommand({
            clientName: clientName,
            command: prefix + "discon"
        });
        cmd.promise.then(function() {
            changeServerStatus(clientName, prefix);
            if (callback) {
                callback();
            }
        });
    }

    function getServerTitle(server) {
        var text = server;
        if (server.indexOf("127.0.0.1:55555") >= 0 && prefs.last_tunnel_url) {
            text = prefs.last_tunnel_url + "";
        }
        return text;
    }

    function changeServerStatus(clientName, prefix, url) {
        prefix = prefix == "l" ? "l" : "";
        var curInstance = tabInstances[clientName];
        var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
        var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
        var bookmarkName = serverPanel.data("bookMarkSelected") || "";
        if (bookmarkName)
            bookmarkName = "<i class='fa fa-bookmark'></i> " + bookmarkName + " ";
        var serverText;
        if (curInstance.info) {
            var data = prefix == "l" ? curInstance.info.source : curInstance.info.destination;
            var vrl = data.vrl;
            if (vrl) {
                serverText = vrl;
                try {
                    var _url;
                    if (serverText)
                        _url = new URI(serverText);
                    else
                        _url = new URL(serverText);
                    var protocol = _url.protocol() || "file:";
                    protocol += "//";
                    var port = _url.port();
                    var host = _url.host();
                    var user = _url.username();
                    var pass = _url.password();
                    if (user) {
                        serverText = protocol + user + ":" + crush.getStars(pass) + "@" + host;
                    } else
                        serverText = protocol + host;

                } catch (ex) {
                    console.log(ex);
                    serverText = vrl;
                }
            }
            serverPanel.find(".server-title").html("<span class='advanced'>" + bookmarkName + getServerTitle(data.display_vrl || "") + "</span>");
        }
        if (url) {
            serverPanel.find(".sub-header, .refresh-button, .settings-button, .navigation, .list-filter, .new-dir-button, .disconnect-button").show();
            serverData.connectedTo = serverText;
            serverPanel.addClass('connected').find(".toggle-switch").not(".collapsed").trigger("click");
            serverPanel.find(".settings-panel-heading").find(".status").remove();
            serverPanel.find(".settings-panel-heading").append('<span class="status advanced"><i class="fa fa-check-circle fa-fw"></i> Connected' + "" + '</span>');
            setTimeout(function(){
                serverPanel.find(".toggle-switch[aria-expanded='true']").trigger('click');
            }, 1000);
        } else {
            serverPanel.find(".sub-header, .refresh-button, .settings-button, .navigation, .list-filter, .new-dir-button, .disconnect-button").hide();
            serverData.connectedTo = false;
            serverData.connectionURL = false;
            serverPanel.removeClass('connected').find(".settings-panel-heading").find('.status').remove();
            serverPanel.find(".server-footer").empty();
            serverPanel.find(".list-group").find(".custom-data-table-scroll").empty();
            serverPanel.find(".server-title").text('Disconnected');

            var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
            var dataTable = listPanel.data("dataTable");
            if(dataTable){
                dataTable.rebind({
                    dataSource: []
                }).scroll("up");
            }
            setTimeout(function(){
                serverPanel.find(".toggle-switch[aria-expanded='false']").trigger('click');
            }, 100);
        }
    }

    function bindEvents(clientName) {
        var curInstance = tabInstances[clientName];
        var panel = curInstance.panel;
        fluidUI.bind(panel);
        $('[data-toggle="tooltip"]', panel).tooltip({
            container: "body"
        });
        var runCustomCommand = $('.runCustomCommand', panel);
        var runCommandToggle = $(".runCommandToggle", panel);
        var commandToRun = $(".commandToRun", panel).unbind().bind("keydown", function(evt) {
            var evt = (evt) ? evt : ((event) ? event : null);
            if (evt.keyCode == 13) {
                runCustomCommand.trigger("click");
                evt.stopPropagation();
                evt.preventDefault();
                return false;
            } else if (evt.keyCode == 27) {
                runCommandToggle.click();
            }
        });
        runCustomCommand.unbind().bind("click", function() {
            var cmdStr = $.trim(commandToRun.val());
            commandToRun.focus();
            if (cmdStr) {
                commandToRun.attr("readonly", "readonly").parent().block({
                    message: "<i class='spin fa fa-spinner'></i> Please Wait..",
                    centerX: false,
                    centerY: false,
                    overlayCSS: {
                        zIndex: 9999
                    },
                    css: {
                        width: 120,
                        top: '2px',
                        left: '50%',
                        'margin-left': '-60px',
                        border: 'none',
                        padding: '5px',
                        backgroundColor: '#000',
                        '-webkit-border-radius': '10px',
                        '-moz-border-radius': '10px',
                        opacity: .5,
                        color: '#fff',
                        'text-align': 'left'
                    }
                });
                var cmd = runCommand({
                    clientName: loadedClientName,
                    command: cmdStr
                });
                cmd.promise.then(function(items) {
                    commandToRun.removeAttr('readonly').parent().unblock();
                    commandToRun.val("");
                });
            }
        });
        $(".clearLog", panel).unbind().bind("click", function() {
            try {
                clientLog[loadedClientName].logData = [];
                var dtInstance = loadedTab.find(".log-panel").data("dataTable");
                dtInstance.rebind({
                    dataSource: clientLog[loadedClientName].logData
                });
            } catch (ex) {}
        });
        panel.find(".settings-button").each(function() {
            var prefix = $(this).hasClass('left-server') ? "l" : "";
            var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
            var panelID = serverPanel.find(".server-settings:first").attr("id");
            var contextMenu = $('#' + panelID + '_itemsContext');
            $(this).unbind().contextMenu({
                menu: contextMenu.attr("id"),
                addClassSP: true,
                openOnClick: true
            }, function(action, el, pos) {
                var prefix = $(el).hasClass('left-server') ? "l" : "";
                handleContextEvents(action, el, clientName, prefix);
            }).bind("onBeforeContextMenu", function() {
                if (isDotItemsHidden(clientName, prefix)) {
                    contextMenu.find(".hide-items-with-dot").removeClass("fa-toggle-off").addClass('fa-toggle-on');
                } else {
                    contextMenu.find(".hide-items-with-dot").removeClass("fa-toggle-on").addClass('fa-toggle-off');
                }
                contextMenu.find(".disabled").removeClass('disabled');
                contextMenu.find(".open,.createdir,.rename,.privs").addClass('disabled');
            });
        });
        panel.find(".settings-panel").find("input").unbind().bind("keyup", function(evt) {
            var evt = (evt) ? evt : ((event) ? event : null);
            if ((evt.keyCode == 13 || evt.keyCode == 27) && $(this).hasClass('typeahead')) {
                if ($(this).closest(".settings-panel").find(".tt-menu:visible").length > 0) {
                    evt.stopPropagation();
                    evt.preventDefault();
                    return false;
                }
            }
            if (evt.keyCode == 13) {
                $(this).closest(".settings-panel").find(".connect-button:last").click();
            } else if (evt.keyCode == 27) {
                $(this).closest(".settings-panel").find(".cancel-button").click();
            }
        });
        panel.find(".save-connection").unbind().bind("change", function() {
            if ($(this).is(":checked"))
                $(this).closest(".settings-panel").find(".bookmark-name").show().find("input").focus().select();
            else
                $(this).closest(".settings-panel").find(".bookmark-name").hide();
        });
        panel.find(".hide-dot-items").unbind().bind("change", function() {
            var prefix = $(this).hasClass('left-server') ? "l" : "";
            crush.storage(clientName + "_" + prefix + "HideDotItems", $(this).is(":checked"));
            navigateToDir(false, clientName, prefix);
        });
        panel.find(".protocol-input").unbind().bind("change", function(evt, noDefaultValues) {
            var ftpOptions = $(this).closest(".settings-panel").find(".ftp-option").hide();
            var ftpesOptions = $(this).closest(".settings-panel").find(".ftpes-option").hide();
            var httpsOptions = $(this).closest(".settings-panel").find(".https-options").hide();
            var httpOptions = $(this).closest(".settings-panel").find(".http-options").hide();
            var sftpOptions = $(this).closest(".settings-panel").find(".sftp-options").hide();
            if ($(this).val() == "file://") {
                $(this).closest(".settings-panel").find(".non-file-option").hide();
            } else {
                $(this).closest(".settings-panel").find(".non-file-option").show();
                if (!noDefaultValues) {
                    if ($(this).val() == "ftp://") {
                        $(this).closest(".settings-panel").find(".port-input").val("21").typeahead('val', 21);
                    } else if ($(this).val() == "ftps://") {
                        $(this).closest(".settings-panel").find(".port-input").val("990").typeahead('val', 990);
                    } else if ($(this).val() == "ftpes://") {
                        $(this).closest(".settings-panel").find(".port-input").val("21").typeahead('val', 21);
                    } else if ($(this).val() == "sftp://") {
                        $(this).closest(".settings-panel").find(".port-input").val("22").typeahead('val', 22);
                    } else if ($(this).val() == "http://") {
                        $(this).closest(".settings-panel").find(".port-input").val("80").typeahead('val', 80);
                    } else if ($(this).val() == "https://") {
                        $(this).closest(".settings-panel").find(".port-input").val("443").typeahead('val', 443);
                    } else if ($(this).val() == "smb://") {
                        $(this).closest(".settings-panel").find(".port-input").val("445").typeahead('val', 445);
                    }
                }
                if ($(this).val() == "ftp://") {
                    ftpOptions.show();
                } else if ($(this).val() == "ftps://") {
                    ftpOptions.show();
                    ftpesOptions.show();
                } else if ($(this).val() == "ftpes://") {
                    ftpOptions.show();
                    ftpesOptions.show();
                } else if ($(this).val() == "sftp://") {
                    //show sftp items
                    sftpOptions.show();
                } else if ($(this).val() == "http://") {
                    //show http items
                    httpOptions.show();
                } else if ($(this).val() == "https://") {
                    //show https items
                    httpOptions.show();
                    httpsOptions.show();
                } else if ($(this).val() == "smb://") {
                    //show smb items
                }
            }
        }).trigger("change");

        panel.find(".bookmarks").unbind().click(function() {
            var prefix = $(this).hasClass('left-server') ? "l" : "";
            var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
            bookmarks.show({
                prefix: prefix,
                serverPanel: serverPanel
            });
            return false;
        });

        panel.find(".cipher-control").unbind().click(function() {
            var prefix = $(this).hasClass('left-server') ? "l" : "";
            var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
            var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
            serverData = serverData || {};
            var cipherData = {};
            var curCipherVal = serverPanel.find(".cipher-value").text();
            curCipherVal = curCipherVal == "Default" ? "" : curCipherVal;
            if (curCipherVal == "Trust All")
                cipherData.trustAll = true;
            else if (curCipherVal)
                cipherData.cipher = curCipherVal;

            ciphers.show({
                prefix: prefix,
                serverPanel: serverPanel,
                serverData: cipherData || {},
                clientName: loadedClientName,
                callback: function(cipher, trustAll) {
                    if (trustAll)
                        serverPanel.find(".cipher-value").text("Trust All");
                    else {
                        cipher = cipher == "" ? "Default" : cipher;
                        serverPanel.find(".cipher-value").text(cipher);
                    }
                }
            });
            return false;
        });

        panel.find(".connect-button").unbind().click(function(event, bookmark) {
            var onlyBM = $(this).hasClass('bookmark-only');
            var prefix = $(this).hasClass('left-server') ? "l" : "";
            var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
            if (bookmark)
                serverPanel.data("bookMarkSelected", bookmark);
            else
                serverPanel.removeData("bookMarkSelected");
            var _serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
            var serverData = $.extend({}, _serverData, true);
            var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
            var panelID = serverPanel.find(".server-settings:first").attr("id");
            var protocol = $('#' + panelID + '_protocol', serverPanel).val() || "";
            var host = $('#' + panelID + '_host', serverPanel).val() || "";
            var port = $('#' + panelID + '_port', serverPanel).val() || "";
            var user = $('#' + panelID + '_username', serverPanel).val() || "";
            var pass = $('#' + panelID + '_password', serverPanel).val() || "";
            var path = $('#' + panelID + '_default_path', serverPanel).val() || "";
            var cipher = $('#' + panelID + '_cipher', serverPanel).val() || "";
            var maxThreads = $('#' + panelID + '_max_threads', serverPanel).val() || "";
            var connect = $('#' + panelID + '_connect', serverPanel).val() || "";
            var save = $('#' + panelID + '_save', serverPanel).is(":checked");
            var bookmarkName = $('#' + panelID + '_bookmark_name', serverPanel).val() || "";
            var useTunnel = $('#' + panelID + '_use_tunnel', serverPanel).is(":checked");
            var securedData = $('#' + panelID + '_secure_data', serverPanel).is(":checked");
            var isPBE = $('#' + panelID + '_PasswordBaseEncrypt', serverPanel).is(":checked");
            var pbe_pass = isPBE ? $('#' + panelID + '_PasswordBaseEncryptPass', serverPanel).val() || "" : "";

            var sftpSSHKey = $('#' + panelID + '_ssh_private_key', serverPanel).val() || "";
            var sftpSSHKeyPass = $('#' + panelID + '_ssh_private_key_pass', serverPanel).val() || "";
            var sftpTwoFactor = $('#' + panelID + '_ssh_two_factor', serverPanel).is(":checked") + "";
            var sftpVerifyHost = $('#' + panelID + '_verifyHost', serverPanel).is(":checked") + "";
            var sftpAddHost = $('#' + panelID + '_addNewHost', serverPanel).is(":checked") + "";
            var sftpKnownHostFile = $('#' + panelID + '_knownHostFile', serverPanel).val() || "";

            if((maxThreads && !crush.isNumeric(maxThreads)) || maxThreads <0){
                bootbox.alert("Max threads value is not valid.", function(){
                    setTimeout(function(){
                        $('#' + panelID + '_max_threads', serverPanel).select().focus();
                    },500);
                });
                return false;
            }
            var _host = host + "";
            if (port && protocol != "file://")
                _host = host + ":" + port;
            var url = {};
            if ((user || pass) && protocol != "file://") {
                url.original = protocol + encodeURIComponent(user) + ":" + encodeURIComponent(pass) + "@" + _host;
                url.display = protocol + user + ":" + crush.getStars(pass) + "@" + _host;
            } else {
                if(protocol == "file://" && path.indexOf("/")==0)
                    url.display = url.original = "file:/" + path;
                else
                    url.display = url.original = protocol + path;
            }
            // var serverData;
            // if (prefix == "l") {
            //     serverData = curInstance.leftServerData;
            // } else {
            //     serverData = curInstance.rightServerData;
            // }
            var cipherData = {};
            var curCipherVal = serverPanel.find(".cipher-value").text();
            curCipherVal = curCipherVal == "Default" ? "" : curCipherVal;
            if (curCipherVal == "Trust All")
                cipherData.trustAll = true;
            else if (curCipherVal)
                cipherData.cipher = curCipherVal;
            serverData.connectionURL = url;
            serverData.currentPath = "/";
            serverData.protocol = protocol;
            serverData.host = $.trim(host);
            serverData.port = $.trim(port);
            serverData.user = $.trim(user);
            serverData.pass = $.trim(pass);
            serverData.passToUse = $.trim(pass);
            serverData.defaultPath = $.trim(path);
            serverData.cipher = cipherData;
            serverData.maxThreads = maxThreads;
            serverData.connect = connect;
            serverData.pbe_pass = pbe_pass + "";
            if (protocol == "http://" || protocol == "https://"){
                serverData.use_tunnel = useTunnel;
            }
            else if(protocol == "ftps://" || protocol == "ftpes://"){
                serverData.secure_data = securedData;
            }
            else if(protocol == "sftp://"){
                serverData.ssh_private_key = sftpSSHKey;
                serverData.ssh_private_key_pass = sftpSSHKeyPass;
                serverData.ssh_two_factor = sftpTwoFactor;
                serverData.verifyHost = sftpVerifyHost;
                serverData.addNewHost = sftpAddHost;
                serverData.knownHostFile = sftpKnownHostFile;
            }
            if (save) {
                function continueSaveBookMark() {
                    var bookmark = $.extend({}, serverData, true);
                    delete bookmark.passToUse;
                    delete bookmark.connectionURL;
                    delete bookmark.currentPath;
                    delete bookmark.lastPath;
                    delete bookmark.lastSelectedIndex;
                    bookmark.id = "Bookmark_" + crush.random();
                    bookmark.name = bookmarkName;
                    savePrefs({
                        newBookmark: bookmark,
                        callback: function() {
                            if (onlyBM) {
                                crush.showLoading(true);
                                loadPrefs(function() {
                                    crush.hideLoading(true);
                                    bookmarks.show();
                                });
                            } else {
                                serverPanel.data("bookMarkSelected", bookmarkName);
                                continueConnect();
                            }
                        }
                    });
                }
                if (!bookmarkName || crush.hasSpecialCharacters(bookmarkName)) {
                    $.notify({
                        icon: 'glyphicon glyphicon-warning-sign',
                        message: 'Bookmark name can not be empty or have special chars like : "@ # % & : = + ? / ."'
                    }, {
                        placement: {
                            align: 'center'
                        },
                        offset: {
                            y: 200
                        },
                        type: 'danger',
                        timer: 1000,
                        z_index: 99999
                    });
                    $('#' + panelID + '_bookmark_name', serverPanel).focus();
                    return false;
                }
                if (bookmarks.hasName(bookmarkName)) {
                    bootbox.confirm("Bookmark with name '" + bookmarkName + "' exists, do you want to overwrite?", function(result) {
                        if (result) {
                            continueSaveBookMark();
                        } else {
                            $('#' + panelID + '_bookmark_name', serverPanel).focus().select();
                        }
                    });
                    return false;
                }
                continueSaveBookMark();
                return false;
            }

            function continueConnect() {
                var cmd = runCommand({
                    clientName: clientName,
                    command: prefix + "discon"
                });
                cmd.promise.then(function() {
                    changeServerStatus(clientName, prefix);
                    crush.block(listPanel.parent(), "<br><div class='text-center'><a class='btn' href='javascript:void(0);'><i class='fa fa-close'></i> Cancel</a></div>");
                    if(prefix == "l")
                        curInstance.leftServerData = serverData;
                    else
                        curInstance.rightServerData = serverData;
                    serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
                    configureConnection(url.original, serverData, clientName, prefix, function() {
                        var cmd = runCommand({
                            clientName: clientName,
                            command: prefix + "connect \"" + url.original + "\"",
                            displayCommand: prefix + "connect \"" + url.display + "\""
                        });
                        cmd.promise.then(function(status) {
                            serverData.currentPath = path;
                            afterConnect(status, clientName, prefix, path);
                        });
                        listPanel.parent().find(".blockMsg").find("a").click(function() {
                            cmd.xhr.abort();
                        });
                    });
                });
            }
            if (serverPanel.hasClass('connected')) {
                if (url.original == serverData.connectionURL) {
                    bootbox.alert("You are already connected to specified host.");
                    return false;
                }
                _serverData.connectedTo = _serverData.connectedTo || "";
                if(_serverData.connectedTo.indexOf("file") == 0 && serverData.connectionURL.original.indexOf("file") == 0){
                    navigateToDir(serverData.defaultPath, clientName, prefix, false, false, true);
                }
                else
                {
                    bootbox.confirm("This will disconnect your current connection, do you want to proceed?", function(result) {
                        if (result)
                            continueConnect();
                    });
                }
            } else {
                continueConnect();
            }
        });
        panel.find(".sub-header").unbind("dblclick").dblclick(function(evt, params) {
            crush.removeRangeSelection();
            var prefix = $(this).closest(".server-list-panel").hasClass('left-server') ? "l" : "";
            panel.find(".sub-header").find("input[type='checkbox']").prop("checked", false);
            navigateToDir(false, clientName, prefix, true);
        });

        panel.find(".sub-header").find("input[type='checkbox']").unbind().change(function(evt, params) {
            var prefix = $(this).closest(".server-list-panel").hasClass('left-server') ? "l" : "";
            if($(this).is(":checked")){
                handleServerItemEvent({which : 65, metaKey : true, preventDefault:function(e){}, stopPropagation:function(e){}, selectAll : true}, "keydown", clientName, prefix);
            }
            else{
                handleServerItemEvent({which : 65, metaKey : true, preventDefault:function(e){}, stopPropagation:function(e){}, selectAll : false}, "keydown", clientName, prefix);
            }
        });

        panel.find(".refresh-button").unbind("click").click(function() {
            var prefix = $(this).closest(".server-panel").find(".server-list-panel").hasClass('left-server') ? "l" : "";
            navigateToDir(false, clientName, prefix);
        });

        panel.find(".disconnect-button").unbind("click").click(function() {
            var prefix = $(this).closest(".server-panel").find(".server-list-panel").hasClass('left-server') ? "l" : "";
            bootbox.confirm("Are you sure you want to disconnect from this server?", function(result) {
                if (result)
                    disconnectServer(clientName, prefix);
            });
        });

        panel.find(".new-dir-button").unbind("click").click(function() {
            var prefix = $(this).closest(".server-list-panel").hasClass('left-server') ? "l" : "";
            handleContextEvents("createdirHere", $("span"), clientName, prefix);
        });

        panel.find(".filter-control").unbind("textchange").bind("textchange", function(evt) {
            var delay = (function() {
                var timer = 0;
                return function(callback, ms) {
                    clearTimeout(timer);
                    timer = setTimeout(callback, ms);
                };
            })();
            var that = $(this);
            var prefix = $(this).hasClass('left-server') ? "l" : "";
            var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
            var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
            var listPanel = prefix == "" ? curInstance.leftListPanel : curInstance.rightListPanel;
            var phrase = $.trim($(this).val());
            if (phrase) {
                $(this).parent().find(".fa-search").removeClass('fa-search').addClass('fa-remove');
            } else {
                $(this).parent().find(".fa-remove").removeClass('fa-remove').addClass('fa-search');
            }
            if (evt.keyCode == 27) {
                $(this).val("").trigger('textchange');
            }
            delay(function() {
                phrase = $.trim(that.val());
                filterServerList(phrase, serverPanel, serverData, prefix);
            }, 500);
        }).bind("keydown", function(evt) {
            if (evt.keyCode == 27) {
                $(this).val("").trigger('textchange');
            }
            if (evt.keyCode == 13) {
                evt.stopPropagation();
                evt.preventDefault();
                return false;
            }
        });

        var logFilter = panel.find(".log-filter").unbind().bind("textchange", function(evt) {
            var delay = (function() {
                var timer = 0;
                return function(callback, ms) {
                    clearTimeout(timer);
                    timer = setTimeout(callback, ms);
                };
            })();
            var phrase = $.trim($(this).val());
            if (phrase) {
                $(this).parent().find(".fa-search").removeClass('fa-search').addClass('fa-remove');
            } else {
                $(this).parent().find(".fa-remove").removeClass('fa-remove').addClass('fa-search');
            }
            delay(function() {
                filterLog(phrase);
            }, 500);
        }).bind("keydown", function(evt) {
            if (evt.keyCode == 27) {
                $(this).val("").trigger('textchange');
            }
            if (evt.keyCode == 13) {
                evt.stopPropagation();
                evt.preventDefault();
                return false;
            }
        });

        panel.find(".log-filter-button").unbind().bind("click", function() {
            logFilter.val("").trigger('textchange');
            return false;
        });

        panel.find(".filter-button").unbind().bind("click", function() {
            if ($(this).parent().find(".filter-control").val())
                $(this).parent().find(".filter-control").val("").trigger('textchange');
        });

        function filterLog(phrase) {
            function processBeforeRender(data) {
                var _data = [];
                for (var i = 0; i < data.length; i++) {
                    var curItem = data[i];
                    if (curItem.text.toLowerCase().indexOf(phrase) >= 0) {
                        _data.push(curItem);
                    }
                }
                return _data;
            }
            var dataTable = loadedTab.find(".log-panel").data("dataTable");
            var items = dataTable.options.dataSource;
            if (!dataTable.options.originalDS)
                dataTable.options.originalDS = dataTable.options.dataSource;
            phrase = $.trim(phrase);
            var prnt = loadedTab.find(".log-panel").parent();
            prnt.find(".filter-info").remove();
            if (phrase) {
                prnt.append('<span class="filter-info"><i class="fa fa-filter"></i> Filter applied <i class="fa fa-remove"></i></span>');
                prnt.find(".filter-info").click(function() {
                    prnt.closest(".log-tab").find(".log-filter").val("").trigger('textchange');
                });
                phrase = phrase.toLowerCase();
                items = processBeforeRender(items);
                dataTable.rebind({
                    dataSource: items
                }).scroll("up");
            } else {
                if (dataTable.options.originalDS)
                    dataTable.options.dataSource = dataTable.options.originalDS;
                delete dataTable.options.originalDS;
                dataTable.rebind().scroll("up");
            }
        }

        function filterServerList(phrase, serverPanel, serverData, prefix) {
            prefix = prefix == "l" ? "l" : "";
            var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
            var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
            var dataTable = listPanel.data("dataTable");

            function processBeforeRender(data) {
                var hideWithDot = isDotItemsHidden(clientName, prefix);
                var _data = [];
                for (var i = 0; i < data.length; i++) {
                    var curItem = data[i];
                    if (curItem.name.toLowerCase().indexOf(phrase) >= 0) {
                        if (!hideWithDot || curItem.name.indexOf(".") != 0)
                            _data.push(curItem);
                    }
                }
                return _data;
            }
            if (dataTable && dataTable.options) {
                if (dataTable.options.originalDS) {
                    dataTable.options.dataSource = dataTable.options.originalDS;
                }
            }
            var items = dataTable && dataTable.options ? dataTable.options.dataSource : [];
            if (dataTable && dataTable.options && !dataTable.options.originalDS)
                dataTable.options.originalDS = dataTable.options.dataSource;
            phrase = $.trim(phrase);
            serverPanel.find(".server-footer").find(".filter-info").remove();
            if (phrase) {
                serverPanel.find(".server-footer").append('<span class="filter-info"><i class="fa fa-filter"></i> Filter applied <i class="fa fa-remove"></i></span>');
                serverPanel.find(".server-footer").find(".filter-info").click(function() {
                    serverPanel.find(".filter-button").click();
                });
                phrase = phrase.toLowerCase();
                items = processBeforeRender(items);
                dataTable.rebind({
                    dataSource: items
                }).scroll("up");
            } else {
                if (dataTable && dataTable.options) {
                    dataTable.rebind().scroll("up");
                }
            }
        }

        bindItemListEvents(curInstance.leftListPanel, curInstance.leftServerPanel, curInstance.leftServerData, clientName, "l");
        bindItemListEvents(curInstance.rightListPanel, curInstance.rightServerPanel, curInstance.rightServerData, clientName);

        panel.find(".detailed-progress-toggle").unbind().click(function() {
            $(this).closest(".action-bar-content").toggleClass("show-details");
        });

        panel.find(".cancel-button-action").unbind().click(function() {
            if($(this).hasClass('disabled'))
                return false;
            if(curInstance.panel.find(".actions").find(".stat-item").length>0){
                bootbox.confirm("Are you sure you want to abort ongoing transfer(s)?", function(result) {
                    if (result) {
                        var cmd = runCommand({
                            clientName: clientName,
                            command: "ABOR"
                        });
                        cmd.promise.then(function(status) {
                            $.notify({
                                icon: 'glyphicon glyphicon-transfer',
                                message: "Transfer aborted."
                            }, {
                                type: 'success',
                                timer: 3000
                            });
                        });
                    }
                });
            }
            return false;
        });
        // $(".fa.fa-caret-right.expand:visible").click(function(e) {

        // });

        var sideBarHndle = panel.find(".right-side-bar-handle").unbind().click(function() {
            $('body').css("overflow", "hidden");
            $(".action-side-bar:visible", loadedTab).toggleClass("collapsed-right-sidebar");
            $(".server-panel-wrapper:visible", loadedTab).css("width", "");
            $(".server-panel-wrapper:visible", loadedTab).toggleClass('col-lg-9 col-lg-12 right-space');
            $(".action-side-bar:visible", loadedTab).toggleClass('col-lg-3 right-sidebar-small');
            if ($(".action-side-bar:visible").hasClass('right-sidebar-small')) {
                $(".server-panel-wrapper:visible .row:first").css("margin-right", "0px");
                $(".server-panel-wrapper:visible").css("margin-right", "-36px");
            } else
                $(".server-panel-wrapper:visible").css("margin-right", "");
            $(".server-panel-wrapper:visible .row:first").css("margin-right", "");
            fluidUI.resize();
        });

        panel.find(".bottom-panel .nav-tabs").unbind().click(function() {
            if ($('body').hasClass('bottom-panel-hidden')) {

            }
        });

        panel.find(".bottom-panel").find("li[menu]").unbind().click(function() {
            var menu = $(this).attr("menu");
            if (menu.indexOf("clear_") == 0) {
                $.when(crush.data.ajax({
                    command: menu,
                    client: clientName
                })).done(function(_data) {});
            } else if (menu == "resend_completed" || menu == "resend_failed") {
                var commands = [];
                var queue = menu == "resend_completed" ? panel.find(".bottom-panel").find(".queue.completed") : panel.find(".bottom-panel").find(".queue.failed");
                var dataTable = queue.data("dataTable");
                var data = dataTable.options.dataSource;
                for (var i = 0; i < data.length; i++) {
                    var cmd = data[i].text;
                    if (commands.indexOf(cmd) < 0)
                        commands.push(cmd);
                }
                runCommand({
                    clientName: clientName,
                    command: commands.join("\n")
                });
            }
        });
    }

    function bindItemListEvents(listPanel, serverPanel, serversData, clientName, prefix) {
        prefix = prefix == "l" ? "l" : "";
        listPanel.unbind("render").bind("render", function() {
            var panelID = serverPanel.find(".server-settings:first").attr("id");
            var contextMenu = $('#' + panelID + '_itemsContext');
            var elems = serverPanel.find("div.custom-data-row");
            $('[data-toggle="tooltip"]', serverPanel).tooltip();
            elems.draggable({
                addClasses: false,
                distance: 20,
                start: function(event, ui) {
                    var elem = $(event.target);
                    if (!elem.hasClass('selected')) {
                        makeItemSelection({
                            start: parseInt(elem.attr("_index"))
                        }, clientName, prefix, false, false);
                    }
                    $(document).unbind("keyup.crushDraggables").bind("keyup.crushDraggables", function(e) {
                        if (e.keyCode == 27) {
                            $(document).trigger('mouseup');
                        }
                    });
                    var curInstance = tabInstances[clientName];
                    var panel = curInstance.panel;
                    var curServerPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
                    var curServerData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
                    var selection = curServerData.currentSelection;
                    var dirsLbl = selection.dirs > 1 ? "folders" : "folder";
                    var helper;
                    var filesLbl = selection.files > 1 ? "files" : "file";
                    if (selection.dirs && selection.files) {
                        helper = "Selected " + selection.dirs + " " + dirsLbl + ", " + selection.files + " " + filesLbl + ".";
                    } else if (selection.dirs) {
                        helper = "Selected " + selection.dirs + " " + dirsLbl + ". ";
                    } else {
                        helper = "Selected " + selection.files + " " + filesLbl + ". ";
                    }
                    $('.dragging-items').text(helper);
                },
                helper: function(e) {
                    var curInstance = tabInstances[clientName];
                    var panel = curInstance.panel;
                    var curServerPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
                    var curServerData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
                    var selection = curServerData.currentSelection || {};
                    var dirsLbl = selection.dirs > 1 ? "folders" : "folder";
                    var helper;
                    var filesLbl = selection.files > 1 ? "files" : "file";
                    if (selection.dirs && selection.files) {
                        helper = $("<span class='dragging-items'>Selected " + selection.dirs + " " + dirsLbl + ", " + selection.files + " " + filesLbl + ".</span>");
                    } else if (selection.dirs) {
                        helper = $("<span class='dragging-items'>Selected " + selection.dirs + " " + dirsLbl + ". </span>");
                    } else if (selection.files) {
                        helper = $("<span class='dragging-items'>Selected " + selection.files + " " + filesLbl + ". </span>");
                    } else {
                        helper = $("<span class='dragging-items'>Selected ");
                    }
                    return helper;
                },
                appendTo: "body"
            });
            $("body").append(contextMenu);
            elems.contextMenu({
                menu: contextMenu.attr("id"),
                addClassSP: true
            }, function(action, el, pos) {
                handleContextEvents(action, el, clientName, prefix);
            }).bind("onBeforeContextMenu", function() {
                if (isDotItemsHidden(clientName, prefix)) {
                    contextMenu.find(".hide-items-with-dot").removeClass("fa-toggle-off").addClass('fa-toggle-on');
                } else {
                    contextMenu.find(".hide-items-with-dot").removeClass("fa-toggle-on").addClass('fa-toggle-off');
                }
                var data = $(this).data("dataRow");
                contextMenu.find(".disabled").removeClass('disabled');
                if (data.type != "dir")
                    contextMenu.find(".createdir").addClass('disabled');
            });
            var pr = prefix == "l" ? "" : "l";
            serverPanel.find(".server-item-row.dir").find(".name").droppable({
                accept: "." + pr + "side",
                hoverClass: "row-hover",
                greedy: true,
                drop: function(e, ui) {
                    handleItemDrop(e.target, clientName, prefix);
                }
            });
        });
        var pr = prefix == "l" ? "" : "l";
        serverPanel.find(".server-list-panel").unbind().droppable({
            accept: "." + pr + "side",
            activeClass: "panel-highlight",
            hoverClass: "panel-hover",
            drop: function(e, ui) {
                handleItemDrop(e.target, clientName, prefix);
            }
        });
    }

    function handleContextEvents(action, el, clientName, prefix) {
        prefix = prefix == "l" ? "l" : "";
        var curInstance = tabInstances[clientName];
        var panel = curInstance.panel;
        var curServerPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
        var curServerData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
        var otherServerPanel = prefix == "l" ? curInstance.rightServerPanel : curInstance.leftServerPanel;
        var otherServerData = prefix == "l" ? curInstance.rightServerData : curInstance.leftServerData;
        var dataRow = el.data("dataRow") || {
            selected: true,
            name: ""
        };
        var selection = $.extend({}, curServerData.currentSelection, true);
        var selectText = "";
        var hasSelection = false;
        if (!dataRow.selected) {
            if (dataRow.type == "dir") {
                selection.dirs++;
                hasSelection = true;
            } else {
                selection.files++;
                hasSelection = true;
            }
        }
        if (selection.dirs > 1 || selection.files > 1 || !hasSelection) {
            if (dataRow.type == "dir")
                selection.dirs -= 1;
            else if (dataRow.type == "file")
                selection.files -= 1;
            var dirsLbl = selection.dirs > 1 ? "folders" : "folder";
            var filesLbl = selection.files > 1 ? "files" : "file";
            var _prefix = dataRow.name ? " and other " : "";
            if (selection.dirs && selection.files) {
                selectText = _prefix + selection.dirs + " " + dirsLbl + ", " + selection.files + " " + filesLbl;
            } else if (selection.dirs) {
                selectText = _prefix + selection.dirs + " " + dirsLbl;
            } else {
                selectText = _prefix + selection.files + " " + filesLbl;
            }
        }
        if (action == "transfer") {
            if (!dataRow.name && !selectText)
                return false;
            generateTransferScript(clientName, prefix, dataRow.name);
        } else if (action == "open") {
            navigateToDir(dataRow.name, clientName, prefix);
        } else if (action == "refresh") {
            navigateToDir(false, clientName, prefix);
        } else if (action == "goup") {
            navigateToDir(false, clientName, prefix, true);
        } else if (action == "createdir" || action == "createdirHere") {
            var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
            var targetServerData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
            var folderPath = action == "createdir" ? dataRow.name : targetServerData.currentPath;
            var folderCreatePath = action == "createdir" ? targetServerData.currentPath + dataRow.name + "/" : targetServerData.currentPath;
            bootbox.dialog({
                title: "Create folder at '" + folderPath + "'",
                message: '<div id="createDirPopup" class="row"><div class="col-md-12"><form action="" class="form-horizontal"><div class="form-group"><label for="newFolderName" class="col-md-4 control-label">Folder Name : </label><div class="col-md-4"><input type="text" value="New Folder" id="newFolderName" class="form-control input-md" /></div></div><div class="form-group"><div class="col-md-4"></div><div class="checkbox col-md-8"><label><input type="checkbox" id="newFolderNavigate"> Navigate to the folder after creation</label></div></div></form></div></div>',
                value: "New Folder",
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: "Cancel",
                        className: "btn-default",
                        callback: function() {}
                    },
                    ok: {
                        label: "OK",
                        className: "btn-success",
                        callback: function() {
                            var result = $("#newFolderName").val();
                            var navigate = $("#newFolderNavigate").is(":checked");
                            if (result) {
                                var path = folderCreatePath + result;
                                crush.block(listPanel.parent());
                                var cmd = runCommand({
                                    clientName: clientName,
                                    command: prefix + "mkd \"" + path + "\""
                                });
                                cmd.promise.then(function(items) {
                                    if (items.toString().toLowerCase().indexOf("error!") >= 0) {
                                        $.notify({
                                            icon: 'glyphicon glyphicon-warning-sign',
                                            message: items.toString()
                                        }, {
                                            type: 'danger',
                                            timer: 3000
                                        });
                                    }
                                    crush.unblock(listPanel.parent());
                                    if (navigate) {
                                        if (action == "createdir")
                                            navigateToDir(dataRow.name + "/" + result, clientName, prefix);
                                        else
                                            navigateToDir(result, clientName, prefix);
                                    } else
                                        navigateToDir(false, clientName, prefix);
                                });
                            }
                        }
                    }
                }
            });
            setTimeout(function() {
                var createDirPopup = $('#createDirPopup');
                createDirPopup.find("#newFolderName").focus().select();
                createDirPopup.find("#newFolderName").bind("keydown", function(evt) {
                    if (evt.which == 13) {
                        createDirPopup.closest(".modal-content").find(".btn-success").trigger("click");
                        evt.stopPropagation();
                        evt.preventDefault();
                        return false;
                    }
                });
            }, 500);
        } else if (action == "rename") {
            bootbox.prompt({
                title: "Rename :",
                value: dataRow.name,
                callback: function(result) {
                    if (result) {
                        var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
                        var targetServerData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
                        var path = targetServerData.currentPath + dataRow.name;
                        var newPath = targetServerData.currentPath + result;
                        crush.block(listPanel.parent());
                        var cmd = runCommand({
                            clientName: clientName,
                            command: prefix + "rename \"" + path + "\" \"" + newPath + "\""
                        });
                        cmd.promise.then(function(items) {
                            if (items.toString().toLowerCase().indexOf("error!") >= 0) {
                                $.notify({
                                    icon: 'glyphicon glyphicon-warning-sign',
                                    message: items.toString()
                                }, {
                                    type: 'danger',
                                    timer: 3000
                                });
                            }
                            crush.unblock(listPanel.parent());
                            navigateToDir(false, clientName, prefix);
                        });
                    }
                }
            });
        } else if (action == "delete") {
            if (!dataRow.name && !selectText)
                return false;
            bootbox.confirm("Are you sure you want to delete " + dataRow.name + " " + selectText + "?", function(result) {
                if (result) {
                    if (!dataRow.selected) {
                        el.trigger('click');
                    }
                    var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
                    var targetServerData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
                    var dataTable = listPanel.data("dataTable");
                    var dataSource = dataTable.options.dataSource;
                    var i = dataSource.length;
                    var totalToDelete = 0;
                    var totalDeleted = 0;
                    if (i > 0)
                        crush.block(listPanel.parent());
                    while (i--) {
                        if (dataSource[i].selected) {
                            totalToDelete++;
                            var path = targetServerData.currentPath + dataSource[i].name;
                            var cmd = runCommand({
                                clientName: clientName,
                                command: prefix + "del \"" + path + "\""
                            });
                            cmd.promise.then(function(items) {
                                if (items.toString().toLowerCase().indexOf("error!") >= 0) {
                                    $.notify({
                                        icon: 'glyphicon glyphicon-warning-sign',
                                        message: items.toString()
                                    }, {
                                        type: 'danger',
                                        timer: 3000
                                    });
                                }
                                totalDeleted++;
                                if (totalDeleted === totalToDelete) {
                                    crush.unblock(listPanel.parent());
                                    navigateToDir(false, clientName, prefix);
                                }
                            });
                        }
                    }
                    if (totalToDelete == 0)
                        crush.unblock(listPanel.parent());
                }
            });
        } else if (action == "privs") {
            $.notify("Under progress..");
        } else if (action == "dotitems") {
            curServerPanel.find(".hide-dot-items").parent().click();
        }
    }

    function handleItemDrop(target, clientName, prefix) {
        prefix = prefix == "l" ? "l" : "";
        var curInstance = tabInstances[clientName];
        var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
        var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
        var targetServerPanel = prefix == "" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
        var targetServerData = prefix == "" ? curInstance.leftServerData : curInstance.rightServerData;
        var listPanel = prefix == "" ? curInstance.leftListPanel : curInstance.rightListPanel;
        var toCopy = [],
            toCopyNames = [],
            targetLoc;
        target = $(target);
        if (target.hasClass("name")) {
            var row = target.closest(".server-item-row").data("dataRow");
            targetLoc = row.fullPath;
        } else {
            targetLoc = serverData.currentPath;
        }
        targetLoc = crush.fixURLPath(targetLoc);
        var dataTable = listPanel.data("dataTable");
        var dataSource = dataTable.options.dataSource;
        var i = dataSource.length;
        while (i--) {
            if (dataSource[i].selected) {
                toCopy.push(targetServerData.currentPath + dataSource[i].name);
                toCopyNames.push(dataSource[i].name);
            }
        }
        var msg = "";
        if(prefix == "l")
            msg = "Downloading <strong>" + toCopyNames[0] + "</strong>";
        else
            msg = "Uploading <strong>" + toCopyNames[0] + "</strong>";
        if(toCopyNames.length>0){
            var other = toCopyNames.length - 1;
            msg += " and other " + other + " item(s)";
        }
        var icon = prefix == "l" ? "glyphicon glyphicon-download" : "glyphicon glyphicon-upload";
        $.notify({
            icon: icon,
            message: msg
        }, {
            type: 'success',
            timer: 3000
        });
        transferItems(targetLoc, toCopy, toCopyNames, clientName, prefix);
    }

    function transferItems(targetLoc, toCopy, toCopyNames, clientName, prefix) {
        prefix = prefix == "l" ? "l" : "";
        var command = prefix == "l" ? "get" : "put";
        for (var i = 0; i < toCopy.length; i++) {
            var curItem = toCopy[i];
            var cmd = runCommand({
                clientName: clientName,
                command: command + " \"" + toCopy[i].replace(/ /g, "%20") + "\" \"" + targetLoc.substring(0, targetLoc.length - 1).replace(/ /g, "%20") + "/" + toCopyNames[i].replace(/ /g, "%20") + "\"",
                multithreaded: "true"
            });
            cmd.promise.then(function(items) {});
        }
    }

    function updateNavigationSelect(clientName, prefix) {
        prefix = prefix == "l" ? "l" : "";
        var curInstance = tabInstances[clientName];
        if(!curInstance)
            return;
        var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
        var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
        var panelID = serverPanel.find(".server-settings:first").attr("id");
        var curDir = serverData.currentPath;
        var paths = curDir.split("/");
        serverPanel.find('.navigation-select-parent').empty().append('<select name="server_location" class="navigation-select" id="' + panelID + '_location"></select>');
        var select = serverPanel.find(".navigation-select");
        var len = paths.length - 1;
        var curPath = "";
        for (var i = 0; i < len; i++) {
            curPath += paths[i] + "/";
            if (curPath == curDir)
                select.append('<option selected value="' + curPath + '">' + curPath + '</option>');
            else
                select.append('<option value="' + curPath + '">' + curPath + '</option>');
        }
        select.editableSelect({
            duration: 200,
            filter: false,
            onCreate: function(elem) {
                elem.bind("keydown", function(evt) {
                    var evt = (evt) ? evt : ((event) ? event : null);
                    if (evt.keyCode == 13) {
                        var path = $.trim($(this).val());
                        if (!path.endsWith("/"))
                            path += "/";
                        $(this).val(path);
                        navigateToDir(path, clientName, prefix, false, false, true);
                        $(this).blur();
                    }
                });
            },
            onSelect: function(elem) {
                navigateToDir(elem.text(), clientName, prefix, false, false, true);
            }
        });
    }

    function generateTransferScript(clientName, prefix, selected) {
        prefix = prefix == "l" ? "l" : "";
        selected = selected || "";
        var curInstance = tabInstances[clientName];
        var source = prefix == "l" ? curInstance.info.source : curInstance.info.destination;
        var destination = prefix == "l" ? curInstance.info.destination : curInstance.info.source;
        var sourcePanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
        var sourceData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
        var destinationData = prefix == "l" ? curInstance.rightServerData : curInstance.leftServerData;
        var sourceServerPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
        var destinationServerPanel = prefix == "l" ? curInstance.rightServerPanel : curInstance.leftServerPanel;

        var sourceBookmarkName = sourceServerPanel.data("bookMarkSelected") || "";
        var sourceURL = source.vrl;
        if (sourceBookmarkName) {
            sourceURL = "{bookmark:" + sourceBookmarkName + ":url}";
        }

        var destinationBookmarkName = destinationServerPanel.data("bookMarkSelected") || "";
        var destinationURL = destination.vrl;
        if (destinationBookmarkName) {
            destinationURL = "{bookmark:" + destinationBookmarkName + ":url}";
        }

        var curDir = sourceData.currentPath;
        var curRemoteDir = destinationData.currentPath;
        var toCopy = [],
            toCopyNames = [];
        var dataTable = sourcePanel.data("dataTable");
        var dataSource = dataTable.options.dataSource;
        var i = dataSource.length;
        while (i--) {
            if (dataSource[i].selected) {
                toCopy.push(curDir + dataSource[i].name);
                toCopyNames.push(dataSource[i].name);
                if(selected && dataSource[i].name == selected)
                    selected = "";
            }
        }
        if(selected){
            toCopy.push(curDir + selected);
            toCopyNames.push(selected);
        }
        var command = prefix == "l" ? "put" : "get";
        var commands = [];
        for (var i = 0; i < toCopy.length; i++) {
            var curCommand = toCopy[i];
            commands.push(command + " \"" + curCommand + "\" \"" + curRemoteDir + toCopyNames[i] + "\"");
        }
        var scheduleName = "Transfer" + crush.random();
        var tabName = $.trim($(".nav.active", "#client-tabs").find("a").text());
        if(tabName.toLowerCase().indexOf("client")!=0)
            scheduleName = tabName;
        if(sourceURL == "file:///")
            sourceURL = "file:/";
        schedules.show({
            scheduleName: scheduleName,
            note: "Schedule transfer created on " + moment().format("YYYY-MM-DD hh:mm A"),
            script: "connect " + destinationURL + "\n" + "ldisconnect\nlconnect " + sourceURL + "\nlcwd \"" + curDir + "\"\ncwd \"" + curRemoteDir + "\"\n" + commands.join("\n") + "\n" + "wait" + "\n" + "quit",
            enabled: "true"
        });
    }

    function navigateToDir(dir, clientName, prefix, goUpLevel, params, fromSelect, callback) {
        prefix = prefix == "l" ? "l" : "";
        var curInstance = tabInstances[clientName];
        var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
        var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
        var serverPanel = prefix == "l" ? curInstance.leftServerPanel : curInstance.rightServerPanel;
        var curDir = serverData.currentPath;
        serverData.currentPath = serverData.currentPath || "/";
        var goToPath;
        dir = dir || "/";
        if (fromSelect) {
            goToPath = dir || "/";
        } else {
            if (dir && dir != "/") {
                if (serverData.currentPath == "/" && dir.indexOf("/") == 0) {
                    goToPath = dir;
                } else {
                    goToPath = serverData.currentPath + dir;
                }
            } else
                goToPath = serverData.currentPath;

            if (!goToPath.endsWith("/"))
                goToPath += "/";
        }
        if (goUpLevel) {
            if (goToPath.length > 2) {
                var temp = goToPath.split('/');
                temp.remove(temp.length - 2, temp.length);
                goToPath = temp.join('/');
            }
        }
        goToPath = goToPath || "";
        goToPath = crush.fixURLPath(goToPath);
        serverData.lastPath = serverData.currentPath;
        serverData.currentPath = goToPath;
        crush.block(listPanel.parent());
        serverPanel.find(".filter-control").val("").trigger('textchange');
        function continueLoadingDir() {
            var cmdCWD;
            if (goUpLevel) {
                cmdCWD = runCommand({
                    clientName: clientName,
                    command: prefix + "cwd \"" + goToPath.replace(/ /g, "%20") + "\""
                });
            } else {
                cmdCWD = runCommand({
                    clientName: clientName,
                    command: prefix + "cwd \"" + goToPath.replace(/ /g, "%20") + "\""
                });
            }
            cmdCWD.promise.then(function() {
                var cmd = runCommand({
                    clientName: clientName,
                    command: prefix + "list \"" + goToPath.replace(/ /g, "%20") + "\""
                });
                cmd.promise.then(function(items) {
                    if (typeof items == "string" && (items.toLowerCase().indexOf("error") == 0 || items.toLowerCase().indexOf("refused") == 0)) {
                        if (items.toLowerCase().indexOf("filenotfoundexception") > 0) {
                            renderServerItems([], clientName, prefix, params, goUpLevel);
                            updateNavigationSelect(clientName, prefix);
                            crush.unblock(listPanel.parent());
                        } else {
                            $.notify({
                                icon: 'glyphicon glyphicon-warning-sign',
                                message: 'Connection refused, retrying. <br>' + items
                            }, {
                                type: 'warning',
                                timer: 1000
                            });
                            reconnectClient(clientName, prefix, function(flag) {
                                if (flag) {
                                    continueLoadingDir();
                                } else {
                                    crush.unblock(listPanel.parent());
                                }
                            });
                        }
                    } else {
                        var items_info = items;
                        items = items.listing;
                        renderServerItems(items, clientName, prefix, params, goUpLevel, items_info.quota);
                        updateNavigationSelect(clientName, prefix);
                        crush.unblock(listPanel.parent());
                    }
                    if(callback)
                        callback();
                });
            });
        }
        continueLoadingDir();
    }

    function renderServerItems(items, clientName, prefix, selectFirst, goUpLevel, quota) {
        prefix = prefix == "l" ? "l" : "";
        var panelDtInstance;
        var curInstance = tabInstances[clientName];
        if(!curInstance)
            return;
        var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
        var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
        var hidden = 0;

        function processBeforeRender(data) {
            if (isDotItemsHidden(clientName, prefix) && data) {
                var _data = [];
                for (var i = 0; i < data.length; i++) {
                    var curItem = data[i];
                    if (curItem.name && curItem.name.indexOf(".") != 0) {
                        _data.push(curItem);
                    } else
                        hidden++;
                }
                return _data;
            }
            return data;
        }
        items = processBeforeRender(items);
        var data = processServerItems(items, serverData.currentPath);
        items = data.items;
        var footer = listPanel.closest(".server-list-panel").find(".server-footer");
        footer.html("<span class='dir-info-text'>" + items.length + " Items (" + data.dirs + " Folders, " + data.files + " Files)</span>");
        if (hidden > 0)
            footer.find("span.dir-info-text").append('<small class="advanced"> (' + hidden + ' Hidden)</small>')
        var dirName = "/";
        if (serverData.currentPath.length > 2) {
            var path = serverData.currentPath + "";
            path = path.substr(0, path.length - 1);
            path = path.split("/");
            dirName = path.pop() || "/";
        }
        var i = items.length;
        while (i--) {
            items[i].name = unescape(items[i].name);
        }
        footer.append('<span class="current-dir-name"><i class="fa fa-folder-o fa-fw"></i> ' + crush.middleEllipsis(dirName, 34, "&hellip;") + '</span>');
        if(typeof quota != "undefined" && quota)
        {
            footer.find(".current-dir-name").append("<span class='quota'>Available " + quota + "</span>");
        }
        if (selectFirst && items.length > 0) {
            items[0].selected = "selected";
            var selection = {
                dirs: 0,
                files: 0
            };
            if (items[0].type == "dir")
                selection.dirs++;
            else
                selection.files++;
            var dirsLbl = selection.dirs > 1 ? "folders" : "folder";
            var filesLbl = selection.files > 1 ? "files" : "file";
            if (selection.dirs && selection.files) {
                footer.append("<span class='selection-text'><span>Selected " + selection.dirs + " " + dirsLbl + ", " + selection.files + " " + filesLbl + ".</span></span>");
            } else if (selection.dirs) {
                footer.append("<span class='selection-text'><span>Selected " + selection.dirs + " " + dirsLbl + ". </span></span>");
            } else {
                footer.append("<span class='selection-text'><span>Selected " + selection.files + " " + filesLbl + ". </span></span>");
            }
        }
        if (listPanel.data("heightSet")) {
            var height = listPanel.height();
            listPanel.height(height - 45);
            listPanel.removeData("heightSet");
        }
        if (listPanel.data("dataTable")) {
            var height = listPanel.height();
            panelDtInstance = listPanel.data("dataTable");
            delete panelDtInstance.options.originalDS;
            panelDtInstance.rebind({
                height: height,
                dataSource: items
            }).scroll("up");
        } else {
            var height = listPanel.height();
            listPanel.dataTable({
                dataSource: items,
                height: height,
                lineHeight: 25,
                template: "<div class='custom-data-row server-item-row " + prefix + "side {{type}} {{selected}}' _index='{{index}}'><span class='name' title='{{name}}'><span class='check-box'><input type='checkbox' {{checked}} /></span> <i class='fa fa-file-o fa-fw'></i><i class='fa fa-folder fa-fw'></i> {{name}}</span><span class='size' data-toggle='tooltip' data-placement='right' title='{{size}}'>{{sizeF}}</span><span class='modified'>{{formattedDate}}</span><span class='privs advanced'>{{permissions}}</span></div>",
                emptyTemplate: '<p class="text-center">Nothing to show...</p>',
                minLinesToShow: 100,
                onDoubleClick: function(evt) {
                    handleServerItemEvent(evt, "dblClick", clientName, prefix);
                },
                onClick: function(evt) {
                    handleServerItemEvent(evt, "click", clientName, prefix);
                },
                onContext: function(evt) {
                    handleServerItemEvent(evt, "context", clientName, prefix);
                },
                onKeyDown: function(evt) {
                    handleServerItemEvent(evt, "keydown", clientName, prefix);
                },
                onKeyUp: function(evt) {
                    handleServerItemEvent(evt, "keyup", clientName, prefix);
                }
            });
        }
        var panel = curInstance.panel;
        panel.find(".list-group").each(function() {
            var dataTable = $(this).data("dataTable");
            if (!dataTable && !$(this).data("heightSet")) {
                var height = $(this).height();
                $(this).height(height + 45);
                $(this).data("heightSet", true);
            }
        });
        if (goUpLevel && serverData.lastPath) {
            var i = items.length;
            panelDtInstance = listPanel.data("dataTable");
            while (i--) {
                if (items[i].fullPath + "/" == serverData.lastPath) {
                    makeItemSelection({
                        start: i
                    }, clientName, prefix);
                    panelDtInstance.scrollToIndex(i);
                    i = 0;
                }
            }
        } else
            serverData.lastSelectedIndex = 0;
        fluidUI.resize();
    }


    function handleServerItemEvent(evt, type, clientName, prefix) {
        prefix = prefix == "l" ? "l" : "";
        if (!evt)
            return;
        var delay = (function() {
            var timer = 0;
            return function(callback, ms) {
                clearTimeout(timer);
                timer = setTimeout(callback, ms);
            };
        })();
        var curInstance = tabInstances[clientName];
        var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
        var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
        crush.removeRangeSelection();
        var target = $(evt.target);
        var targetElem = target.hasClass('server-item-row') ? target : target.closest('.server-item-row');
        listPanel.focus();
        if (type == "context") {
            evt.preventDefault();
            evt.stopPropagation();
        } else if (type == "dblClick") {
            var dataRow;
            if (targetElem.length > 0) {
                dataRow = target.closest('.server-item-row').data("dataRow");
            }
            if (dataRow) {
                if (dataRow.type == "dir") {
                    navigateToDir(dataRow.name, clientName, prefix);
                }
            }
        } else if (type == "click") {
            var meta = evt.ctrlKey || evt.metaKey;
            if(evt && evt.target && $(evt.target).is("input[type='checkbox']"))
            {
                meta = true;
            }

            var start = parseInt(targetElem.attr("_index"));
            var end;
            if (evt.shiftKey) {
                end = serverData.lastSelectedIndex;
                if (typeof end != "undefined") {
                    if (end < start) {
                        var hold = start;
                        start = end;
                        end = hold;
                    }
                }
            }
            makeItemSelection({
                start: start,
                end: end
            }, clientName, prefix, evt.shiftKey, meta);
        } else if (type == "keyup") {
            if (evt.which) {
                if (evt.which == 27 || evt.metaKey || evt.ctrlKey || listPanel.data("selectAll")) {
                    serverData.filterWord = false;
                    listPanel.find(".word-suggest").remove();
                    return false;
                }
                if (evt.which == 46) {
                    return false;
                }
                var word = serverData.filterWord || "";
                var varKey = $.getChar(evt);
                if (evt.which == 8) {
                    varKey = -1;
                    evt.preventDefault();
                    evt.stopPropagation();
                }
                if (varKey) {
                    if (varKey == -1) {
                        if (word.length == 1)
                            word = "";
                        else
                            word = word.substr(0, word.length - 1);
                    } else {
                        var c = String.fromCharCode(varKey);
                        word += c + "";
                    }
                    word = word.ltrim();
                    listPanel.find(".word-suggest").remove();
                    if (word && $.trim(word).length > 0) {
                        listPanel.append('<span class="word-suggest">' + word + '</span>');
                        serverData.filterWord = word;
                    }
                    if (word) {
                        var dataTable = listPanel.data("dataTable");
                        var dataSource = dataTable.options.dataSource;
                        var i = 0;
                        var found = "no-match";
                        while (i < dataSource.length) {
                            if (dataSource[i].name.toLowerCase().indexOf(word.toLowerCase()) == 0) {
                                makeItemSelection({
                                    start: i
                                }, clientName, prefix, evt.shiftKey, evt.shiftKey);
                                dataTable.scrollToIndex(i);
                                found = "found-match";
                                i = dataSource.length;
                            }
                            i++;
                        }
                        listPanel.find(".word-suggest").addClass(found);
                    }
                    delay(function() {
                        serverData.filterWord = false;
                        listPanel.find(".word-suggest").remove();
                    }, 2000);
                    evt.preventDefault();
                    evt.stopPropagation();
                    return false;
                }
            }
        } else if (type == "keydown") {
            if (evt.which == 46) {
                handleContextEvents("delete", $("<span></span>"), clientName, prefix);
                evt.preventDefault();
                evt.stopPropagation();
                return false;
            }
            if (evt.which == 8) {
                varKey = -1;
                evt.preventDefault();
                evt.stopPropagation();
                return false;
            }
            if (evt.which == 65 && (evt.metaKey || evt.ctrlKey)) {
                var dataTable = listPanel.data("dataTable");
                var dataSource = dataTable.options.dataSource;
                makeItemSelection({
                    start: 0,
                    end: dataSource.length
                }, clientName, prefix, false, false, evt);
                serverData.lastSelectedIndex = 0;
                listPanel.data("selectAll", true);
                evt.preventDefault();
                evt.stopPropagation();
                return false;
            } else if (evt.which == 13 || (evt.which == 40 && (evt.ctrlKey || evt.metaKey))) // On enter or Cmd + right arrow
            {
                listPanel.removeData("selectAll");
                var item = serverData.lastSelectedIndex;
                if (typeof item !== "undefined") {
                    item = parseInt(item);
                    var dataTable = listPanel.data("dataTable");
                    var dataSource = dataTable.options.dataSource;
                    var dataRow = dataSource[item];
                    if (dataRow && dataRow.type == "dir") {
                        serverData.filterWord = false;
                        listPanel.find(".word-suggest").remove();
                        navigateToDir(dataRow.name, clientName, prefix, false, true);
                    }
                    evt.preventDefault();
                    evt.stopPropagation();
                    return false;
                }
            } else if (evt.which == 38 && (evt.ctrlKey || evt.metaKey)) // On Cmd + left arrow
            {
                listPanel.removeData("selectAll");
                navigateToDir(false, clientName, prefix, true, true);
                serverData.lastSelectedIndex = 0;
                serverData.filterWord = false;
                listPanel.find(".word-suggest").remove();
                evt.preventDefault();
                evt.stopPropagation();
                return false;
            } else if (evt.which == 38 || evt.which == 40) // On up/down arrows
            {
                listPanel.removeData("selectAll");
                var item = serverData.lastSelectedIndex || 0;
                if (typeof item !== "undefined") {
                    var dataTable = listPanel.data("dataTable");
                    var dataSource = dataTable.options.dataSource;
                    var toSelect;
                    if (evt.which == 38) {
                        if (item - 1 >= 0)
                            toSelect = item - 1;
                    } else {
                        if (item + 2 <= dataSource.length)
                            toSelect = item + 1;
                    }
                    if (typeof toSelect != "undefined") {
                        serverData.filterWord = false;
                        listPanel.find(".word-suggest").remove();
                        makeItemSelection({
                            start: toSelect
                        }, clientName, prefix, evt.shiftKey, evt.shiftKey);
                        dataTable.scrollToIndex(item);
                    }
                }
                evt.preventDefault();
                evt.stopPropagation();
                return false;
            } else if (evt.which == 32) // spcebar scroll stop
            {
                listPanel.removeData("selectAll");
                evt.preventDefault();
                evt.stopPropagation();
                return false;
            } else {
                listPanel.removeData("selectAll");
            }
        }
    }

    function makeItemSelection(range, clientName, prefix, shift, meta, evt) {
        prefix = prefix == "l" ? "l" : "";
        var curInstance = tabInstances[clientName];
        var listPanel = prefix == "l" ? curInstance.leftListPanel : curInstance.rightListPanel;
        var serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
        var dataTable = listPanel.data("dataTable");
        var dataSource = dataTable.options.dataSource;
        var selection = {
            dirs: 0,
            files: 0
        };
        if (dataSource && dataSource.length > 0) {
            var allSelected = true;
            if(evt && typeof evt.selectAll != "undefined"){
                var i = dataSource.length;
                while (i--) {
                    if (evt.selectAll)
                        dataSource[i].selected = "selected";
                    else
                        dataSource[i].selected = "";
                    dataSource[i].checked = "";
                    if (dataSource[i].selected == "selected") {
                        dataSource[i].checked = "checked";
                        if (dataSource[i].type == "dir")
                            selection.dirs++;
                        else
                            selection.files++;
                    }
                    else{
                        allSelected = false;
                    }
                }
            }
            else{
                if (typeof range.end == "undefined") {
                    var i = dataSource.length;
                    while (i--) {
                        if (!meta)
                            dataSource[i].selected = "";
                        if (i === range.start) {
                            var selected = "";
                            if (meta && !shift)
                                selected = dataSource[i].selected ? "" : "selected";
                            else
                                selected = "selected";
                            dataSource[i].selected = selected;
                            if (dataSource[i].selected == "selected")
                                dataSource[i].checked = "checked";
                        }
                        dataSource[i].checked = "";
                        if (dataSource[i].selected == "selected") {
                            dataSource[i].checked = "checked";
                            if (dataSource[i].type == "dir")
                                selection.dirs++;
                            else
                                selection.files++;
                        }
                        else{
                            allSelected = false;
                        }
                    }
                    serverData.lastSelectedIndex = range.start;
                } else {
                    var i = dataSource.length;
                    while (i--) {
                        if (!meta)
                            dataSource[i].selected = "";
                        if (i >= range.start && i <= range.end) {
                            var selected = "";
                            if (meta && !shift)
                                selected = dataSource[i].selected ? "" : "selected";
                            else
                                selected = "selected";
                            dataSource[i].selected = selected;
                            if (dataSource[i].selected == "selected")
                                dataSource[i].checked = "checked";
                        }
                        if (dataSource[i].selected == "selected") {
                            if (dataSource[i].type == "dir")
                                selection.dirs++;
                            else
                                selection.files++;
                        }
                        else{
                            allSelected = false;
                        }
                    }
                }
            }
            if(allSelected){
                listPanel.closest(".server-list-panel").find(".sub-header").find("input[type='checkbox']").prop("checked", true);
            }
            else
            {
                listPanel.closest(".server-list-panel").find(".sub-header").find("input[type='checkbox']").prop("checked", false);
            }
            dataTable.options.dataSource = dataSource;
            dataTable.rebind();
        }
        var footer = listPanel.closest(".server-list-panel").find(".server-footer");
        footer.find(".selection-text").remove();
        if (selection.dirs || selection.files) {
            var dirsLbl = selection.dirs > 1 ? "folders" : "folder";
            var filesLbl = selection.files > 1 ? "files" : "file";
            if (selection.dirs && selection.files) {
                footer.append("<span class='selection-text'><span>Selected " + selection.dirs + " " + dirsLbl + ", " + selection.files + " " + filesLbl + ".</span></span>");
            } else if (selection.dirs) {
                footer.append("<span class='selection-text'><span>Selected " + selection.dirs + " " + dirsLbl + ". </span></span>");
            } else {
                footer.append("<span class='selection-text'><span>Selected " + selection.files + " " + filesLbl + ". </span></span>");
            }
        }
        serverData.currentSelection = selection;
        if(prefix == "l")
            curInstance.leftServerData.currentSelection = selection;
        else
            curInstance.rightServerData.currentSelection = selection;
    }

    function processServerItems(items, path) {
        var dirItems = [];
        var fileItems = [];
        path = path || "/";
        if(!items)
            items = [];
        var i = items.length;
        if ($.isArray(items)) {
            while (i--) {
                items[i].type = items[i].type.toLowerCase();
                items[i].sizeF = crush.formatBytes(items[i].size);
                var date = items[i].modified;
                items[i].formattedDate = "-";
                items[i].selected = items[i].selected || "";
                items[i].fullPath = path + items[i].name;
                if (date) {
                    var dt = new Date(parseInt(date));
                    if (dt)
                        items[i].formattedDate = dt.format("mm/dd/yyyy hh:nn a/p");
                }
                var type = items[i].type;
                if (typeof type != "undefined" && type == "dir")
                    dirItems.push(items[i]);
                else
                    fileItems.push(items[i]);
            }
        }
        dirItems.sort(function(a, b) {
            if (a.name.toLowerCase() < b.name.toLowerCase()) {
                return -1;
            }
            if (a.name.toLowerCase() > b.name.toLowerCase()) {
                return 1;
            }
            return 0;
        });

        fileItems.sort(function(a, b) {
            if (a.name.toLowerCase() < b.name.toLowerCase()) {
                return -1;
            }
            if (a.name.toLowerCase() > b.name.toLowerCase()) {
                return 1;
            }
            return 0;
        });
        items = dirItems.concat(fileItems);
        return {
            items: items,
            dirs: dirItems.length,
            files: fileItems.length
        };
    }

    function getconnectURL(clientName, prefix) {
        prefix = prefix == "l" ? "l" : "";
        var curInstance = tabInstances[clientName];
        if (curInstance) {
            if (prefix == "l")
                return curInstance.leftServerData.connectionURL;
            else
                return curInstance.rightServerData.connectionURL;
        }
        return {};
    }

    function runCommand(params) {
        var $q = jQuery.Deferred();
        var data = {
            command: "process_command"
        };
        for (item in params) {
            if (item == "command")
                data.command_str = crush.fixChars(params[item]);
            else if (item == "clientName")
                data.client = params[item];
            else
                data[item] = params[item];
        }
        crush.showLoading(true);
        var promise = crush.data.ajax(data);
        $.when(promise).done(function(xhr) {
            $q.resolve(xhr);
        }).fail(function(xhr) {
            if (xhr.status == 200) {
                try {
                    $q.resolve(eval(xhr.responseText));
                } catch (ex) {
                    console.log(ex);
                    $q.resolve([]);
                }
            } else
                $q.resolve([]);
        }).always(function() {
            crush.hideLoading(true);
        });
        if (data.client == loadedClientName) {
            var cmd = params.displayCommand || params.command;
            clientLog[loadedClientName].logData.unshift({
                text: "Command : " + unescape(cmd)
            });
            if (dtInstance) {
                dtInstance.rebind({
                    dataSource: clientLog[loadedClientName].logData
                }).scroll("up");
            }
        }
        return {
            xhr: promise,
            promise: $q.promise()
        };
    }
    function processQueue(data, queue) {
        data = data || "";
        var curInstance = tabInstances[loadedClientName];
        if (!curInstance)
            return;
        var queueType = queue + "";
        var queueDT = curInstance.panel.find("." + queue + "");
        if (queue == "queue")
            queueDT = curInstance.panel.find(".inqueue");
        var _totalCompleted = 0;
        if (queue == "completed")
            _totalCompleted = totalCompleted;
        var queueCount = curInstance.panel.find("." + queue + "-count");
        var queueMenu = curInstance.panel.find("." + queue + "-menu");
        var sidebarProgressInfo = curInstance.panel.find(".progress-info");
        var _queue = [];
        if (data) {
            _queue = data.split("\n").removeByVal("");
        }
        var i = _queue.length;
        if (i > 0) {
            if (_totalCompleted)
                queueCount.text(_totalCompleted).show();
            else
                queueCount.text(i).show();
            queueMenu.show();
        } else {
            queueCount.text("").hide();
            queueMenu.hide();
        }
        var queueData = [];
        while (i--) {
            var text = _queue[i];
            if (text) {
                queueData.push({
                    text: text
                });
            }
        }
        if (queueDT.data("dataTable")) {
            var instance = queueDT.data("dataTable");
            var highlightIndex = queueDT.find(".highlight").attr("_index");
            instance.rebind({
                dataSource: queueData
            }).scroll("up");
            if(typeof highlightIndex != "undefined"){
                queueDT.find(".custom-data-row[_index='"+highlightIndex+"']").addClass("highlight");
            }
        } else {
            var dt = queueDT.dataTable({
                lineHeight: 20,
                height: 58,
                dataSource: queueData,
                //isolatedScroll: true,
                minLinesToShow: 200,
                template: "<div class='custom-data-row' _index='{{index}}'><pre>{{text}}</pre></div>"
            });
            if ((queueType == "failed" || queueType == "completed") && !queueDT.data("menuAdded")) {
                queueDT.data("menuAdded", true);
                var contextMenu = $('#processedQueueItemsContext');
                queueDT.contextMenu({
                    menu: "processedQueueItemsContext",
                    useClientPosition: true
                }, function(action, el, pos, text, evt) {
                    handleQueueItemContextEvents(action, loadedClientName, evt, queueDT, queueType);
                }).bind("onBeforeContextMenu", function(evt, args) {
                    if (args && args.target) {
                        contextMenu.find(".remove").hide();
                        if (queueType == "failed")
                            contextMenu.find(".remove").show();
                        if ($(args.target).is("pre")) {
                            contextMenu.find(".disabled").removeClass("disabled");
                            $(args.target).closest(".custom-data-row").addClass('highlight');
                        } else {
                            contextMenu.find(".retry, .remove").addClass("disabled");
                        }
                    }
                }).bind("onContextMenuClose", function(evt, args){
                    queueDT.find(".highlight").removeClass('highlight');
                });
            } else if (queueType == "queue" && !queueDT.data("menuAdded")) {
                queueDT.data("menuAdded", true);
                var contextMenu = $('#currentQueueItemsContext');
                queueDT.contextMenu({
                    menu: "currentQueueItemsContext",
                    useClientPosition: true
                }, function(action, el, pos, text, evt) {
                    handleQueueItemContextEvents(action, loadedClientName, evt, queueDT, queueType);
                }).bind("onBeforeContextMenu", function(evt, args) {
                    if (args && args.target) {
                        if ($(args.target).is("pre")) {
                            contextMenu.find(".disabled").removeClass("disabled");
                            $(args.target).closest(".custom-data-row").addClass('highlight');
                        } else {
                            contextMenu.find("li").addClass("disabled");
                        }
                    }
                }).bind("onContextMenuClose", function(evt, args){
                    queueDT.find(".highlight").removeClass('highlight');
                });
            }
        }
    }

    function handleQueueItemContextEvents(action, clientName, evt, queue, queueType) {
        if (queueType == "queue") {
            if (evt && $(evt.target).is("pre") && action == "remove") {
                var cmd = "clear_" + queueType;
                cmd = cmd.replace("completed", "success");
                $.when(crush.data.ajax({
                    command: cmd,
                    client: loadedClientName,
                    specific_item: $(evt.target).text()
                })).done(function(_data) {});
            } else if (action == "clear") {
                var cmd = "clear_" + queueType;
                cmd = cmd.replace("completed", "success");
                $.when(crush.data.ajax({
                    command: cmd,
                    client: loadedClientName
                })).done(function(_data) {});
            }
        } else {
            if (evt && $(evt.target).is("pre") && action == "retry") {
                var cmd = "clear_" + queueType;
                cmd = cmd.replace("completed", "success");
                $.when(crush.data.ajax({
                    command: cmd,
                    client: loadedClientName,
                    specific_item: $(evt.target).text()
                })).done(function(_data) {});
                runCommand({
                    clientName: clientName,
                    command: $(evt.target).text()
                });
            } else if (evt && $(evt.target).is("pre") && action == "remove") {
                var cmd = "clear_" + queueType;
                cmd = cmd.replace("completed", "success");
                $.when(crush.data.ajax({
                    command: cmd,
                    client: loadedClientName,
                    specific_item: $(evt.target).text()
                })).done(function(_data) {});
            } else {
                if (action == "retryall") {
                    var commands = [];
                    var dataTable = queue.data("dataTable");
                    var data = dataTable.options.dataSource;
                    for (var i = 0; i < data.length; i++) {
                        var cmd = data[i].text;
                        if (commands.indexOf(cmd) < 0) {
                            commands.push(cmd);
                            var _cmd = "clear_" + queueType;
                            _cmd = _cmd.replace("completed", "success");
                            $.when(crush.data.ajax({
                                command: _cmd,
                                client: loadedClientName,
                                specific_item: cmd
                            })).done(function(_data) {});
                        }
                    }
                    runCommand({
                        clientName: clientName,
                        command: commands.join("\n")
                    });
                } else if (action == "clear") {
                    var cmd = "clear_" + queueType;
                    cmd = cmd.replace("completed", "success");
                    $.when(crush.data.ajax({
                        command: cmd,
                        client: loadedClientName
                    })).done(function(_data) {});
                }
            }
        }
    }

    function processStats(data) {
        data = data || "";
        var curInstance = tabInstances[loadedClientName];
        if (!curInstance)
            return;
        var actionPanel = curInstance.panel.find(".actions").empty();
        // if(!actionPanel.data("eventsAdded")){
        //     actionPanel.data("eventsAdded", true);
        //     actionPanel.on("click", function(evt){
        //         if($(evt.target).is(".cancel-button"))
        //         {
        //             var target = $(evt.target).closest(".stat-item");
        //             var metadata = target.find(".metadata");
        //             var src = metadata.find(".src").text();
        //             var dest = metadata.find(".dest").text();
        //             var _get = metadata.find(".get").text();
        //             if(confirm("Are you sure you wish to cancel transferring : " + src + "?"))
        //             {
        //                 var cmd = "cancel_action";
        //                 $.when(crush.data.ajax({
        //                     command: cmd,
        //                     client: loadedClientName,
        //                     src: src,
        //                     dest: dest,
        //                     get : _get
        //                 })).done(function(_data) {});
        //             }
        //         }
        //     });
        // }
        var sidebarProgressInfo = curInstance.panel.find(".progress-info");
        if (data) {
            var stats = data.split("\n").removeByVal("");
            if (stats && stats.length > 0) {
                var objStats = [],
                    global_uploaded = 0,
                    global_totalSize = 0,
                    global_time = 0;
                for (var i = 0; i < stats.length; i++) {
                    var info = stats[i].split(";").removeByVal("");
                    //console.log(info);
                    if (info.length > 4) {
                        info[3] = info[3] ? parseInt(info[3]) : 1;
                        info[4] = info[4] ? parseInt(info[4]) : 0;
                        info[5] = info[5] ? parseInt(info[5]) : 0;
                        info[7] = info[7] ? parseInt(info[7]) : 0;
                        var get = info[6] && $.trim(info[6].toLowerCase()) == "get";
                        var data = {
                            id: info[0],
                            src: info[1],
                            dest: info[2],
                            seconds: info[3],
                            time: crush.formatTime(info[3]),
                            position: info[4],
                            uploaded: crush.formatBytes(info[4]),
                            totalSize: crush.formatBytes(info[5]),
                            maxPosition: info[5],
                            get: get,
                            speed: crush.formatBytes(info[7])
                        };
                        global_uploaded += data.position;
                        global_totalSize += data.maxPosition;
                        if (global_time == 0)
                            global_time = data.seconds;
                        global_time = data.seconds > global_time ? data.seconds : global_time;
                        if (data.maxPosition)
                            data.perc = Math.ceil((100 * data.position) / data.maxPosition);
                        else
                            data.perc = 0;
                        if (data.position) {
                            data.remainingTime = crush.formatTime(Math.ceil((data.seconds * data.maxPosition) / data.position) - data.seconds);
                        } else
                            data.remainingTime = "*";
                        data.name = data.src.split("/").pop();
                        objStats.push(data);
                    }
                }
                var globalInfo = {
                    global_total: objStats.length
                };
                if (!global_time)
                    global_time = 1;
                if (global_uploaded)
                    globalInfo.global_perc = Math.ceil((100 * global_uploaded) / global_totalSize);
                else
                    globalInfo.global_perc = 0;
                if (global_uploaded) {
                    globalInfo.global_remainingTime = crush.formatTime(Math.ceil((global_time * global_totalSize) / global_uploaded) - global_time);
                } else
                    globalInfo.global_remainingTime = "*";
                globalInfo.global_speed = crush.formatBytes(Math.ceil(global_uploaded / global_time));
                globalInfo.global_uploaded = crush.formatBytes(global_uploaded);
                globalInfo.global_totalSize = crush.formatBytes(global_totalSize);
                sidebarProgressInfo.find(".value").text(globalInfo.global_perc);
                var globalData;
                if (stats.length > 1) {
                    globalData = globalInfo;
                }
                else{
                    globalData = false;
                }
                isTransferInProgress = actionPanel.append(curInstance.statsTemplate({
                    data: objStats,
                    globalInfo: globalData
                })).find(".stat-item:first").length > 0;
            }
        } else {
            if (isTransferInProgress) {
                curInstance.panel.find(".refresh-button").click();
            }
            isTransferInProgress = false;
        }
        if (!isTransferInProgress) {
            curInstance.panel.find(".cancel-button-action").addClass('disabled');
            sidebarProgressInfo.hide();
        } else {
            curInstance.panel.find(".cancel-button-action").removeClass('disabled');
            sidebarProgressInfo.show();
        }
    }

    function startPolling(clientName) {
        if (!clientLog[clientName])
            clientLog[clientName] = {}
        clientLog[clientName].logData = clientLog[clientName].logData || [];
        if (!loadedTab)
            loadedTab = $("#tab-1");
        var dt = loadedTab.find(".log-panel").dataTable({
            lineHeight: 20,
            height: 158,
            dataSource: clientLog[clientName].logData,
            minLinesToShow: 200,
            template: "<div class='custom-data-row' _index='{{index}}'><pre>{{text}}</pre></div>"
        });
        dtInstance = dt.data("dataTable");
        if (logInterval) {
            clearInterval(logInterval);
            logInterval = false;
        }
        if (!logInterval) {
            var clientName = loadedClientName + "";

            function reloadLog(cb) {
                $.when(crush.data.ajax({
                    command: "log",
                    client: clientName
                })).done(function(data) {
                    if (data) {
                        if (clientName == loadedClientName) {
                            var newItems = data.split("\n");
                            var i = newItems.length;
                            while (i--) {
                                var text = newItems[i];
                                if (text) {
                                    clientLog[clientName].logData.unshift({
                                        text: text
                                    });
                                }
                            }
                            clientLog[clientName].logData = clientLog[clientName].logData || [];
                            var dt = loadedTab.find(".log-panel").dataTable({
                                dataSource: clientLog[clientName].logData,
                                lineHeight: 20,
                                minLinesToShow: 200,
                                height: 58,
                                //isolatedScroll: true,
                                template: "<div class='custom-data-row' _index='{{index}}'><pre>{{text}}</pre></div>"
                            });
                            dtInstance = dt.data("dataTable");
                            dtInstance.rebind({
                                dataSource: clientLog[clientName].logData
                            });
                        }
                        if (cb)
                            cb();
                    }
                });
            }
            logInterval = setInterval(function() {
                if (!$('body').hasClass('bottom-panel-hidden')) {
                    reloadLog();
                }
            }, 1000);
            reloadLog();
            forceLogReload = reloadLog;
        }
        if (statsInterval) {
            clearTimeout(statsInterval);
            statsInterval = false;
        }
        if (!statsInterval) {
            function fetchServerStatus() {
                $.when(crush.data.ajax({
                    command: "stats",
                    client: loadedClientName
                })).done(function(_data) {
                    processStats(_data);
                    statsInterval = setTimeout(fetchServerStatus, 1000);
                }).fail(function(){
                    statsInterval = setTimeout(fetchServerStatus, 1000);
                });
            }
            // statsInterval = setInterval(function() {
            //     fetchServerStatus();
            // }, 1000);
            fetchServerStatus();
        }

        if (queueInterval) {
            clearInterval(queueInterval);
            queueInterval = false;
        }
        if (!queueInterval) {
            function fetchFileQueue() {
                $.when(crush.data.ajax({
                    command: "queue",
                    client: loadedClientName,
                    queue_type: "pending"
                })).done(function(data) {
                    processQueue(data, "queue");
                });

                $.when(crush.data.ajax({
                    command: "queue",
                    client: loadedClientName,
                    queue_type: "success"
                })).done(function(data) {
                    processQueue(data, "completed");
                });

                $.when(crush.data.ajax({
                    command: "queue",
                    client: loadedClientName,
                    queue_type: "failed"
                })).done(function(data) {
                    processQueue(data, "failed");
                });
            }
            queueInterval = setInterval(function() {
                fetchFileQueue();
            }, 5000);
            fetchFileQueue();
        }
    }

    var fluidUI = (function() {
        //Default values
        var windowResizeAdded, minBodyHeight = 500, minBodyWidth = 500, padding = 10, dimensionPerc = {
            serversMax: 80,
            bottomPanelMax: 80,
            servers: crush.storage("serverHeight") || 70,
            serverWidth: crush.storage("serverWidth") || 50
        };
        //Percentages of value
        function getPerc(val, perc) {
            return ((val * perc) / 100);
        }

        function resize() {
            var servers = $(".connections", loadedTab);
            var bottomPanel = $('.server-bottom-panel', loadedTab);
            var settings = prefs;
            var wrapper = servers.find('.server-panel-wrapper');
            if (settings && settings.action_list_position && settings.action_list_position.toString() == "right") {
                if(!loadedTab.hasClass('action-list-right')){
                    loadedTab.addClass('action-list-right').removeClass('action-list-bottom');
                    wrapper.removeClass('col-lg-12').addClass('col-lg-9');
                    loadedTab.find(".action-side-bar").find(".panel").append(loadedTab.find(".action-bar-content"));
                    loadedTab.find(".action-side-bar").find(".panel").find(".panel-title").after(loadedTab.find(".action-list-tab-bottom-header").find(".progress-info"));
                }
                setTimeout(function(){
                    servers.find(".action-side-bar").find(".panel").height(wrapper.height()- 23);
                    servers.find(".action-side-bar").find(".action-bar-content").height(wrapper.height()-65);
                });
            }
            else
            {
                if(!loadedTab.hasClass('action-list-bottom')){
                    loadedTab.addClass('action-list-bottom').removeClass('action-list-right');
                    wrapper.removeClass('col-lg-9').addClass('col-lg-12').removeClass('right-space');
                    loadedTab.find(".action-bar-bottom-content").append(loadedTab.find(".action-bar-content"));
                    loadedTab.find(".action-list-tab-bottom-header").append(loadedTab.find(".progress-info"));
                }
            }
            var windowHeight = $(window).height() - 60; //30px top tab height and 30px footer
            if (windowHeight < minBodyHeight)
                windowHeight = minBodyHeight;
            var serverHeight = getPerc(windowHeight, dimensionPerc.servers);
            var bottomPanelHeight = getPerc(windowHeight, 100 - dimensionPerc.servers) + padding; // Adding size as to cover bottom area just above footer
            servers.height(serverHeight);
            bottomPanel.height(bottomPanelHeight);
            var serverListHeight = serverHeight - 175;//minus height of header, footer, filter panel etc.
            servers.find(".list-group:visible").each(function(){
                $(this).height(serverListHeight);
                var dataTable = $(this).data("dataTable");
                if (dataTable) {
                    dataTable.options.height = serverListHeight;
                    dataTable.rebind();
                }
                else
                {
                    $(this).data("height", serverListHeight);
                    $(this).height(serverListHeight);
                }
            });

            var bottomListHeight = bottomPanelHeight - 35;//minus height of header, footer, filter panel etc.
            bottomPanel.find(".list-group").each(function(){
                $(this).height(bottomListHeight);
                if($(this).is(".log-panel"))
                    $(this).height(bottomListHeight - 30);
                var dataTable = $(this).data("dataTable");
                if (dataTable) {
                    dataTable.options.height = bottomListHeight;
                    dataTable.rebind();
                }
                else
                {
                    $(this).data("height", bottomListHeight);
                }
            });
            loadedTab.find(".action-bar-bottom-content").find(".action-bar-content").height(bottomListHeight + 10);

            var windowWidth = wrapper.width();
            if(wrapper.hasClass('right-space'))
                windowWidth -= 0;
            else
                windowWidth += 25;
            if(settings.action_list_position && settings.action_list_position.toString() !== "right"){
                windowWidth = $(window).width() - 65;
            }
            if (windowWidth < minBodyWidth)
                windowWidth = minBodyWidth;
            var serverWidth = getPerc(windowWidth, dimensionPerc.serverWidth);
            var server2Width = windowWidth - serverWidth;
            servers.find(".server-panel-1:visible").width(serverWidth);
            servers.find(".server-panel-2:visible").width(server2Width);
            servers.find('.server-panel-1').resizable("option", "maxWidth", windowWidth - 300);
        };

        function bind(tab) {
            if(!windowResizeAdded){
                windowResizeAdded = true;
                $(window).resize(function(e) {
                    if(!e.target || e.target == window)
                        resize();
                });
                //On tab load, resize items
                $('a[data-toggle="tab"]', "#client-tabs").on('shown.bs.tab', function (e) {
                    resize();
                    setTimeout(function(){
                        resize();
                    }, 100);
                });
                $("body").removeClass('loading');
            }
            var elem = $(tab).find('.connections:not(.resizeAdded)').addClass('resizeAdded').parent().each(function(){
                var that = $(this);
                var windowHeight = $(window).height() - 60; //30px top tab height and 30px footer
                if (windowHeight < minBodyHeight)
                    windowHeight = minBodyHeight;
                that.resizable({
                    handles: 's',
                    alsoResizeReverse : that.next(),
                    // ghost: true,
                    // helper: "resizable-helper",
                    minHeight:250,
                    maxHeight : windowHeight - 100,
                    resize : function(event, ui){
                        var currentHeight = ui.size.height;
                        var windowHeight = $(window).height() - 60; //30px top tab height and 30px footer
                        if (windowHeight < minBodyHeight)
                            windowHeight = minBodyHeight;
                        var serverHeightPerc = ((100 * currentHeight)/windowHeight);
                        crush.storage("serverHeight", serverHeightPerc);
                        dimensionPerc.servers = serverHeightPerc;
                        $(tab).find(".top-panel").css("height", "auto");
                        $(tab).find(".bottom-panel").css("width", "auto");
                        resize();
                    },
                    stop : function(event, ui){
                        // var currentHeight = ui.size.height;
                        // var windowHeight = $(window).height() - 60; //30px top tab height and 30px footer
                        // if (windowHeight < minBodyHeight)
                        //     windowHeight = minBodyHeight;
                        // var serverHeightPerc = ((100 * currentHeight)/windowHeight);
                        // crush.storage("serverHeight", serverHeightPerc);
                        // dimensionPerc.servers = serverHeightPerc;
                        // $(tab).find(".top-panel").css("height", "auto");
                        // resize();
                    }
                });
            });
            $(tab).find(".top-panel").each(function() {
                var wrapper = tab.find('.server-panel-wrapper');
                $(this).find('.server-panel-1:not(.resizeAdded)').addClass('resizeAdded').each(function(){
                    var that = $(this);
                    that.resizable({
                        handles: 'e',
                        minWidth: 300,
                        alsoResizeReverse : that.next(),
                        stop : function(event, ui){
                            that.css("height", "auto");
                            that.next().css("height", "auto");
                            var currentWidth = ui.size.width;
                            var windowWidth = wrapper.width();
                            if(wrapper.hasClass('right-space'))
                                windowWidth -= 5;
                            else
                                windowWidth += 15;
                            if (windowWidth < minBodyWidth)
                                windowWidth = minBodyWidth;
                            var serverWidthPerc = ((100 * currentWidth)/windowWidth);
                            crush.storage("serverWidth", serverWidthPerc);
                            dimensionPerc.serverWidth = serverWidthPerc;
                            $(tab).find(".bottom-panel").css("width", "auto");
                        }
                    });
                });
            });
        }

        return {
            bind: bind,
            resize: resize
        }
    })();

    var schedules = (function() {
        function save(info, clientName, schedule, cb) {
            if (!info)
                return false;
            var curInstance = tabInstances[clientName];

            function getVRL(vrl) {
                var server = "";
                if (vrl) {
                    var serverText = vrl;
                    try {
                        var _url;
                        if (serverText)
                            _url = new URI(serverText);
                        else
                            _url = new URL(serverText);
                        var protocol = _url.protocol() || "file:";
                        protocol += "//";
                        var port = _url.port();
                        var host = _url.host();
                        var user = _url.username();
                        var pass = crush.encryptDecryptPass(_url.password());
                        if (user || pass)
                            server = protocol + user + ":" + pass + "@" + host;
                        else
                            server = protocol + host;
                    } catch (ex) {
                        server = vrl;
                    }
                }
                return server;
            }
            if (info.id) {
                remove(info.id);
            }
            if (info.scheduleName) {
                remove(false, info.scheduleName);
            }
            savePrefs({
                newSchedule: info,
                callback: cb
            });
        }

        function remove(id, name) {
            if (prefs.schedules && prefs.schedules.length > 0) {
                var _schedules = prefs.schedules;
                var toKeep = [];
                for (var i = 0; i < _schedules.length; i++) {
                    if (id) {
                        if (_schedules[i].id != id)
                            toKeep.push(_schedules[i]);
                    }
                    if (name) {
                        if (_schedules[i].scheduleName && _schedules[i].scheduleName.toLowerCase() != name.toLowerCase())
                            toKeep.push(_schedules[i]);
                    }
                }
                prefs.schedules = toKeep;
            }
        }

        function get(id, name) {
            if (prefs.schedules && prefs.schedules.length > 0) {
                var schedules = prefs.schedules;
                var toKeep = [];
                for (var i = 0; i < schedules.length; i++) {
                    if (id) {
                        if (schedules[i].id == id)
                            return schedules[i];
                    }
                    if (name) {
                        if (schedules[i].scheduleName && schedules[i].scheduleName.toLowerCase() == name.toLowerCase())
                            return schedules[i];
                    }
                }
            }
            return false;
        }

        function refresh() {
            var schedulesList = $('#schedule-list', "#_schedulesDialog");
            loadPrefs(function() {
                crush.hideLoading(true);
                schedulesList.empty().append('<li class="list-group-item text-center"><div>Nothing to display</div></li>');
                if (prefs.schedules && prefs.schedules.length > 0) {
                    schedulesList.empty();
                    var schedules = prefs.schedules;
                    schedules.sort(function(a, b) {
                        if (a.scheduleName.toLowerCase() < b.scheduleName.toLowerCase()) {
                            return -1;
                        }
                        if (a.scheduleName.toLowerCase() > b.scheduleName.toLowerCase()) {
                            return 1;
                        }
                        return 0;
                    });
                    for (var i = 0; i < schedules.length; i++) {
                        var curItem = schedules[i];
                        if (curItem.id) {
                            var desc = curItem.note ? "<p>" + curItem.note + "</p>" : "";
                            var status = curItem.enabled && curItem.enabled.toString() == "true" ? "schedule-enabled-flag" : "schedule-disabled-flag";
                            var type = curItem.scheduleType ? "<p><small>" + curItem.scheduleType + "</small></p>" : "";
                            var item = $('<li class="list-group-item schedule-item ' + status + '"><div class="row"><div class="col-md-1 text-center"><br><input name="cb_' + i + '" id="cb_' + i + '" type="checkbox" rel="' + curItem.id + '"> <br></div><div class="col-md-9"><strong>' + curItem.scheduleName + '</strong>' + desc + type + '</div><div class="col-md-2"><div class="text-right" style="margin-bottom:10px;margin-top:-10px;"><a class="run" href="javascript:void(0);" style="font-size:24px;" data-toggle="tooltip" data-placement="right" title="Run Schedule Now"><i class="fa fa-play fa-fw"></i></a></div><div><span style="float:right;"><a data-toggle="tooltip" data-placement="right" title="Edit Schedule" class="edit" href="javascript:void(0);"><i class="fa fa-pencil fa-fw"></i></a> <a data-toggle="tooltip" data-placement="right" title="Re-construct" class="reconstruct" href="javascript:void(0);"><i class="fa fa-refresh fa-fw"></i></a> <a data-toggle="tooltip" data-placement="right" title="Remove Schedule" class="remove" href="javascript:void(0);"><i class="fa fa-trash fa-fw"></i></a></span></div></div></div></li>');
                            item.data("data-item", curItem);
                            schedulesList.append(item);
                        }
                    }

                    if (schedulesList.find("li.schedule-item").length == 0)
                        schedulesList.append('<li class="list-group-item text-center"><div>Nothing to display</div></li>');

                    schedulesList.find(".remove,.edit,.reconstruct").unbind().click(function() {
                        var elem = $(this).closest("li");
                        if ($(this).is(".remove")) {
                            bootbox.confirm("Are you sure you want to remove selected schedule?", function(result) {
                                if (result) {
                                    removeM([elem.find("input").attr("rel")]);
                                }
                            });
                        } else if($(this).is(".edit")){
                            create(get(elem.find("input").attr("rel")));
                        } else if($(this).is(".reconstruct")){
                            reConstruct(elem.find("input").attr("rel"));
                        }
                        return false;
                    });

                    schedulesList.find(".run").unbind().click(function() {
                        var elem = $(this).closest("li");
                        var data = elem.data("data-item");
                        $("#_schedulesDialog").find(".modal-footer").find("button").click();
                        var hasTab;
                        $(".nav", "#client-tabs").find("a").each(function(){
                            var text = $.trim($(this).text());
                            if(text.toLowerCase() == data.scheduleName.toLowerCase()){
                                hasTab = $(this);
                            }
                        });
                        if(hasTab){
                            hasTab.trigger('click');
                            var clientName = hasTab.attr("clientname");
                            var panel = $("#" + hasTab.attr("href").split("#")[1]);
                            disconnectServer(clientName, "l", function(){
                                disconnectServer(clientName, "", function(){
                                    continueRun(panel, clientName);
                                });
                            });
                        }
                        else
                        {
                            addNewClient(false, data.scheduleName, function(panel, clientName) {
                                continueRun(panel, clientName);
                            });
                        }

                        function continueRun(panel, clientName){
                            clientName = clientName || loadedClientName;
                            $.when(crush.data.ajax({
                                command: "run_schedule",
                                client: clientName,
                                scheduleName: data.scheduleName
                            })).done(function(_data) {
                                $.notify({
                                    icon: 'glyphicon glyphicon-check',
                                    message: "Schedule started, please check log panel for more information."
                                }, {
                                    type: 'success',
                                    timer: 3000
                                });

                                function runT() {
                                    showScheduleProgress(panel, clientName, panel.attr("id").replace("tab-"));
                                }

                                window.runT = runT;
                                runT();
                                setTimeout(function(){
                                    runT();
                                }, 1000);
                            });
                        }
                        return false;
                    });

                    $('[data-toggle="tooltip"]', "#_schedulesDialog").tooltip({
                        container: "body"
                    });
                }
            });
        }

        function showScheduleProgress(panel, clientName, clientLink) {
            if (tabInstances[clientName]) {
                var curInstance = tabInstances[clientName];
                var cmd = runCommand({
                    clientName: clientName,
                    command: "lpwd"
                });
                cmd.promise.then(function(status) {
                    if ($.trim(status).length > 0 && $.trim(status).toLowerCase() != "not connected.") {
                        var dir = $.trim(status);
                        dir = dir.substr(1, dir.lastIndexOf("\"") - 1);
                        afterConnect("true", clientName, "l", dir);
                    }
                });
                var cmd = runCommand({
                    clientName: clientName,
                    command: "pwd"
                });
                cmd.promise.then(function(status) {
                    if ($.trim(status).length > 0 && $.trim(status).toLowerCase() != "not connected.") {
                        var dir = $.trim(status);
                        dir = dir.substr(1, dir.lastIndexOf("\"") - 1);
                        afterConnect("true", clientName, "", dir);
                    }
                });
            }
            var lServerPanel = panel.find(".server-panel-1");
            var rServerPanel = panel.find(".server-panel-2");
            clientTabs.find('a[clientLink="' + clientLink + '"]').attr("clientName", clientName);

            function afterClientCreated() {
                bindEvents(clientName);
                //resizeBottomPanel();
                $("input[id$='hide_dot_items']", panel).each(function() {
                    var elm = $(this);
                    var prefix = $(this).hasClass('left-server') ? "l" : "";
                    if (isDotItemsHidden(clientName, prefix))
                        elm.attr("checked", "checked");
                    else
                        elm.removeAttr("checked");
                });
                $("input[id$='host']", panel).each(function() {
                    var elm = $(this);
                    elm.typeahead({
                        minLength: 0,
                        hint: true,
                        highlight: true
                    }, {
                        name: 'hosts',
                        limit: 10,
                        source: crush.substringMatcher(bookmarksData.hosts, elm)
                    });
                });
                $("input[id$='port']", panel).each(function() {
                    var elm = $(this);
                    elm.typeahead({
                        minLength: 0,
                        hint: true,
                        highlight: true
                    }, {
                        name: 'hosts',
                        limit: 10,
                        source: crush.substringMatcher(bookmarksData.ports, elm)
                    });
                });
                panel.attr("clientName", clientName);
                if (tabInstances[clientName]) {
                    var curInstance = tabInstances[clientName];
                    var cmd = runCommand({
                        clientName: clientName,
                        command: "lpwd"
                    });
                    cmd.promise.then(function(status) {
                        if ($.trim(status).length > 0 && $.trim(status).toLowerCase() != "not connected.") {
                            var dir = $.trim(status);
                            dir = dir.substr(1, dir.lastIndexOf("\"") - 1);
                            afterConnect("true", clientName, "l", "");
                        }
                    });
                    var cmd = runCommand({
                        clientName: clientName,
                        command: "pwd"
                    });
                    cmd.promise.then(function(status) {
                        if ($.trim(status).length > 0 && $.trim(status).toLowerCase() != "not connected.") {
                            var dir = $.trim(status);
                            dir = dir.substr(1, dir.lastIndexOf("\"") - 1);
                            afterConnect("true", clientName, "", "");
                        }
                    });
                }
                clientTabs.find('a[clientLink="' + clientLink + '"]').attr("clientName", clientName);
            }
            getClientInfo(clientName, function(xhr) {
                if (xhr) {
                    var info = $.xml2json(xhr);
                    if (tabInstances[clientName]) {
                        tabInstances[clientName].info = info;

                        function bindInfo(serverPanel, dataItem) {
                            if (serverPanel && dataItem) {
                                var panelID = serverPanel.find(".server-settings:first").attr("id");
                                try {
                                    var _url;
                                    if (dataItem.vrl)
                                        _url = new URI(dataItem.vrl);
                                    else
                                        _url = new URL(dataItem.vrl);
                                    dataItem.protocol = _url.protocol() || "file:";
                                    dataItem.protocol += "//";
                                    dataItem.port = _url.port();
                                    dataItem.host = _url.host();
                                    if (dataItem.host.endsWith(":" + dataItem.port)) {
                                        dataItem.host = dataItem.host.replace(":" + dataItem.port, "");
                                    }
                                } catch (ex) {}
                                setTimeout(function(){
                                    $('#' + panelID + '_protocol', serverPanel).val(dataItem.protocol || "file://").trigger('change', [true]);
                                    $('#' + panelID + '_host', serverPanel).val(dataItem.host || "");
                                    $('#' + panelID + '_port', serverPanel).val(dataItem.port || "").typeahead('val', dataItem.port || "");
                                    $('#' + panelID + '_username', serverPanel).val(dataItem.username || "");
                                    $('#' + panelID + '_password', serverPanel).val(dataItem.password || "");
                                }, 100);
                            }
                        }
                        bindInfo(curInstance.leftServerPanel, info.source);
                        bindInfo(curInstance.rightServerPanel, info.destination);
                    }
                }
                afterClientCreated(true);
            });
        }

        function removeM(ids) {
            for (var i = 0; i < ids.length; i++) {
                remove(ids[i]);
            }
            savePrefs({
                callback: function() {
                    $.notify({
                        icon: 'glyphicon glyphicon-check',
                        message: "Schedule(s) removed."
                    }, {
                        type: 'success',
                        timer: 3000
                    });
                    refresh();
                }
            });
        }

        function show(createSchedule) {
            var dlg = bootbox.dialog({
                title: "<i class='fa fa-calendar fa-fw'></i> Schedules : ",
                message: $('#schedulesDialog').html(),
                size: "large",
                value: "",
                onEscape: true,
                backdrop: true,
                buttons: {
                    ok: {
                        label: "OK",
                        className: "btn-success save",
                        callback: function() {}
                    }
                }
            });
            dlg.attr("id", "_schedulesDialog");
            crush.showLoading(true);
            var btns = dlg.find("#top-button");
            var schedulesList = $('#schedule-list', dlg).empty();
            btns.find(".btn").unbind().bind("click", function(e) {
                e.preventDefault();
                e.stopPropagation();
                if ($(this).is(".add")) {
                    create();
                } else if ($(this).is(".refresh")) {
                    refresh();
                } else if ($(this).is(".select-all")) {
                    schedulesList.find("input[type='checkbox']").prop("checked", "checked");
                } else if ($(this).is(".select-none")) {
                    schedulesList.find("input[type='checkbox']").removeAttr("checked");
                } else if ($(this).is(".remove")) {
                    var count = schedulesList.find("input[type='checkbox']:checked:visible").length;
                    if (count) {
                        bootbox.confirm("Are you sure you want to remove selected " + count + " schedule(s)?", function(result) {
                            if (result) {
                                var ids = [];
                                schedulesList.find("input[type='checkbox']:checked:visible").each(function() {
                                    ids.push($(this).attr("rel"));
                                });
                                removeM(ids);
                            }
                        });
                    }
                }
            });

            var delay = (function() {
                var timer = 0;
                return function(callback, ms) {
                    clearTimeout(timer);
                    timer = setTimeout(callback, ms);
                };
            })();

            var filter = $("#filter", dlg).unbind("keyup").keyup(function(evt, data) {
                var evt = (evt) ? evt : ((event) ? event : null);
                if (evt.keyCode == 27) {
                    $(this).val("").trigger("keyup");
                    return false;
                }
                var phrase = $.trim($(this).val());
                if (phrase.length < 1) {
                    phrase = "";
                }
                if ($(this).data("last_searched") && $(this).data("last_searched") === phrase) {
                    return false;
                }

                function startFilter() {
                    if (phrase && phrase.length > 1) {
                        schedulesList.find("li.list-group-item").hide();
                        var items = schedulesList.find("li.list-group-item:Contains('" + phrase + "')").show();
                    } else
                        schedulesList.find("li.list-group-item").show();
                }
                if (data) {
                    startFilter();
                } else {
                    delay(function() {
                        startFilter();
                    }, 200);
                }
            });
            refresh();
            if (createSchedule) {
                create(createSchedule)
            }
        }


        function create(schedule) {
            scheduleTime = "8:00 AM", scheduleTimeList = [];
            var dlg = bootbox.dialog({
                title: "<i class='fa fa-calendar fa-fw'></i> Schedule Settings : ",
                message: $('#createScheduleDialog').html(),
                size: "large",
                value: "",
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: "Cancel",
                        className: "btn-default cancel",
                        callback: function() {}
                    },
                    ok: {
                        label: "OK",
                        className: "btn-success save",
                        callback: function() {
                            var _dialog = $('#_scheduleDialog');
                            var schedule_name = $.trim($("#schedule_name", _dialog).val());
                            var enabled = $("#enabled", _dialog).is(":checked");
                            var schedule_note = $.trim($("#schedule_note", _dialog).val());
                            var schedule_script = $.trim($("#schedule_script", _dialog).val());
                            var max_runtime_hours = $("#max_runtime_hours", _dialog).val();
                            var max_runtime_minutes = $("#max_runtime_minutes", _dialog).val();
                            var scheduleTime = $("#scheduleTime", _dialog).val();
                            var scheduleTime_jobs = $("#scheduleTime_jobs", _dialog).val();
                            var single = $("#single", _dialog).is(":checked");
                            var client_log_enabled = $("#client_log_enabled", _dialog).is(":checked");
                            var client_log = $.trim($("#client_log", _dialog).val());
                            var minutes = $("#minutes", _dialog).val();
                            var days = $("#days", _dialog).val();
                            var weeks = $("#weeks", _dialog).val();
                            var months = $("#months", _dialog).val();
                            var weekDays = "";
                            var monthDays = "";
                            var type = $(".scheduleRadios:checked", _dialog).val();
                            $(".week-day.active", _dialog).each(function() {
                                weekDays += "(" + $(this).attr("_day") + ")";
                            });
                            $(".month-day.active", _dialog).each(function() {
                                monthDays += "(" + $(this).attr("_day") + ")";
                            });
                            var info = {};
                            if (!schedule || !schedule.id)
                                info.id = crush.random();
                            else
                                info.id = schedule.id;
                            info.enabled = enabled.toString();
                            info.single = single.toString();
                            info.scheduleName = schedule_name;
                            info.note = schedule_note;
                            info.script = schedule_script;
                            info.client_log_enabled = client_log_enabled.toString();
                            info.client_log = client_log.toString();
                            info.schedule_name = schedule_name;
                            info.scheduleType = type;
                            info.max_runtime_hours = max_runtime_hours;
                            info.max_runtime_minutes = max_runtime_minutes;
                            info.scheduleTime = scheduleTime;
                            info.scheduleTime_jobs = scheduleTime_jobs;
                            info.monthlyAmount = months;
                            info.dailyAmount = days;
                            info.weeklyAmount = weeks;
                            info.minutelyAmount = minutes;
                            info.weekDays = weekDays;
                            info.monthDays = monthDays;
                            info.nextRun = "0";

                            function continueSaveSchedule() {
                                save(info, loadedClientName, schedule, function() {
                                    refresh();
                                });
                            }

                            if (!schedule_name || crush.hasSpecialCharacters(schedule_name)) {
                                $.notify({
                                    icon: 'glyphicon glyphicon-warning-sign',
                                    message: 'Schedule name can not be empty or have special chars like : "@ # % & : = + ? / ."'
                                }, {
                                    placement: {
                                        align: 'center'
                                    },
                                    offset: {
                                        y: 200
                                    },
                                    type: 'danger',
                                    timer: 1000,
                                    z_index: 99999
                                });
                                $('#schedule_name', _dialog).focus();
                                return false;
                            }
                            if (((schedule && schedule.scheduleName != schedule_name) || !schedule) && schedules.hasName(schedule_name)) {
                                bootbox.confirm("Schedule with name '" + schedule_name + "' exists, do you want to overwrite?", function(result) {
                                    if (result) {
                                        continueSaveSchedule();
                                        _dialog.find(".cancel").trigger("click");
                                    } else {
                                        $('#schedule_name', _dialog).focus().select();
                                    }
                                });
                                return false;
                            }
                            continueSaveSchedule();
                        }
                    }
                }
            });

            dlg.attr("id", "_scheduleDialog");

            $("#client_log_enabled", dlg).unbind().bind("change", function() {
                if ($(this).is(":checked"))
                    $("#client_log_panel", dlg).show();
                else
                    $("#client_log_panel", dlg).hide();
            });

            $(".scheduleRadios", dlg).unbind().bind("change", function() {
                var val = $(this).val();
                switch (val) {
                    case "manually":
                        $(".option_minutely,.option_daily,.option_weekly,.option_monthly").hide();
                        break;
                    case "minutely":
                        $(".option_minutely").show();
                        $(".option_daily,.option_weekly,.option_monthly").hide();
                        break;
                    case "daily":
                        $(".option_minutely,.option_daily").show();
                        $(".option_weekly,.option_monthly").hide();
                        break;
                    case "weekly":
                        $(".option_minutely,.option_daily,.option_weekly").show();
                        $(".option_monthly").hide();
                        break;
                    case "monthly":
                        $(".option_minutely,.option_daily,.option_monthly").show();
                        $(".option_weekly").hide();
                        break;
                    default:
                        break;
                }
            });

            $('#schedule_script', dlg).suggest('{', {
                data: prefs.bookmarks,
                appendText: '',
                map: function(curBm) {
                    var url;
                    if (curBm) {
                        if (curBm.user) {
                            url = curBm.protocol + curBm.user + ":" + crush.getStars(curBm.pass) + "@" + curBm.host;
                        } else
                            url = curBm.protocol + curBm.host;
                        if (curBm.name)
                            url = "<strong>" + curBm.name + "</strong> : <br>" + url;
                        if (curBm.defaultPath && curBm.defaultPath != "/")
                            url = url + "<br><small>(" + curBm.defaultPath + ")</small>";
                    }
                    if (url) {
                        return {
                            value: "bookmark:" + curBm.name + ":url}\r",
                            text: url
                        }
                    } else {
                        return false;
                    }
                }
            });

            setTimeout(function() {
                if ($("#schedule_script").val() != "") {
                    $("#_scheduleDialog #schedule_script").attr('rows', 1);
                    $("#_scheduleDialog #schedule_script").after('<button type="button" id="more" class="btn col-sm-12" data-toggle="collapse" data-target="#about" style="margin-top: 1px;">');
                    $('#more').html('<span class="glyphicon glyphicon-chevron-up"></span> Less Info');
                    $('#more').unbind().click(function() {
                        if ($('#more span').hasClass('glyphicon-chevron-down')) {
                            $('#more').html('<span class="glyphicon glyphicon-chevron-up"></span> Less Info');
                            $("#_scheduleDialog #schedule_script").attr('rows', 1);
                        } else {
                            $('#more').html('<span class="glyphicon glyphicon-chevron-down"></span> More Info');
                            $("#_scheduleDialog #schedule_script").attr('rows', 5);
                        }
                    });
                }

                $('#_scheduleDialog #scheduleTime').datetimepicker({
                    format: 'LT'
                });

                $('#_scheduleDialog #timepicker1').datetimepicker({
                    format: 'LT'
                });

                function formatTime(time) {
                    var result = false,
                        m, n;
                    time = time.trim();
                    //var re = /^\s*([01]?\d|2[0-3]):?([0-5]\d)\s*$/;
                    var re = /^\s*([01]?\d|2[0-3]):?([0-5]\d) [APap][mM]$/;
                    var re2 = /^\s*([01]?\d|2[0-3]):?([0-5]\d)[APap][mM]$/;
                    var regex = /^(0?[1-9]|1[012])(:[0-5]\d) [APap][mM]$/;
                    var regex2 = /^(0?[1-9]|1[012])(:[0-5]\d)[APap][mM]$/;
                    if ((regex.test(time) || regex2.test(time)) && time != '') {
                        if ((m = time.match(re)) || (n = time.match(re2))) {
                            time = time.trim().slice(-2);
                            if (!m == false)
                                result = (m[1].length === 2 ? "" : "0") + m[1] + ":" + m[2];
                            else if (!n == false)
                                result = (n[1].length === 2 ? "" : "0") + n[1] + ":" + n[2];

                            result = result + " " + time;
                        }
                    }
                    if (result)
                        return result;
                    else
                        return time;
                }

                function checkIfArrayIsUnique(myarray) {
                    for (var i = 0; i < myarray.length; i++) {
                        if (myarray[i] != '') {
                            if (myarray.indexOf(myarray[i]) !== myarray.lastIndexOf(myarray[i])) {
                                return false;
                            }
                        }
                    }
                    return true;
                }

                function checkIfArrayIsUniqueWithValue(myarray, value) {
                    for (var i = 0; i < myarray.length; i++) {
                        if (myarray[i] != '') {
                            if (formatTime(myarray[i].toUpperCase()) == formatTime(value.toUpperCase())) {
                                return false;
                            }
                        }
                    }
                    return true;
                }

                function setRemoveTimeCall() {
                    $("#_scheduleDialog .removefromtimelist").unbind("click").bind("click", function() {
                        for (var i = 0; i < scheduleTimeList.length; i++) {
                            if (scheduleTimeList[i] == $(this).attr("_id")) {
                                scheduleTimeList.splice(i, 1);

                                $("span[_id='" + $(this).attr("_id") + "']").remove();
                                $(this).remove();
                                //break; //remove this line to remove all occurrences
                            }
                        }
                        scheduleTime = "";
                        var timearray = scheduleTimeList;
                        for (var i = 0; i < timearray.length; i++) {
                            if (i == 0)
                                scheduleTime += timearray[i];
                            else
                                scheduleTime += "," + timearray[i];
                        }
                        $("#_scheduleDialog #scheduleTime_jobs").val(scheduleTime);
                    });
                }

                $('#_scheduleDialog #addinTimeList').click(function() {
                    var timevalue = $.trim($("#_scheduleDialog #scheduleTime").val());
                    if (!timevalue)
                        return false;
                    if (!formatTime(timevalue) && timevalue != '') {
                        $("#_scheduleDialog #scheduleTime").val("");
                        alert(timevalue + " is invalid Time");
                        return false;
                    } else if (!checkIfArrayIsUniqueWithValue(scheduleTimeList, timevalue)) {
                        $("#_scheduleDialog #scheduleTime").val("");
                        alert(timevalue + " is already exists.");
                        return false;
                    } else {
                        timevalue = formatTime(timevalue);
                        scheduleTimeList.push(timevalue);
                        var timearray = scheduleTimeList;
                        $("#_scheduleDialog .time-list-fieldset").html("");
                        timearray.sort(function(a, b) {
                            return new Date('1970/01/01 ' + a) - new Date('1970/01/01 ' + b);
                        });
                        scheduleTime = "";
                        for (var i = 0; i < timearray.length; i++) {
                            if (timearray[i] != '') {
                                timearray[i] = timearray[i].toUpperCase();
                                var timeliststr = "<span class='time-list excludeXML' _index='1' value='" + timearray[i] + "' style='' disabled _id='" + timearray[i] + "'>" + timearray[i] + "</span><span class='pointer ui-icon ui-icon-close removefromtimelist time-list-remove-icon' _id='" + timearray[i] + "'></span>";
                                if (i == 0)
                                    scheduleTime += timearray[i];
                                else
                                    scheduleTime += "," + timearray[i];

                                $("#_scheduleDialog .time-list-fieldset").append(timeliststr);
                                setRemoveTimeCall();
                            }
                        }
                        $("#_scheduleDialog #scheduleTime_jobs").val(scheduleTime);
                        setRemoveTimeCall();
                        $("#_scheduleDialog #scheduleTime").val("");
                    }
                });
            }, 300);

            if (schedule) {
                var _dialog = $('#_scheduleDialog');
                $("#schedule_name", _dialog).val(schedule.scheduleName);
                $("#schedule_note", _dialog).val(schedule.note);
                $("#schedule_script", _dialog).val(schedule.script);
                $("#max_runtime_hours", _dialog).val(schedule.max_runtime_hours);
                $("#max_runtime_minutes", _dialog).val(schedule.max_runtime_minutes);
                $("#scheduleTime", _dialog).val(schedule.scheduleTime);
                $("#scheduleTime_jobs", _dialog).val(schedule.scheduleTime_jobs)
                $("#minutes", _dialog).val(schedule.minutelyAmount);
                $("#days", _dialog).val(schedule.dailyAmount);
                $("#weeks", _dialog).val(schedule.weeklyAmount);
                $("#months", _dialog).val(schedule.monthlyAmount);
                if (schedule.enabled && schedule.enabled.toString() == "true")
                    $("#enabled", _dialog).prop("checked", "checked");
                if (schedule.single && schedule.single.toString() == "true")
                    $("#single", _dialog).prop("checked", "checked");

                if (schedule.client_log_enabled && schedule.client_log_enabled.toString() == "true") {
                    $("#client_log_enabled", _dialog).prop("checked", "checked");
                    $("#client_log_panel", _dialog).show();
                    $("#client_log", _dialog).val(schedule.client_log);
                } else {
                    $("#client_log_panel", _dialog).hide();
                }

                $(".scheduleRadios[value='" + schedule.scheduleType + "']", _dialog).prop("checked", "checked").trigger("change");
                schedule.monthDays = schedule.monthDays || "";
                var monthDays = schedule.monthDays.split(")(");
                for (var i = 0; i < monthDays.length; i++) {
                    var day = monthDays[i].replace("(", "").replace(")", "");
                    $(".month-day[_day='" + day + "']", _dialog).addClass('active');
                }

                schedule.weekDays = schedule.weekDays || "";
                var weekDays = schedule.weekDays.split(")(");
                for (var i = 0; i < weekDays.length; i++) {
                    var day = weekDays[i].replace("(", "").replace(")", "");
                    $(".week-day[_day='" + day + "']", _dialog).addClass('active');
                }

                setTimeout(function() {
                    if ($("#schedule_script", _dialog).val() != "") {
                        $("#_scheduleDialog #schedule_script").attr('rows', 1);
                        $("#_scheduleDialog #schedule_script").after('<button type="button" id="more" class="btn col-sm-12" data-toggle="collapse" data-target="#about" style="margin-top: 1px;">');
                        $('#more').html('<span class="glyphicon glyphicon-chevron-down"></span> Show more');

                        $('#more').unbind().click(function() {
                            if (!$('#more span').hasClass('glyphicon-chevron-down')) {
                                $('#more').html('<span class="glyphicon glyphicon-chevron-down"></span> Show more');
                                $("#_scheduleDialog #schedule_script").attr('rows', 1);
                            } else {
                                $('#more').html('<span class="glyphicon glyphicon-chevron-up"></span> Show less');
                                $("#_scheduleDialog #schedule_script").attr('rows', 10);
                            }
                        });
                        if (schedule && typeof schedule.id == "undefined") {
                            $('#more').click();
                        }
                    }

                    $('#_scheduleDialog #scheduleTime').datetimepicker({
                        format: 'LT'
                    });
                    $('#_scheduleDialog #timepicker1').datetimepicker({
                        format: 'LT'
                    });

                    function formatTime(time) {
                        var result = false,
                            m, n;
                        time = time.trim();
                        //var re = /^\s*([01]?\d|2[0-3]):?([0-5]\d)\s*$/;
                        var re = /^\s*([01]?\d|2[0-3]):?([0-5]\d) [APap][mM]$/;
                        var re2 = /^\s*([01]?\d|2[0-3]):?([0-5]\d)[APap][mM]$/;
                        var regex = /^(0?[1-9]|1[012])(:[0-5]\d) [APap][mM]$/;
                        var regex2 = /^(0?[1-9]|1[012])(:[0-5]\d)[APap][mM]$/;
                        if ((regex.test(time) || regex2.test(time)) && time != '') {
                            if ((m = time.match(re)) || (n = time.match(re2))) {
                                time = time.trim().slice(-2);
                                if (!m == false)
                                    result = (m[1].length === 2 ? "" : "0") + m[1] + ":" + m[2];
                                else if (!n == false)
                                    result = (n[1].length === 2 ? "" : "0") + n[1] + ":" + n[2];

                                result = result + " " + time;
                            }
                        }
                        if (result)
                            return result;
                        else
                            return time;
                    }

                    function checkIfArrayIsUnique(myarray) {
                        for (var i = 0; i < myarray.length; i++) {
                            if (myarray[i] != '') {
                                if (myarray.indexOf(myarray[i]) !== myarray.lastIndexOf(myarray[i])) {
                                    return false;
                                }
                            }
                        }
                        return true;
                    }

                    function checkIfArrayIsUniqueWithValue(myarray, value) {
                        for (var i = 0; i < myarray.length; i++) {
                            if (myarray[i] != '') {
                                if (formatTime(myarray[i].toUpperCase()) == formatTime(value.toUpperCase())) {
                                    return false;
                                }
                            }
                        }
                        return true;
                    }

                    function setRemoveTimeCall() {
                        $("#_scheduleDialog .removefromtimelist").unbind("click").bind("click", function() {

                            for (var i = 0; i < scheduleTimeList.length; i++) {
                                if (scheduleTimeList[i] == $(this).attr("_id")) {
                                    scheduleTimeList.splice(i, 1);

                                    $("span[_id='" + $(this).attr("_id") + "']").remove();
                                    $(this).remove();
                                    //break; //remove this line to remove all occurrences
                                }
                            }
                            scheduleTime = "";
                            var timearray = scheduleTimeList;
                            for (var i = 0; i < timearray.length; i++) {
                                if (i == 0)
                                    scheduleTime += timearray[i];
                                else
                                    scheduleTime += "," + timearray[i];
                            }
                            $("#_scheduleDialog #scheduleTime_jobs").val(scheduleTime);
                        });
                    }

                    $('#_scheduleDialog #addinTimeList').click(function() {
                        var timevalue = $.trim($("#_scheduleDialog #scheduleTime").val());
                        if (!timevalue)
                            return false;
                        if (!formatTime(timevalue) && timevalue != '') {
                            $("#_scheduleDialog #scheduleTime").val("");
                            alert(timevalue + " is invalid Time");
                            return false;
                        } else if (!checkIfArrayIsUniqueWithValue(scheduleTimeList, timevalue)) {
                            $("#_scheduleDialog #scheduleTime").val("");
                            alert(timevalue + " is already exists.");
                            return false;
                        } else {
                            timevalue = formatTime(timevalue);
                            scheduleTimeList.push(timevalue);
                            var timearray = scheduleTimeList;
                            $("#_scheduleDialog .time-list-fieldset").html("");
                            timearray.sort(function(a, b) {
                                return new Date('1970/01/01 ' + a) - new Date('1970/01/01 ' + b);
                            });
                            scheduleTime = "";
                            for (var i = 0; i < timearray.length; i++) {
                                if (timearray[i] != '') {
                                    timearray[i] = timearray[i].toUpperCase();
                                    var timeliststr = "<span class='time-list excludeXML' _index='1' value='" + timearray[i] + "' style='' disabled _id='" + timearray[i] + "'>" + timearray[i] + "</span><span class='pointer ui-icon ui-icon-close removefromtimelist time-list-remove-icon' _id='" + timearray[i] + "'></span>";
                                    if (i == 0)
                                        scheduleTime += timearray[i];
                                    else
                                        scheduleTime += "," + timearray[i];

                                    $("#_scheduleDialog .time-list-fieldset").append(timeliststr);
                                    setRemoveTimeCall();
                                }
                            }
                            $("#_scheduleDialog #scheduleTime_jobs").val(scheduleTime);
                            setRemoveTimeCall();
                            $("#_scheduleDialog #scheduleTime").val("");
                        }
                    });

                    var timearray = $("#scheduleTime_jobs", _dialog).val().split(",") //taskDesigner.loadedSchedule.scheduleTime.split(",");
                    timearray.sort(function(a, b) {
                        return new Date('1970/01/01 ' + a) - new Date('1970/01/01 ' + b);
                    });
                    //taskDesigner.loadedSchedule.scheduleTimeList = timearray;
                    scheduleTimeList = timearray;
                    $(".time-list-fieldset", _dialog).html("");
                    for (var i = 0; i < timearray.length; i++) {
                        if (timearray[i] != '') {
                            timearray[i] = formatTime(timearray[i].toUpperCase());
                            var timeliststr = "<span type='text' class='time-list excludeXML' _index='1' value='" + timearray[i] + "' style='' disabled _id='" + timearray[i] + "'>" + timearray[i] + "</span><span class='pointer ui-icon ui-icon-close removefromtimelist time-list-remove-icon' _id='" + timearray[i] + "'></span>";
                            $(".time-list-fieldset", _dialog).append(timeliststr);
                            setRemoveTimeCall();
                        }
                    }
                }, 300);
            }
            $(".scheduleRadios:checked", _dialog).trigger("change");
        }

        function reConstruct(id){
            var schedule = get(id);
            if(schedule && schedule.id)
            {
                var recreate = {
                    commands : []
                };
                var script = schedule.script.split("\n");
                for (var i = 0; i < script.length; i++) {
                    var curItem = $.trim(script[i]);
                    if(curItem.indexOf("connect")==0){
                        recreate.connectURL = $.trim(curItem.replace("connect",""));
                        if(recreate.connectURL.indexOf("{bookmark:")==0)
                        {
                            recreate.bookmark = bookmarks.get(false, recreate.connectURL.split(":")[1]);
                        }
                    }
                    else if(curItem.indexOf("lconnect")==0){
                        recreate.lconnectURL = $.trim(curItem.replace("lconnect",""));
                        if(recreate.lconnectURL.indexOf("{bookmark:")==0)
                        {
                            recreate.bookmarkL = bookmarks.get(false, recreate.lconnectURL.split(":")[1]);
                        }
                    }
                    else if(curItem.indexOf("put")==0){
                        recreate.commands.push($.trim(curItem));
                    }
                    // else if(curItem.indexOf("get")==0){
                    //     recreate.commands.push($.trim(curItem));
                    // }
                    else if(curItem.indexOf("lcwd")==0){
                        //recreate.commands.push($.trim(curItem));
                        recreate.ldir = $.trim(curItem.replace("lcwd","")).replace(/\"/g, "");
                    }
                    else if(curItem.indexOf("cwd")==0){
                        recreate.rdir = $.trim(curItem.replace("cwd","")).replace(/\"/g, "");
                    }
                }
                $("#_schedulesDialog").find(".modal-footer").find("button").click();
                var hasTab;
                $(".nav", "#client-tabs").find("a").each(function(){
                    var text = $.trim($(this).text());
                    if(text.toLowerCase() == schedule.scheduleName.toLowerCase()){
                        hasTab = $(this);
                    }
                });
                function continueConstruct(panel, clientName){
                    $('body').addClass('loading');
                    function useBookmark(dataItem, serverPanel, dir)
                    {
                        var panelID = serverPanel.find(".server-settings:first").attr("id");
                        var pass = dataItem.pass || "";
                        if (pass) {
                            pass = crush.encryptDecryptPass(pass, true);
                        }
                        var pbe_pass = dataItem.pbe_pass || "";
                        if (pbe_pass) {
                            pbe_pass = crush.encryptDecryptPass(pbe_pass, true);
                        }
                        var ssh_private_key_pass = dataItem.ssh_private_key_pass || "";
                        if (ssh_private_key_pass) {
                            ssh_private_key_pass = crush.encryptDecryptPass(ssh_private_key_pass, true);
                        }
                        dataItem.defaultPath = dir || dataItem.defaultPath;
                        $('#' + panelID + '_protocol', serverPanel).val(dataItem.protocol || "").trigger('change', [true]);
                        $('#' + panelID + '_host', serverPanel).val(dataItem.host || "");
                        $('#' + panelID + '_port', serverPanel).val(dataItem.port || "").typeahead('val', dataItem.port || "");
                        $('#' + panelID + '_username', serverPanel).val(dataItem.user || "");
                        $('#' + panelID + '_password', serverPanel).val(pass);
                        $('#' + panelID + '_default_path', serverPanel).val(dataItem.defaultPath || "");
                        $('#' + panelID + '_connect', serverPanel).val(dataItem.connect || "");
                        $('#' + panelID + '_cipher', serverPanel).text(dataItem.cipher || "");
                        $('#' + panelID + '_max_threads', serverPanel).val(dataItem.maxThreads || "");
                        if (dataItem.tunnel && dataItem.tunnel.toString() == "true"){
                            $('#' + panelID + '_use_tunnel', serverPanel).prop("checked", "checked");
                        }
                        else{
                            $('#' + panelID + '_use_tunnel', serverPanel).removeProp("checked");
                        }
                        if (pbe_pass) {
                            $('#' + panelID + '_PasswordBaseEncrypt', serverPanel).prop("checked", "checked").trigger("change");
                            $('#' + panelID + '_PasswordBaseEncryptPass', serverPanel).val(pbe_pass);
                        } else {
                            $('#' + panelID + '_PasswordBaseEncrypt', serverPanel).removeProp("checked").trigger("change");
                            $('#' + panelID + '_PasswordBaseEncryptPass', serverPanel).val("");
                        }

                        $('#' + panelID + '_ssh_private_key', serverPanel).val(dataItem.ssh_private_key);
                        $('#' + panelID + '_ssh_private_key_pass', serverPanel).val(dataItem.ssh_private_key_pass);
                        $('#' + panelID + '_knownHostFile', serverPanel).val(dataItem.knownHostFile);
                        if(dataItem.ssh_two_factor && dataItem.ssh_two_factor.toString() == "true")
                            $('#' + panelID + '_ssh_two_factor', serverPanel).prop("checked", "checked");
                        else
                            $('#' + panelID + '_ssh_two_factor', serverPanel).removeProp("checked");

                        if(dataItem.verifyHost && dataItem.verifyHost.toString() == "true")
                            $('#' + panelID + '_verifyHost', serverPanel).prop("checked", "checked");
                        else
                            $('#' + panelID + '_verifyHost', serverPanel).removeProp("checked");

                        if(dataItem.addNewHost && dataItem.addNewHost.toString() == "true")
                            $('#' + panelID + '_addNewHost', serverPanel).prop("checked", "checked");
                        else
                            $('#' + panelID + '_addNewHost', serverPanel).removeProp("checked");
                    }
                    function useURL(_url, serverPanel, dir)
                    {
                        var panelID = serverPanel.find(".server-settings:first").attr("id");
                        if(_url.indexOf("file://")==0)
                        {
                            $('#' + panelID + '_protocol', serverPanel).val("file://").trigger('change', [true]);
                            $('#' + panelID + '_default_path', serverPanel).val(dir || _url.replace("file:/", ""));
                        }
                        else{
                            var url = URI(_url);
                            var pass = url.password() || "";
                            dir = dir || url.directory() || "";
                            $('#' + panelID + '_protocol', serverPanel).val(url.protocol()+"://" || "").trigger('change', [true]);
                            $('#' + panelID + '_host', serverPanel).val(url.hostname() || "");
                            $('#' + panelID + '_port', serverPanel).val(url.port() || "").typeahead('val', url.port() || "");
                            $('#' + panelID + '_username', serverPanel).val(url.username() || "");
                            $('#' + panelID + '_password', serverPanel).val(pass);
                            $('#' + panelID + '_default_path', serverPanel).val(dir);
                        }
                    }
                    var lServerPanel = panel.find(".server-panel-1");
                    var rServerPanel = panel.find(".server-panel-2");
                    if(recreate.bookmark){
                        useBookmark(recreate.bookmark, rServerPanel, recreate.rdir);
                    }
                    else{
                        useURL(recreate.connectURL, rServerPanel, recreate.rdir);
                    }
                    if(recreate.bookmarkL){
                        useBookmark(recreate.bookmarkL, lServerPanel, recreate.ldir);
                    }
                    else{
                        useURL(recreate.lconnectURL, lServerPanel, recreate.ldir);
                    }
                    $('body').addClass('loading');
                    lServerPanel.find(".connect-button:first").trigger("click");
                    rServerPanel.find(".connect-button:first").trigger("click");
                    $('body').addClass('loading');
                    function connected(){
                        $('body').addClass('loading');
                        setTimeout(function(){
                            var files = [];
                            var commands = recreate.commands;
                            for (var i = 0; i < commands.length; i++) {
                                var curItem = commands[i];
                                var path = curItem.split('" "')[0];
                                var text = path.split('"')[1];
                                var file = text.split("/");
                                var fileName = file[file.length-1];
                                files.push(fileName);
                            }
                            var listPanel = lServerPanel.find(".list-group:visible");
                            var dataTable = listPanel.data("dataTable");
                            if(!dataTable)
                                return;
                            var dataSource = dataTable.options.dataSource;
                            var hasChange = false;
                            var firstSelected;
                            for (var i = 0; i < dataSource.length; i++) {
                                if(files.has(dataSource[i].name)){
                                    dataSource[i].checked = "checked";
                                    dataSource[i].selected = "selected";
                                    if(!firstSelected)
                                        firstSelected = i;
                                    hasChange = true;
                                }
                            }
                            if(hasChange)
                            {
                                dataTable.options.dataSource = dataSource;
                                dataTable.rebind();
                                if(firstSelected)
                                {
                                    dataTable.scrollToIndex(firstSelected);
                                }
                            }
                            $('body').removeClass('loading');
                        }, 1000);
                    }
                    var lConnected, rConnected;
                    lServerPanel.one("connected", function(){
                        $('body').addClass('loading');
                        lConnected = true;
                        if(lConnected == rConnected){
                            connected();
                        }
                    });
                    rServerPanel.one("connected", function(){
                        $('body').addClass('loading');
                        rConnected = true;
                        if(lConnected == rConnected){
                            connected();
                        }
                    });
                }
                if(hasTab){
                    hasTab.trigger('click');
                    var clientName = hasTab.attr("clientname");
                    var panel = $("#" + hasTab.attr("href").split("#")[1]);
                    disconnectServer(clientName, "l", function(){
                        disconnectServer(clientName, "", function(){
                            continueConstruct(panel, clientName);
                        });
                    });
                }
                else
                {
                    addNewClient(false, schedule.scheduleName, function(panel, clientName) {
                        continueConstruct(panel, clientName);
                    });
                }
            }
        }

        function XML(data) {
            var xml = [];
            var hasItem = false;

            function prepareXML(info, saved) {
                var _xml = [];
                if (info) {
                    _xml.push('<schedule_subitem type="properties">');
                    for (var item in info) {
                        hasItem = true;
                        if (typeof info[item] == "string")
                            _xml.push('<' + item + '>' + encodeURIComponent(info[item] + "") + '</' + item + '>');
                    }
                    _xml.push('</schedule_subitem>');
                }
                return _xml;
            }
            xml.push('<schedules type="vector">');
            if (prefs.schedules) {
                for (var i = 0; i < prefs.schedules.length; i++) {
                    if (typeof prefs.schedules[i]["temp"] == "undefined") {
                        xml.push.apply(xml, prepareXML(prefs.schedules[i], true));
                    }
                }
            }
            xml.push.apply(xml, prepareXML(data));
            if (!hasItem)
                xml.push('<schedules_subitem type="properties"><temp></temp></schedules_subitem>');
            xml.push('</schedules>');
            return xml.join("\r\n");
        }

        return {
            XML: XML,
            show: show,
            hasName: function(name) {
                return get(false, name);
            }
        }
    })();

    var bookmarks = (function() {
        function remove(id, name) {
            if (prefs.bookmarks && prefs.bookmarks.length > 0) {
                var bookmarks = prefs.bookmarks;
                var toKeep = [];
                for (var i = 0; i < bookmarks.length; i++) {
                    if (id) {
                        if (bookmarks[i].id != id)
                            toKeep.push(bookmarks[i]);
                    }
                    if (name) {
                        if (bookmarks[i].name && bookmarks[i].name.toLowerCase() != name.toLowerCase())
                            toKeep.push(bookmarks[i]);
                    }
                }
                prefs.bookmarks = toKeep;
            }
        }

        function get(id, name) {
            if (prefs.bookmarks && prefs.bookmarks.length > 0) {
                var bookmarks = prefs.bookmarks;
                var toKeep = [];
                for (var i = 0; i < bookmarks.length; i++) {
                    if (id && bookmarks[i].id == id)
                        return bookmarks[i];
                    if (name && bookmarks[i].name && bookmarks[i].name.toLowerCase() == name.toLowerCase())
                        return bookmarks[i];
                }
            }
            return false;
        }

        function save(info, bookmark, cb) {
            if (!info)
                return false;
            if (bookmark) {
                remove(bookmark.id);
                remove(false, bookmark.name);
            }
            savePrefs({
                newBookmark: info,
                callback: cb
            });
        }

        function create(bookmark) {
            var dlg = bootbox.dialog({
                title: "<i class='fa fa-bookmark fa-fw'></i> Bookmark : ",
                message: $('#createBookmarkDialog').html(),
                size: "medium",
                value: "",
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: "Cancel",
                        className: "btn-default cancel",
                        callback: function() {}
                    },
                    ok: {
                        label: "OK",
                        className: "btn-success save",
                        callback: function() {
                            var _dialog = $('#_bookmarkDialog');
                            var protocol = $('#protocol', dlg).val() || "";
                            var host = $('#host', dlg).val() || "";
                            var port = $('#port', dlg).val() || "";
                            var user = $('#username', dlg).val() || "";
                            var pass = $('#password', dlg).val() || "";
                            var path = $('#default_path', dlg).val() || "";
                            var connect = $('#connect', dlg).val() || "";
                            var pbe_pass = $('#pbe_pass', dlg).val() || "";
                            var bookmarkName = $('#bookmark_name', dlg).val() || "";
                            var maxThreads = $('#max_threads', dlg).val() || "";
                            var useTunnel = $('#useTunnel', dlg).is(":checked") + "";
                            var securedData = $('#secureData', dlg).is(":checked") + "";
                            var cipherInfo = $('#cipherValue', dlg).text() || "";

                            var sftpSSHKey = $('#ssh_private_key', dlg).val() || "";
                            var sftpSSHKeyPass = $('#ssh_private_key_pass', dlg).val() || "";
                            var sftpTwoFactor = $('#ssh_two_factor', dlg).is(":checked") + "";
                            var sftpVerifyHost = $('#verifyHost', dlg).is(":checked") + "";
                            var sftpAddHost = $('#addNewHost', dlg).is(":checked") + "";
                            var sftpKnownHostFile = $('#knownHostFile', dlg).val() || "";

                            var serverData = {};
                            if (!$("#PasswordBaseEncrypt", dlg).is(":checked"))
                                pbe_pass = "";

                            if((maxThreads && !crush.isNumeric(maxThreads)) || maxThreads <0){
                                bootbox.alert("Max threads value is not valid.", function(){
                                    setTimeout(function(){
                                        $('#max_threads', dlg).select().focus();
                                    },500);
                                });
                                return false;
                            }

                            function continueSaveBookMark() {
                                serverData.name = $.trim(bookmarkName);
                                serverData.protocol = protocol;
                                serverData.host = $.trim(host);
                                serverData.port = $.trim(port);
                                serverData.user = $.trim(user);
                                serverData.pass = $.trim(pass);
                                serverData.pbe_pass = $.trim(pbe_pass);
                                serverData.defaultPath = $.trim(path);
                                serverData.connect = connect;
                                serverData.cipher = cipherInfo;
                                serverData.maxThreads = maxThreads;
                                serverData.use_tunnel = useTunnel;
                                serverData.secure_data = securedData;

                                serverData.ssh_private_key = sftpSSHKey;
                                serverData.ssh_private_key_pass = sftpSSHKeyPass;
                                serverData.ssh_two_factor = sftpTwoFactor;
                                serverData.verifyHost = sftpVerifyHost;
                                serverData.addNewHost = sftpAddHost;
                                serverData.knownHostFile = sftpKnownHostFile;
                                if (bookmark && bookmark.id)
                                    serverData.id = bookmark.id;
                                else
                                    serverData.id = "Bookmark_" + crush.random();
                                save(serverData, bookmark, function() {
                                    _dialog.find(".modal-footer").find("button.cancel").click();
                                    refresh();
                                });
                            }
                            if (!bookmarkName || crush.hasSpecialCharacters(bookmarkName)) {
                                $.notify({
                                    icon: 'glyphicon glyphicon-warning-sign',
                                    message: 'Bookmark name can not be empty or have special chars like : "@ # % & : = + ? / ."'
                                }, {
                                    placement: {
                                        align: 'center'
                                    },
                                    offset: {
                                        y: 200
                                    },
                                    type: 'danger',
                                    timer: 1000,
                                    z_index: 99999
                                });
                                $('#bookmark_name', dlg).focus();
                                return false;
                            }
                            if (((bookmark && bookmark.name != bookmarkName) || !bookmark) && bookmarks.hasName(bookmarkName)) {
                                bootbox.confirm("Bookmark with name '" + bookmarkName + "' exists, do you want to overwrite?", function(result) {
                                    if (result) {
                                        continueSaveBookMark();
                                    } else {
                                        $('#bookmark_name', dlg).focus().select();
                                    }
                                });
                                return false;
                            }
                            continueSaveBookMark();
                        }
                    }
                }
            });
            dlg.attr("id", "_bookmarkDialog");
            dlg.find(".protocol-input").bind("change", function(evt, noDefaultValues) {
                var ftpOptions = $(this).closest(".bookmark-panel").find(".ftp-option").hide();
                var ftpesOptions = $(this).closest(".bookmark-panel").find(".ftpes-option").hide();
                var httpsOptions = $(this).closest(".bookmark-panel").find(".https-options").hide();
                var httpOptions = $(this).closest(".bookmark-panel").find(".http-options").hide();
                var sftpOptions = $(this).closest(".bookmark-panel").find(".sftp-options").hide();
                if ($(this).val() == "file://") {
                    $(this).closest(".bookmark-panel").find(".non-file-option").hide();
                } else {
                    $(this).closest(".bookmark-panel").find(".non-file-option").show();
                    if (!noDefaultValues) {
                        if ($(this).val() == "ftp://") {
                            $(this).closest(".bookmark-panel").find(".port-input").val("21").typeahead('val', "21");
                        } else if ($(this).val() == "ftps://") {
                            $(this).closest(".bookmark-panel").find(".port-input").val("990").typeahead('val', "990");
                        } else if ($(this).val() == "ftpes://") {
                            $(this).closest(".bookmark-panel").find(".port-input").val("21").typeahead('val', "21");
                        } else if ($(this).val() == "sftp://") {
                            $(this).closest(".bookmark-panel").find(".port-input").val("22").typeahead('val', "22");
                        } else if ($(this).val() == "http://") {
                            $(this).closest(".bookmark-panel").find(".port-input").val("80").typeahead('val', "80");
                        } else if ($(this).val() == "https://") {
                            $(this).closest(".bookmark-panel").find(".port-input").val("443").typeahead('val', "443");
                        } else if ($(this).val() == "smb://") {
                            $(this).closest(".bookmark-panel").find(".port-input").val("445").typeahead('val', "445");
                        }
                    }
                    if ($(this).val() == "ftp://") {
                        ftpOptions.show();
                    } else if ($(this).val() == "ftps://") {
                        ftpOptions.show();
                        ftpesOptions.show();
                    } else if ($(this).val() == "ftpes://") {
                        ftpOptions.show();
                        ftpesOptions.show();
                    } else if ($(this).val() == "sftp://") {
                        //show sftp items
                        sftpOptions.show();
                    } else if ($(this).val() == "http://") {
                        //show http items
                        httpOptions.show();
                    } else if ($(this).val() == "https://") {
                        //show https items
                        httpsOptions.show();
                        httpOptions.show();
                    } else if ($(this).val() == "smb://") {
                        //show smb items
                    }
                }
            }).trigger("change");

            $("input[id$='host']", dlg).each(function() {
                var elm = $(this);
                elm.typeahead({
                    minLength: 0,
                    hint: true,
                    highlight: true
                }, {
                    name: 'hosts',
                    limit: 10,
                    source: crush.substringMatcher(bookmarksData.hosts, elm, true)
                });
            });

            $("input[id$='port']", dlg).each(function() {
                var elm = $(this);
                elm.typeahead({
                    minLength: 0,
                    hint: true,
                    highlight: true
                }, {
                    name: 'hosts',
                    limit: 10,
                    source: crush.substringMatcher(bookmarksData.ports, elm, true)
                });
            });

            $("input#PasswordBaseEncrypt", dlg).bind("change", function() {
                var parent = $(this).closest(".row");
                if ($(this).is(":checked")) {
                    parent.find(".password-based-encryption-input").show().find("input").focus();
                } else {
                    parent.find(".password-based-encryption-input").hide();
                }
            });

            $("input#verifyHost", dlg).bind("change", function() {
                var parent = $(this).parent().parent();
                if ($(this).is(":checked")) {
                    parent.next().show().find("input").focus();
                } else {
                    parent.next().hide();
                }
            });

            dlg.find(".cipher-control").click(function() {
                var cipherData = {};
                var curCipherVal = dlg.find("#cipherValue").text();
                curCipherVal = curCipherVal == "Default" ? "" : curCipherVal;
                if (curCipherVal == "Trust All")
                    cipherData.trustAll = true;
                else if (curCipherVal)
                    cipherData.cipher = curCipherVal;
                ciphers.show({
                    serverData: cipherData,
                    clientName: loadedClientName,
                    callback: function(cipher, trustAll) {
                        if (trustAll)
                            dlg.find("#cipherValue").text("Trust All");
                        else {
                            cipher = cipher == "" ? "Default" : cipher;
                            dlg.find("#cipherValue").text(cipher);
                        }
                    }
                });
                return false;
            });
            if (bookmark) {
                $('#protocol', dlg).val(bookmark.protocol).trigger('change');
                $('#host', dlg).val(bookmark.host);
                $('#port', dlg).val(bookmark.port).typeahead('val', bookmark.port);
                $('#username', dlg).val(bookmark.user);
                $('#password', dlg).val(crush.encryptDecryptPass(bookmark.pass + "", true));
                $('#default_path', dlg).val(bookmark.defaultPath);
                $('#connect', dlg).val(bookmark.connect);
                $('#bookmark_name', dlg).val(bookmark.name);
                $('#cipherValue', dlg).text(bookmark.cipher || "Default");
                $('#max_threads', dlg).val(bookmark.maxThreads);
                if (bookmark.pbe_pass) {
                    $('#pbe_pass', dlg).val(crush.encryptDecryptPass(bookmark.pbe_pass + "", true));
                }
                if (bookmark.pbe_pass)
                    $('#PasswordBaseEncrypt', dlg).attr("checked", "checked").trigger("change");
                else
                    $('#PasswordBaseEncrypt', dlg).removeAttr("checked").trigger("change");
                if (bookmark.use_tunnel && bookmark.use_tunnel.toString() == "true")
                    $('#useTunnel', dlg).attr("checked", "checked");
                else
                    $('#useTunnel', dlg).removeAttr("checked").trigger("change");

                if (bookmark.secure_data && bookmark.secure_data.toString() == "true")
                    $('#secureData', dlg).attr("checked", "checked");
                else
                    $('#secureData', dlg).removeAttr("checked").trigger("change");

                var ssh_private_key_pass = bookmark.ssh_private_key_pass || "";
                if (ssh_private_key_pass) {
                    ssh_private_key_pass = crush.encryptDecryptPass(ssh_private_key_pass + "", true);
                }
                $('#ssh_private_key', dlg).val(bookmark.ssh_private_key);
                if(bookmark.ssh_private_key_pass){
                    $('#ssh_private_key_pass', dlg).val(crush.encryptDecryptPass(bookmark.ssh_private_key_pass + "", true));
                }
                $('#knownHostFile', dlg).val(bookmark.knownHostFile);
                if(bookmark.ssh_two_factor && bookmark.ssh_two_factor.toString() == "true")
                    $('#ssh_two_factor', dlg).attr("checked", "checked").trigger("change");
                else
                    $('#ssh_two_factor', dlg).removeAttr("checked").trigger("change");

                if(bookmark.verifyHost && bookmark.verifyHost.toString() == "true")
                    $('#verifyHost', dlg).attr("checked", "checked").trigger("change");
                else
                    $('#verifyHost', dlg).removeAttr("checked").trigger("change");

                if(bookmark.addNewHost && bookmark.addNewHost.toString() == "true")
                    $('#addNewHost', dlg).attr("checked", "checked").trigger("change");
                else
                    $('#addNewHost', dlg).removeAttr("checked").trigger("change");
            }
        }

        function refresh(params) {
            var bookmarksList = $('#bookmarks-list', "#_bookmarksDialog");
            loadPrefs(function() {
                crush.hideLoading(true);
                bookmarksList.empty().append("<div class='text-center'>Nothing to show.</div>");
                if (prefs.bookmarks && prefs.bookmarks.length > 0) {
                    bookmarksList.empty();
                    var bookmarks = prefs.bookmarks;
                    bookmarks.sort(function(a, b) {
                        if (a.name.toLowerCase() < b.name.toLowerCase()) {
                            return -1;
                        }
                        if (a.name.toLowerCase() > b.name.toLowerCase()) {
                            return 1;
                        }
                        return 0;
                    });
                    var list = $("<ul class='bookmark-list popup-list'></ul>")
                    for (var i = 0; i < bookmarks.length; i++) {
                        var curBm = bookmarks[i];
                        if (curBm.protocol) {
                            var url;
                            if (curBm.user) {
                                url = curBm.protocol + curBm.user + ":" + crush.getStars(curBm.pass) + "@" + curBm.host;
                            } else
                                url = curBm.protocol + curBm.host;
                            if (curBm.name)
                                url = "<strong>" + curBm.name + "</strong> : <br>" + url;
                            if (curBm.defaultPath && curBm.defaultPath != "/")
                                url = url + "<br><small>(" + curBm.defaultPath + ")</small>";
                            var item = $('<li class="list-group-item bookmark schedule-item"><div class="row"><div class="col-md-1 text-center"><input name="cb_' + i + '" id="cb_' + i + '" type="checkbox" rel="' + curBm.id + '"> </div><div class="col-md-9 url">' + url + '</div><div class="col-md-2"><div><span style="float:right;"><a data-toggle="tooltip" data-placement="right" title="Edit Bookmark" class="edit" href="javascript:void(0);"><i class="fa fa-pencil fa-fw"></i></a> <a data-toggle="tooltip" data-placement="right" title="Remove Bookmark" class="remove" href="javascript:void(0);"><i class="fa fa-trash fa-fw"></i></a></span></div></div></div></li>');
                            item.find(".url").append("<div><span class='buttons'><a href=\"javascript:void(0);\" class=\"select connect\"><i class=\"fa fa-check-circle fa-fw\"></i>Select &amp; Connect</a> &nbsp; <a href=\"javascript:void(0);\" class=\"select\"><i class=\"fa fa-check fa-fw\"></i>Select</a></span></div>");
                            item.data("data-item", curBm);
                            list.append(item);
                        }
                    }
                    if (list.find("li").length == 0) {
                        list.append('<li class="text-center"><div class="text-center">Nothing to show.</div></li>')
                    }
                    bookmarksList.append(list.find("li"));

                    function getServerPanelInput(cb) {
                        var dlg = bootbox.dialog({
                            message: '<div class="well" style="padding:30px 0px;"><div style="text-align: center;width: 100%;position: absolute;top: 28px;" class="input-group-btn"><button type="button" class="btn btn-default left"><i class="fa fa-arrow-left"></i> Left Server</button><button type="button" class="btn btn-default right"><i class="fa fa-arrow-right"></i> Right Server</button></div></div>',
                            title: "Which panel to use : ",
                            onEscape: true,
                            backdrop: true
                        });
                        dlg.find(".input-group-btn button").click(function() {
                            cb($(this).hasClass('left'));
                            dlg.find('.bootbox-close-button').click();
                            return false;
                        });
                    }
                    bookmarksList.find(".select").bind("click", function() {
                        var elm = $(this);

                        function continueSelect(serverPanel) {
                            var dataItem = elm.closest("li").data("data-item");
                            var panelID = serverPanel.find(".server-settings:first").attr("id");
                            var pass = dataItem.pass || "";
                            if (pass) {
                                pass = crush.encryptDecryptPass(pass, true);
                            }
                            var pbe_pass = dataItem.pbe_pass || "";
                            if (pbe_pass) {
                                pbe_pass = crush.encryptDecryptPass(pbe_pass, true);
                            }
                            $('#' + panelID + '_protocol', serverPanel).val(dataItem.protocol || "").trigger('change', [true]);
                            $('#' + panelID + '_host', serverPanel).val(dataItem.host || "");
                            $('#' + panelID + '_port', serverPanel).val(dataItem.port || "").typeahead('val', dataItem.port || "");
                            $('#' + panelID + '_username', serverPanel).val(dataItem.user || "");
                            $('#' + panelID + '_password', serverPanel).val(pass);
                            $('#' + panelID + '_default_path', serverPanel).val(dataItem.defaultPath || "");
                            $('#' + panelID + '_connect', serverPanel).val(dataItem.connect || "");
                            $('#' + panelID + '_cipher', serverPanel).text(dataItem.cipher || "");
                            $('#' + panelID + '_max_threads', serverPanel).val(dataItem.maxThreads || "");
                            if (dataItem.tunnel && dataItem.tunnel.toString() == "true")
                                $('#' + panelID + '_use_tunnel', serverPanel).prop("checked", "checked");
                            else
                                $('#' + panelID + '_use_tunnel', serverPanel).removeProp("checked");

                            if (pbe_pass) {
                                $('#' + panelID + '_PasswordBaseEncrypt', serverPanel).prop("checked", "checked").trigger("change");
                                $('#' + panelID + '_PasswordBaseEncryptPass', serverPanel).val(pbe_pass);
                            } else {
                                $('#' + panelID + '_PasswordBaseEncrypt', serverPanel).removeProp("checked").trigger("change");
                                $('#' + panelID + '_PasswordBaseEncryptPass', serverPanel).val("");
                            }

                            //SFTP Items
                            $('#' + panelID + '_ssh_private_key', serverPanel).val(dataItem.ssh_private_key);
                            var ssh_private_key_pass = dataItem.ssh_private_key_pass || "";
                            if (ssh_private_key_pass) {
                                ssh_private_key_pass = crush.encryptDecryptPass(ssh_private_key_pass, true);
                                $('#' + panelID + '_ssh_private_key_pass', serverPanel).val(ssh_private_key_pass);
                            }
                            $('#' + panelID + '_knownHostFile', serverPanel).val(dataItem.knownHostFile);
                            if(dataItem.ssh_two_factor && dataItem.ssh_two_factor.toString() == "true")
                                $('#' + panelID + '_ssh_two_factor', serverPanel).prop("checked", "checked").trigger("change");
                            else
                                $('#' + panelID + '_ssh_two_factor', serverPanel).removeProp("checked").trigger("change");

                            if(dataItem.verifyHost && dataItem.verifyHost.toString() == "true")
                                $('#' + panelID + '_verifyHost', serverPanel).prop("checked", "checked").trigger("change");
                            else
                                $('#' + panelID + '_verifyHost', serverPanel).removeProp("checked").trigger("change");

                            if(dataItem.addNewHost && dataItem.addNewHost.toString() == "true")
                                $('#' + panelID + '_addNewHost', serverPanel).prop("checked", "checked").trigger("change");
                            else
                                $('#' + panelID + '_addNewHost', serverPanel).removeProp("checked").trigger("change");

                            var curInstance = tabInstances[loadedClientName];
                            var prefix;
                            if(serverPanel.find(".server-list-panel.left-server").length>0)
                                prefix = "l";
                            else
                                prefix = "";
                            var _serverData = prefix == "l" ? curInstance.leftServerData : curInstance.rightServerData;
                            _serverData = _serverData || {};
                            _serverData.connectedTo = _serverData.connectedTo || "";
                            var connectToo;
                            if(_serverData.connectedTo.indexOf("file") == 0 && dataItem.protocol.indexOf("file") == 0){
                                connectToo = true;
                            }
                            if (elm.hasClass('connect') || connectToo) {
                                serverPanel.find(".connect-button:last").trigger('click', [elm.closest(".bookmark").data("data-item").name]);
                            } else
                                serverPanel.find(".toggle-switch.collapsed").trigger("click");
                            $("#_bookmarksDialog").find(".modal-footer").find("button").click();
                        }
                        if (params) {
                            continueSelect(params.serverPanel);
                        } else {
                            var curInstance = tabInstances[loadedClientName];
                            getServerPanelInput(function(toUse) {
                                var curServerPanel = toUse ? curInstance.leftServerPanel : curInstance.rightServerPanel;
                                continueSelect(curServerPanel);
                            })
                        }
                        return false;
                    });
                    bookmarksList.find(".remove,.edit").unbind().click(function() {
                        var elem = $(this).closest("li");
                        if ($(this).is(".remove")) {
                            bootbox.confirm("Are you sure you want to remove selected bookmark?", function(result) {
                                if (result) {
                                    removeM([elem.find("input").attr("rel")]);
                                }
                            });
                        } else {
                            create(get(elem.find("input").attr("rel")));
                        }
                    });
                    $('[data-toggle="tooltip"]', "#_bookmarksDialog").tooltip({
                        container: "body"
                    });
                }
            });
        }

        function removeM(ids) {
            for (var i = 0; i < ids.length; i++) {
                remove(ids[i]);
            }
            savePrefs({
                callback: function() {
                    $.notify({
                        icon: 'glyphicon glyphicon-check',
                        message: "Bookmark(s) removed."
                    }, {
                        type: 'success',
                        timer: 3000
                    });
                    refresh();
                }
            });
        }

        function show(params) {
            var dlg = bootbox.dialog({
                title: "<i class='fa fa-bookmark fa-fw'></i> Bookmark Manager : ",
                message: $('#bookmarksDialog').html(),
                size: "large",
                value: "",
                onEscape: true,
                backdrop: true,
                buttons: {
                    ok: {
                        label: "OK",
                        className: "btn-success save",
                        callback: function() {}
                    }
                }
            });
            dlg.attr("id", "_bookmarksDialog");
            crush.showLoading(true);
            var btns = dlg.find("#top-button");
            var bookmarksList = $('#bookmarks-list', dlg).empty();
            btns.find(".btn").unbind().bind("click", function(e) {
                e.preventDefault();
                e.stopPropagation();
                if ($(this).is(".add")) {
                    create();
                } else if ($(this).is(".refresh")) {
                    refresh();
                } else if ($(this).is(".select-all")) {
                    bookmarksList.find("input[type='checkbox']").prop("checked", "checked");
                } else if ($(this).is(".select-none")) {
                    bookmarksList.find("input[type='checkbox']").removeAttr("checked");
                } else if ($(this).is(".remove")) {
                    var count = bookmarksList.find("input[type='checkbox']:checked:visible").length;
                    if (count) {
                        bootbox.confirm("Are you sure you want to remove selected " + count + " bookmark(s)?", function(result) {
                            if (result) {
                                var ids = [];
                                bookmarksList.find("input[type='checkbox']:checked:visible").each(function() {
                                    ids.push($(this).attr("rel"));
                                });
                                removeM(ids);
                            }
                        });
                    }
                }
            });

            var delay = (function() {
                var timer = 0;
                return function(callback, ms) {
                    clearTimeout(timer);
                    timer = setTimeout(callback, ms);
                };
            })();

            var filter = $("#filter", dlg).unbind("keyup").keyup(function(evt, data) {
                var evt = (evt) ? evt : ((event) ? event : null);
                if (evt.keyCode == 27) {
                    $(this).val("").trigger("keyup");
                    return false;
                }
                var phrase = $.trim($(this).val());
                if (phrase.length < 1) {
                    phrase = "";
                }
                if ($(this).data("last_searched") && $(this).data("last_searched") === phrase) {
                    return false;
                }

                function startFilter() {
                    if (phrase && phrase.length > 1) {
                        bookmarksList.find("li.list-group-item").hide();
                        var items = bookmarksList.find("li.list-group-item:Contains('" + phrase + "')").show();
                    } else
                        bookmarksList.find("li.list-group-item").show();
                }
                if (data) {
                    startFilter();
                } else {
                    delay(function() {
                        startFilter();
                    }, 200);
                }
            });
            refresh(params);
        }

        function XML(data) {
            var xml = [];
            var hasItem = false;
            if (data && data.name) {
                remove(false, data.name);
            }

            function prepareXML(info, saved) {
                var _xml = [];
                if (info && info.name && info.id) {
                    if (!saved && info.pass)
                        info.pass = crush.encryptDecryptPass(info.pass + "");
                    if (!saved && info.pbe_pass)
                        info.pbe_pass = crush.encryptDecryptPass(info.pbe_pass + "");
                    if (!saved && info.ssh_private_key_pass)
                        info.ssh_private_key_pass = crush.encryptDecryptPass(info.ssh_private_key_pass + "");
                    _xml.push('<bookmarks_subitem type="properties">');
                    for (var item in info) {
                        hasItem = true;
                        if (typeof info[item] == "string")
                            _xml.push('<' + item + '>' + encodeURIComponent(info[item] + "") + '</' + item + '>');
                    }
                    _xml.push('</bookmarks_subitem>');
                }
                return _xml;
            }
            xml.push('<bookmarks type="vector">');
            if (prefs.bookmarks) {
                for (var i = 0; i < prefs.bookmarks.length; i++) {
                    if (typeof prefs.bookmarks[i]["temp"] == "undefined") {
                        xml.push.apply(xml, prepareXML(prefs.bookmarks[i], true));
                    }
                }
            }
            xml.push.apply(xml, prepareXML(data));
            if (!hasItem)
                xml.push('<bookmarks_subitem type="properties"><temp></temp></bookmarks_subitem>');
            xml.push('</bookmarks>');
            return xml.join("\r\n");
        }

        return {
            get : get,
            XML: XML,
            show: show,
            remove: remove,
            hasName: function(name) {
                return get(false, name);
            }
        }
    })();

    var servers = (function() {
        function remove(id, name) {
            if (prefs.servers && prefs.servers.length > 0) {
                var servers = prefs.servers;
                var toKeep = [];
                for (var i = 0; i < servers.length; i++) {
                    if (id) {
                        if (servers[i].id != id)
                            toKeep.push(servers[i]);
                    }
                    if (name) {
                        if (servers[i].name && servers[i].name.toLowerCase() != name.toLowerCase())
                            toKeep.push(servers[i]);
                    }
                }
                prefs.servers = toKeep;
            }
        }

        function removeM(ids) {
            for (var i = 0; i < ids.length; i++) {
                remove(ids[i]);
            }
            savePrefs({
                callback: function() {
                    $.notify({
                        icon: 'glyphicon glyphicon-check',
                        message: "Server(s) removed."
                    }, {
                        type: 'success',
                        timer: 3000
                    });
                    refresh();
                }
            });
        }

        function get(id, name) {
            if (prefs.servers && prefs.servers.length > 0) {
                var servers = prefs.servers;
                var toKeep = [];
                for (var i = 0; i < servers.length; i++) {
                    if (id && servers[i].id == id)
                        return servers[i];
                    if (name && servers[i].name && servers[i].name.toLowerCase() == name.toLowerCase())
                        return servers[i];
                }
            }
            return false;
        }

        function save(info, server, cb) {
            if (!info)
                return false;
            if (server) {
                remove(server.id);
                remove(false, server.name);
            }
            savePrefs({
                newServer: info,
                callback: cb
            });
        }

        function create(server) {
            var dlg = bootbox.dialog({
                title: "<i class='fa fa-link fa-fw'></i> Managed Server : ",
                message: $('#createServerDialog').html(),
                size: "medium",
                value: "",
                onEscape: true,
                backdrop: true,
                buttons: {
                    cancel: {
                        label: "Cancel",
                        className: "btn-default cancel",
                        callback: function() {}
                    },
                    ok: {
                        label: "OK",
                        className: "btn-success save",
                        callback: function() {
                            var _dialog = $('#_serverDialog');
                            var protocol = $('#protocol', dlg).val() || "https";
                            var host = $('#host', dlg).val() || "";
                            var port = $('#port', dlg).val() || "";
                            var serverName = $('#server_name', dlg).val() || "";
                            var user = $('#username', dlg).val() || "";
                            var pass = $('#password', dlg).val() || "";
                            var serverData = {};

                            function continueSaveServer() {
                                serverData.name = $.trim(serverName);
                                serverData.protocol = $.trim(protocol);
                                serverData.host = $.trim(host);
                                serverData.port = $.trim(port);
                                serverData.user = $.trim(user);
                                serverData.pass = $.trim(pass);
                                if (server && server.id)
                                    serverData.id = server.id;
                                else
                                    serverData.id = "Server_" + crush.random();
                                save(serverData, server, function() {
                                    _dialog.find(".modal-footer").find("button.cancel").click();
                                    //refresh();
                                    $.notify({
                                        icon: 'glyphicon glyphicon-check',
                                        message: "Managed Server settings saved."
                                    }, {
                                        type: 'success',
                                        timer: 3000
                                    });
                                });
                            }
                            if (!serverName || crush.hasSpecialCharacters(serverName)) {
                                $.notify({
                                    icon: 'glyphicon glyphicon-warning-sign',
                                    message: 'Server name can not be empty or have special chars like : "@ # % & : = + ? / ."'
                                }, {
                                    placement: {
                                        align: 'center'
                                    },
                                    offset: {
                                        y: 200
                                    },
                                    type: 'danger',
                                    timer: 1000,
                                    z_index: 99999
                                });
                                $('#server_name', dlg).focus();
                                return false;
                            }
                            // if (((server && server.name != serverName) || !server) && servers.hasName(serverName)) {
                            //     bootbox.confirm("Server with name '" + serverName + "' exists, do you want to overwrite?", function(result) {
                            //         if (result) {
                            //             continueSaveServer();
                            //         } else {
                            //             $('#server_name', dlg).focus().select();
                            //         }
                            //     });
                            //     return false;
                            // }
                            continueSaveServer();
                        }
                    }
                }
            });
            dlg.attr("id", "_serverDialog");
            if (server) {
                $('#protocol', dlg).val(server.protocol);
                $('#host', dlg).val(server.host);
                $('#port', dlg).val(server.port).typeahead('val', server.port);
                $('#server_name', dlg).val(server.name);
                $('#username', dlg).val(server.user);
                if (server.pass)
                    $('#password', dlg).val(crush.encryptDecryptPass(server.pass + "", true));
            }
        }

        // function refresh(params) {
        //     var serversList = $('#servers-list', "#_serverDialog");
        //     loadPrefs(function() {
        //         crush.hideLoading(true);
        //         serversList.empty().append("<div class='text-center'>Nothing to show.</div>");
        //         if (prefs.servers && prefs.servers.length > 0) {
        //             serversList.empty();
        //             var serverItems = prefs.servers;
        //             serverItems.sort(function(a, b) {
        //                 if (a.name.toLowerCase() < b.name.toLowerCase()) {
        //                     return -1;
        //                 }
        //                 if (a.name.toLowerCase() > b.name.toLowerCase()) {
        //                     return 1;
        //                 }
        //                 return 0;
        //             });
        //             var list = $("<ul class='server-list popup-list'></ul>")
        //             for (var i = 0; i < serverItems.length; i++) {
        //                 var curServer = serverItems[i];
        //                 if (curServer.host) {
        //                     curServer.protocol = curServer.protocol || "http";
        //                     var url = curServer.protocol + "://" +curServer.host;
        //                     if (curServer.port)
        //                         url += ":" + curServer.port;
        //                     if (curServer.name)
        //                         url = "<strong>" + curServer.name + "</strong> : <br>" + url;
        //                     if (curServer.user) {
        //                         if (curServer.pass)
        //                             url += "<br>User : " + curServer.user + ":" + crush.getStars(curServer.pass);
        //                         else
        //                             url += "<br>User : " + curServer.user;
        //                     }
        //                     var item = $('<li class="list-group-item"><div class="row"><div class="col-md-1 text-center"><input name="cb_' + i + '" id="cb_' + i + '" type="checkbox" rel="' + curServer.id + '"> </div><div class="col-md-9 url">' + url + '</div><div class="col-md-2"><div><span style="float:right;"><a data-toggle="tooltip" data-placement="right" title="Edit server" class="edit" href="javascript:void(0);"><i class="fa fa-pencil fa-fw"></i></a> <a data-toggle="tooltip" data-placement="right" title="Remove Bookmark" class="remove" href="javascript:void(0);"><i class="fa fa-trash fa-fw"></i></a></span></div></div></div></li>');
        //                     item.data("data-item", curServer);
        //                     list.append(item);
        //                 }
        //             }
        //             if (list.find("li").length == 0) {
        //                 list.append('<li class="text-center"><div class="text-center">Nothing to show.</div></li>')
        //             }
        //             serversList.append(list.find("li"));
        //             serversList.find(".remove,.edit").unbind().click(function() {
        //                 var elem = $(this).closest("li");
        //                 if ($(this).is(".remove")) {
        //                     bootbox.confirm("Are you sure you want to remove selected server?", function(result) {
        //                         if (result) {
        //                             remove([elem.find("input").attr("rel")]);
        //                         }
        //                     });
        //                 } else {
        //                     create(get(elem.find("input").attr("rel")));
        //                 }
        //             });
        //             $('[data-toggle="tooltip"]', "#_serverDialog").tooltip({
        //                 container: "body"
        //             });
        //         }
        //     });
        // }

        function show(params) {
            // var dlg = bootbox.dialog({
            //     title: "<i class='fa fa-link fa-fw'></i> Managed Servers : ",
            //     message: $('#serversDialog').html(),
            //     size: "large",
            //     value: "",
            //     onEscape: true,
            //     backdrop: true,
            //     buttons: {
            //         ok: {
            //             label: "OK",
            //             className: "btn-success save",
            //             callback: function() {}
            //         }
            //     }
            // });
            // dlg.attr("id", "_serverDialog");
            // crush.showLoading(true);
            // var btns = dlg.find("#top-button");
            // var serverList = $('#servers-list', dlg).empty();
            // btns.find(".btn").unbind().bind("click", function(e) {
            //     e.preventDefault();
            //     e.stopPropagation();
            //     if ($(this).is(".add")) {
            //         create();
            //     } else if ($(this).is(".refresh")) {
            //         refresh();
            //     } else if ($(this).is(".select-all")) {
            //         serverList.find("input[type='checkbox']").prop("checked", "checked");
            //     } else if ($(this).is(".select-none")) {
            //         serverList.find("input[type='checkbox']").removeAttr("checked");
            //     } else if ($(this).is(".remove")) {
            //         var count = serverList.find("input[type='checkbox']:checked:visible").length;
            //         if (count) {
            //             bootbox.confirm("Are you sure you want to remove selected " + count + " server(s)?", function(result) {
            //                 if (result) {
            //                     var ids = [];
            //                     serverList.find("input[type='checkbox']:checked:visible").each(function() {
            //                         ids.push($(this).attr("rel"));
            //                     });
            //                     removeM(ids);
            //                 }
            //             });
            //         }
            //     }
            // });

            // var delay = (function() {
            //     var timer = 0;
            //     return function(callback, ms) {
            //         clearTimeout(timer);
            //         timer = setTimeout(callback, ms);
            //     };
            // })();

            // var filter = $("#filter", dlg).unbind("keyup").keyup(function(evt, data) {
            //     var evt = (evt) ? evt : ((event) ? event : null);
            //     if (evt.keyCode == 27) {
            //         $(this).val("").trigger("keyup");
            //         return false;
            //     }
            //     var phrase = $.trim($(this).val());
            //     if (phrase.length < 1) {
            //         phrase = "";
            //     }
            //     if ($(this).data("last_searched") && $(this).data("last_searched") === phrase) {
            //         return false;
            //     }

            //     function startFilter() {
            //         if (phrase && phrase.length > 1) {
            //             serverList.find("li.list-group-item").hide();
            //             var items = serverList.find("li.list-group-item:Contains('" + phrase + "')").show();
            //         } else
            //             serverList.find("li.list-group-item").show();
            //     }
            //     if (data) {
            //         startFilter();
            //     } else {
            //         delay(function() {
            //             startFilter();
            //         }, 200);
            //     }
            // });
            // refresh(params);
            loadPrefs(function() {
                crush.hideLoading(true);
                if (prefs.servers && prefs.servers.length > 0) {
                    var server = prefs.servers[0];
                    create(server);
                }
                else
                {
                    create();
                }
            });
        }

        function XML(data) {
            var xml = [];
            var hasItem = false;
            if (data && data.name) {
                remove(false, data.name);
            }

            function prepareXML(info, saved) {
                var _xml = [];
                if (info && info.name && info.id) {
                    if (!saved && info.pass)
                        info.pass = crush.encryptDecryptPass(info.pass + "");
                    _xml.push('<servers_subitem type="properties">');
                    for (var item in info) {
                        hasItem = true;
                        if (typeof info[item] == "string")
                            _xml.push('<' + item + '>' + encodeURIComponent(info[item] + "") + '</' + item + '>');
                    }
                    _xml.push('</servers_subitem>');
                }
                return _xml;
            }
            xml.push('<servers type="vector">');
            if (prefs.servers) {
                for (var i = 0; i < prefs.servers.length; i++) {
                    if (typeof prefs.servers[i]["temp"] == "undefined") {
                        xml.push.apply(xml, prepareXML(prefs.servers[i], true));
                    }
                }
            }
            xml.push.apply(xml, prepareXML(data));
            if (!hasItem)
                xml.push('<servers_subitem type="properties"><temp></temp></servers_subitem>');
            xml.push('</servers>');
            return xml.join("\r\n");
        }

        return {
            XML: XML,
            show: show,
            remove: remove,
            hasName: function(name) {
                return get(false, name);
            }
        }
    })();

    var ciphers = (function() {
        function show(params) {
            var serverData = params.serverData || {};
            var dlg = bootbox.dialog({
                title: "<i class='fa fa-steam fa-fw'></i> Cipher Control : ",
                message: $('#ciphersDialog').html(),
                size: "large",
                value: "",
                onEscape: true,
                backdrop: true,
                buttons: {
                    ok: {
                        label: "Done",
                        className: "btn-success save",
                        callback: function() {
                            var dialog = $('#_ciphersDialog');
                            var selectedCipher = dialog.find("input:checked").closest("li").attr("rel");
                            var trustAll = dialog.find("#trust_all_certificates").is(":checked");
                            if (params.callback) {
                                params.callback(selectedCipher, trustAll);
                            }
                        }
                    }
                }
            });

            function refresh(type) {
                if (type == "recent") {
                    var cmd = runCommand({
                        clientName: params.clientName,
                        command: "CIPHER get"
                    });
                    //crush.showLoading(true);
                    cmd.promise.then(function(data) {
                        //crush.hideLoading(false);
                        var ciphers = data;
                        ciphers = ciphers.replace("[", "").replace("]", "").split(",");
                        var recentCipherList = dlg.find("#recent-cipher-list").empty();
                        if (recentCipherList && recentCipherList.length > 0) {
                            for (var i = 0; i < ciphers.length; i++) {
                                var curItem = ciphers[i];
                                if (curItem) {
                                    var listItem = $("<li class='cipher-item' rel='" + curItem + "'><label><input type='radio'/> " + curItem + "</label></li>");
                                    recentCipherList.append(listItem);
                                }
                            }
                            if (recentCipherList.find("li").length == 0)
                                recentCipherList.append("<li class='text-center'>No items available</li>")
                        }
                    });
                } else {
                    var cmd = runCommand({
                        clientName: params.clientName,
                        command: "CIPHER list"
                    });
                    crush.showLoading(true);
                    if (dlg.find("#available-cipher-list").find("li").length == 0) {
                        dlg.find("#available-cipher-list").append("<li>Loading...</li>")
                    }
                    cmd.promise.then(function(data) {
                        crush.hideLoading(false);
                        var ciphers = data;
                        var curSelectedCipher = serverData.cipher;
                        ciphers = ciphers.replace("[", "").replace("]", "").split(",");
                        var avaliableCiphers = ciphers;
                        var availableCipherList = dlg.find("#available-cipher-list").empty();
                        if (avaliableCiphers && avaliableCiphers.length > 0) {
                            for (var i = 0; i < avaliableCiphers.length; i++) {
                                var curItem = avaliableCiphers[i];
                                if (curItem) {
                                    var checked = $.trim(curSelectedCipher) == $.trim(curItem) ? "checked='checked'" : "";
                                    var listItem = $("<li class='cipher-item' rel='" + curItem + "'><label><input " + checked + " name='selectedCipher' type='radio'/> " + curItem + "</label></li>");
                                    availableCipherList.append(listItem);
                                }
                            }
                            if (availableCipherList.find("li").length == 0)
                                availableCipherList.append("<li class='text-center'>No items available</li>");
                            else {
                                var listItem = $("<li class='cipher-item' rel=''><label><input name='selectedCipher' type='radio'/> Default</label></li>");
                                if (availableCipherList.find("input:checked").length == 0)
                                    listItem.find("input").attr("checked", "checked");
                                availableCipherList.prepend(listItem);
                            }
                        }
                    });
                }
            }
            refresh("recent");
            refresh("available");
            dlg.attr("id", "_ciphersDialog");
            if (serverData.trustAll) {
                dlg.find("#trust_all_certificates").attr("checked", "checked");
            }
            var delay = (function() {
                var timer = 0;
                return function(callback, ms) {
                    clearTimeout(timer);
                    timer = setTimeout(callback, ms);
                };
            })();

            var btns = dlg.find(".top-button");
            btns.find(".btn").unbind().bind("click", function(e) {
                var that = $(this);
                var cipherList = that.closest(".panel").find(".popup-list");
                e.preventDefault();
                e.stopPropagation();
                if ($(this).is(".refresh")) {
                    refresh($(this).attr("ref"));
                }
            });

            var filter = $(".filter-control", dlg).unbind("keyup").keyup(function(evt, data) {
                var that = $(this);
                var cipherList = that.closest(".panel").find(".popup-list");
                var evt = (evt) ? evt : ((event) ? event : null);
                if (evt.keyCode == 27) {
                    $(this).val("").trigger("keyup");
                    return false;
                }
                var phrase = $.trim($(this).val());
                if (phrase.length < 1) {
                    phrase = "";
                }
                if ($(this).data("last_searched") && $(this).data("last_searched") === phrase) {
                    return false;
                }

                function startFilter() {
                    if (phrase && phrase.length > 1) {
                        cipherList.find("li.cipher-item").hide();
                        var items = cipherList.find("li.cipher-item:Contains('" + phrase + "')").show();
                    } else
                        cipherList.find("li.cipher-item").show();
                }
                if (data) {
                    startFilter();
                } else {
                    delay(function() {
                        startFilter();
                    }, 200);
                }
            });
        }
        return {
            show: show
        }
    })();

    var settings = (function() {
        function show(params) {
            var settings = params && params.settings ? params.settings : {};
            var dlg = bootbox.dialog({
                title: "<i class='fa fa-wrench fa-fw'></i> General Settings : ",
                message: $('#generalSettingsDialog').html(),
                size: "large",
                value: "",
                onEscape: true,
                backdrop: true,
                buttons: {
                    ok: {
                        label: "Done",
                        className: "btn-success save",
                        callback: function() {
                            var dialog = $('#_generalSettingsDialog');
                            var data = {
                                enable_logging: $("#enable", dialog).is(":checked").toString(),
                                log_file: $("#log_file", dialog).val(),
                                log_level: $("#log_level", dialog).val(),
                                log_history: $("#log_history", dialog).val(),
                                action_list_position: $("input[name='action_list_position']:checked", dialog).val(),
                                client_view_mode: $("input[name='client_view_mode']:checked", dialog).val()
                            };
                            if (params.callback) {
                                params.callback(data);
                            }
                        }
                    }
                }
            });
            for (var item in settings) {
                var input = dlg.find("[name='" + item + "']");
                if (!input.is(":radio"))
                    input.val(settings[item]);
                if (input.attr("type") == "checkbox") {
                    if (settings[item].toString() == "true" || settings[item].toString() == "on")
                        input.prop("checked", "checked");
                    else
                        input.removeProp("checked");
                }
                if (item == "action_list_position") {
                    var val = settings[item];
                    dlg.find("input[name='action_list_position'][value='" + val + "']").attr("checked", "checked");
                }
                if (item == "client_view_mode") {
                    var val = settings[item];
                    dlg.find("input[name='client_view_mode'][value='" + val + "']").attr("checked", "checked");
                }
            }
            if(dlg.find("input[name='client_view_mode']:checked").length==0)
                dlg.find("input[name='client_view_mode'][value='simple']").attr("checked", "checked");
            dlg.attr("id", "_generalSettingsDialog");
        }
        return {
            show: show
        }
    })();

    return {
        prepare: prepare,
        init: init,
        authenticationToken: function() {
            return authenticationToken
        }
    };
})();

// Init CrushClient
CrushClient.prepare();